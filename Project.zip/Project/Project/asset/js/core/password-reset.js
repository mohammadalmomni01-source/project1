// Password reset helpers (front-end demo)
// This project is  (localStorage). We simulate "Forgot password" by
// generating a short code and showing it to the user.
(function(){
  const KEY = 'password_reset_tokens_v1';
  const TTL_MIN = 10; // code expiry

  function nowMs(){ return Date.now(); }
  function safeJsonParse(v, fallback){
    try{ return v ? JSON.parse(v) : fallback; }catch(_){ return fallback; }
  }
  function loadTokens(){
    return safeJsonParse(localStorage.getItem(KEY), []);
  }
  function saveTokens(tokens){
    localStorage.setItem(KEY, JSON.stringify(tokens||[]));
  }
  function normEmail(email){
    return String(email||'').trim().toLowerCase();
  }
  function genCode(){
    // 6 digits
    return String(Math.floor(100000 + Math.random()*900000));
  }
  function prune(tokens){
    const t = nowMs();
    return (tokens||[]).filter(x => x && x.expiresAt && x.expiresAt > t);
  }

  function findAccount(role, emailLower){
    if(role === 'customer'){
      const customers = (window.CustomerStore && window.CustomerStore.load)
        ? window.CustomerStore.load(window.CustomerStore.K.customers, [])
        : safeJsonParse(localStorage.getItem('lab_customers'), []);
      const idx = customers.findIndex(c => (c.email||'').toLowerCase() === emailLower);
      return { list: customers, idx, key: (window.CustomerStore && window.CustomerStore.K && window.CustomerStore.K.customers) ? window.CustomerStore.K.customers : 'lab_customers' };
    }
    if(role === 'provider'){
      const providers = safeJsonParse(localStorage.getItem('lab_providers'), []);
      const idx = providers.findIndex(p => (p.email||'').toLowerCase() === emailLower);
      return { list: providers, idx, key: 'lab_providers' };
    }
    return { list: [], idx: -1, key: '' };
  }

  function saveAccount(role, accountList, storageKey){
    if(role === 'customer' && window.CustomerStore && window.CustomerStore.save){
      window.CustomerStore.save(storageKey, accountList);
      return;
    }
    localStorage.setItem(storageKey, JSON.stringify(accountList||[]));
  }

  function request(role, email){
    const emailLower = normEmail(email);
    if(!emailLower) return { ok:false, error:'Please enter your email.' };

    const acc = findAccount(role, emailLower);
    if(acc.idx < 0) return { ok:false, error:'Account not found for this email.' };

    let tokens = prune(loadTokens());
    // Remove any previous token for same role+email
    tokens = tokens.filter(t => !(t.role === role && t.email === emailLower));

    const code = genCode();
    tokens.unshift({
      role,
      email: emailLower,
      code,
      createdAt: nowMs(),
      expiresAt: nowMs() + TTL_MIN*60*1000
    });
    saveTokens(tokens);
    return { ok:true, code, expiresInMin: TTL_MIN };
  }

  function reset(role, email, code, newPassword){
    const emailLower = normEmail(email);
    const c = String(code||'').trim();
    const pass = String(newPassword||'');

    if(!emailLower) return { ok:false, error:'Please enter your email.' };
    if(c.length < 4) return { ok:false, error:'Please enter the verification code.' };
    if(pass.length < 6) return { ok:false, error:'Password must be at least 6 characters.' };

    let tokens = prune(loadTokens());
    const tokIdx = tokens.findIndex(t => t.role === role && t.email === emailLower && String(t.code) === c);
    if(tokIdx < 0) return { ok:false, error:'Invalid or expired code.' };

    const acc = findAccount(role, emailLower);
    if(acc.idx < 0) return { ok:false, error:'Account not found.' };

    acc.list[acc.idx] = { ...acc.list[acc.idx], password: pass, updatedAt: new Date().toISOString() };
    saveAccount(role, acc.list, acc.key);

    // consume token
    tokens.splice(tokIdx, 1);
    saveTokens(tokens);
    return { ok:true };
  }

  window.PasswordReset = {
    request,
    reset,
    _debug: { KEY, TTL_MIN }
  };
})();
