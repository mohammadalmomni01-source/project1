import { supabase } from "../asset/js/supabaseClient.js";
import { getSession, getMyRole } from "../asset/js/supabaseAuth.js";

const u = document.getElementById("u"); // email
const p = document.getElementById("p");
const err = document.getElementById("err");

async function init() {
  const session = await getSession();
  if (session) {
    const role = await getMyRole();
    if (role === "admin") {
      window.location.href = "admin-dashboard-modern.html";
      return;
    }
  }
}
init();

async function doLogin() {
  err.style.display = "none";
  const email = (u.value || "").trim();
  const password = (p.value || "").trim();

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });

  if (error || !data?.session) {
    err.textContent = "Wrong email or password.";
    err.style.display = "block";
    return;
  }

  const role = await getMyRole();
  if (role !== "admin") {
    await supabase.auth.signOut();
    err.textContent = "Not authorized.";
    err.style.display = "block";
    return;
  }

  window.location.href = "admin-dashboard-modern.html";
}

document.getElementById("loginBtn").addEventListener("click", doLogin);
document.addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });
