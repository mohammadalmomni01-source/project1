// Shared helpers for customer flow ()
(function () {
    const TAX_RATE = 0.16; // demo tax rate (16%)

    const K = {
        customers: 'lab_customers',
        session: 'customer_session',
        cart: 'customer_cart',
        saved: 'customer_saved',
        orders: 'customer_orders',
        messages: 'customer_messages',
        reviews: 'customer_reviews'
    };

    // Per-customer scoping (fix): cart & saved were shared across all accounts
    // on the same browser because they used global localStorage keys.
    // We keep the original base keys (for minimal page changes), but transparently
    // namespace cart/saved by the logged-in customer's identity.
    function _normUserKey(v) {
        return String(v || '').trim().toLowerCase();
    }
    function getUserKey() {
        const s = (function () {
            try { return JSON.parse(localStorage.getItem(K.session) || 'null'); } catch (e) { return null; }
        })();
        if (!s || !s.loggedIn) return null;
        const key = _normUserKey(s.email || s.id);
        return key || null;
    }
    function scopedKey(key) {
        if (key !== K.cart && key !== K.saved) return key;
        const uk = getUserKey();
        return uk ? `${key}:${uk}` : key;
    }
    function migrateScoped() {
        const uk = getUserKey();
        if (!uk) return;
        // Move legacy global cart/saved into scoped keys once, then clear globals.
        try {
            for (const base of [K.cart, K.saved]) {
                const globalRaw = localStorage.getItem(base);
                const scoped = `${base}:${uk}`;
                const scopedRaw = localStorage.getItem(scoped);
                if (globalRaw && !scopedRaw) {
                    localStorage.setItem(scoped, globalRaw);
                }
                if (globalRaw) {
                    localStorage.removeItem(base);
                }
            }
        } catch (e) { /* ignore */ }
    }

    function load(key, fallback) {
        try {
            migrateScoped();
            const v = localStorage.getItem(scopedKey(key));
            return v ? JSON.parse(v) : fallback;
        } catch (e) {
            return fallback;
        }
    }
    function save(key, val) {
        migrateScoped();
        localStorage.setItem(scopedKey(key), JSON.stringify(val));
    }
    function uid(prefix = 'id') {
        return `${prefix}-${Math.random().toString(16).slice(2, 10)}-${Date.now().toString(16)}`;
    }
    function money(n) {
        const x = Number(n || 0);
        return `$${x.toFixed(2)}`;
    }
    function daysFromNow(days) {
        const d = new Date();
        d.setDate(d.getDate() + days);
        return d.toISOString().slice(0, 10);
    }
    function getSession() {
        return load(K.session, null);
    }
    function requireCustomer() {
        const s = getSession();
        if (!s || !s.loggedIn) window.location.href = 'customer-login.html';
        return s;
    }
    function priceForType(basePrice, orgType) {
        // Simple demo pricing tiers
        // Small Lab: base
        // Large Lab: 8% discount
        // Company: 12% discount, plus minimum order enforced on checkout
        const p = Number(basePrice || 0);
        if (orgType === 'Large Lab') return p * 0.92;
        if (orgType === 'Company') return p * 0.88;
        return p;
    }
    function calcCartTotals(cart, orgType) {
        let subtotal = 0;
        for (const line of cart) {
            subtotal += priceForType(line.basePrice, orgType) * line.qty;
        }
        const tax = subtotal * TAX_RATE; // demo
        const total = subtotal + tax;
        return { subtotal, tax, total };
    }

    window.CustomerStore = {
        K,
        TAX_RATE,
        load,
        save,
        uid,
        money,
        daysFromNow,
        getSession,
        requireCustomer,
        priceForType,
        calcCartTotals
    };
})();
