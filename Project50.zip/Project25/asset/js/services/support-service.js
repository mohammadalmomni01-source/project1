(function () {
    async function _sb() {
        if (window.supabaseClient) return window.supabaseClient;
        if (window.__supabase) return window.__supabase;
        if (window._supabaseForEmployee) return window._supabaseForEmployee;
        // create if config is available
        if (window.supabase && window.SUPABASE_URL) {
            window.__supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY, {
                auth: { persistSession: true, autoRefreshToken: true }
            });
            return window.__supabase;
        }
        // wait up to 5s
        let retries = 20;
        while (retries-- > 0) {
            await new Promise(r => setTimeout(r, 250));
            if (window.supabaseClient) return window.supabaseClient;
            if (window.__supabase) return window.__supabase;
        }
        console.error('[SupportService] No Supabase client found.');
        return null;
    }

    function _normStatus(s) {
        const v = String(s || '').toLowerCase();
        if (v === 'answered' || v === 'replied') return 'Answered';
        if (v === 'closed' || v === 'resolved') return 'Closed';
        return 'Open';
    }

    function _mapTicket(r) {
        if (!r) return null;
        return {
            id: r.id,
            customerEmail: r.customer_email,
            customerName: r.customer_name,
            requesterRole: r.requester_role || 'customer',
            subject: r.subject,
            category: r.category,
            orderRef: r.order_ref || '',
            status: _normStatus(r.status),
            lastReplyRole: r.last_reply_role || 'customer',
            autoAckSent: r.auto_ack_sent || false,
            createdAt: r.created_at,
            updatedAt: r.updated_at
        };
    }

    function _mapMsg(r) {
        if (!r) return null;
        return {
            id: r.id,
            ticketId: r.ticket_id,
            fromRole: r.from_role,
            fromName: r.from_name || '',
            fromEmail: r.from_email || '',
            text: r.text,
            createdAt: r.created_at,
            readBy: {
                customer: r.read_by_customer || false,
                admin: r.read_by_admin || false
            }
        };
    }

    async function listTickets({ email = null, role = null } = {}) {
        const sb = await _sb(); if (!sb) return [];
        let q = sb.from('support_tickets').select('*').order('updated_at', { ascending: false });
        if (email) q = q.eq('customer_email', String(email).trim().toLowerCase());
        if (role) q = q.eq('requester_role', String(role).trim().toLowerCase());
        const { data, error } = await q;
        return error ? [] : (data || []).map(_mapTicket);
    }

    async function getTicket(ticketId) {
        const sb = await _sb(); if (!sb) return null;
        const { data, error } = await sb.from('support_tickets')
            .select('*').eq('id', ticketId).maybeSingle();
        return error ? null : _mapTicket(data);
    }

    async function createTicket({ customerEmail, customerName, subject, category, message, orderRef, requesterRole = 'customer' } = {}) {
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };

        // Get logged-in user id
        const { data: sessData } = await sb.auth.getSession();
        const uid = sessData?.session?.user?.id || null;

        const { data: ticket, error } = await sb.from('support_tickets').insert({
            customer_id: uid,
            customer_email: String(customerEmail || '').trim().toLowerCase(),
            customer_name: String(customerName || '').trim(),
            requester_role: String(requesterRole || 'customer'),
            subject: String(subject || 'Help request').trim(),
            category: String(category || 'General').trim(),
            order_ref: String(orderRef || '').trim(),
            status: 'Open',
            last_reply_role: requesterRole,
            auto_ack_sent: false
        }).select().single();

        if (error) return { ok: false, error: error.message };

        // First message from requester
        const text = String(message || '').trim();
        if (text) {
            await sb.from('support_messages').insert({
                ticket_id: ticket.id,
                from_role: requesterRole === 'provider' ? 'provider' : 'customer',
                text,
                read_by_customer: true,
                read_by_admin: false
            });

            // Auto-ack
            await sb.from('support_messages').insert({
                ticket_id: ticket.id,
                from_role: 'admin',
                text: 'Thank you for contacting us. We have received your message and will get back to you as soon as possible.',
                read_by_customer: false,
                read_by_admin: true
            });

            await sb.from('support_tickets')
                .update({ auto_ack_sent: true })
                .eq('id', ticket.id);
        }

        return { ok: true, ticket: _mapTicket(ticket) };
    }

    async function updateTicket(ticketId, patch = {}) {
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        const upd = {};
        if (patch.status) upd.status = _normStatus(patch.status);
        if (patch.lastReplyRole) upd.last_reply_role = patch.lastReplyRole;
        if (patch.autoAckSent != null) upd.auto_ack_sent = patch.autoAckSent;
        const { data, error } = await sb.from('support_tickets')
            .update(upd).eq('id', ticketId).select().single();
        return error ? { ok: false, error: error.message } : { ok: true, ticket: _mapTicket(data) };
    }

    async function deleteTicket(ticketId) {
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        const { error } = await sb.from('support_tickets').delete().eq('id', ticketId);
        return error ? { ok: false, error: error.message } : { ok: true };
    }

    async function listMessages(ticketId) {
        const sb = await _sb(); if (!sb) return [];
        const { data, error } = await sb.from('support_messages')
            .select('*').eq('ticket_id', ticketId).order('created_at', { ascending: true });
        return error ? [] : (data || []).map(_mapMsg);
    }

    async function sendMessage(ticketId, { fromRole = 'customer', text, fromName = '', fromEmail = '' } = {}) {
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        const clean = String(text || '').trim();
        if (!clean) return { ok: false, error: 'Empty message' };

        const isAdmin = fromRole === 'admin' || fromRole === 'employee';
        const { data: msg, error } = await sb.from('support_messages').insert({
            ticket_id: ticketId,
            from_role: fromRole,
            from_name: fromName,
            from_email: fromEmail,
            text: clean,
            read_by_customer: isAdmin ? false : true,
            read_by_admin: isAdmin ? true : false
        }).select().single();

        if (error) return { ok: false, error: error.message };

        // Update ticket status
        const newStatus = isAdmin ? 'Answered' : 'Open';
        await sb.from('support_tickets')
            .update({ status: newStatus, last_reply_role: fromRole, updated_at: new Date().toISOString() })
            .eq('id', ticketId);

        return { ok: true, message: _mapMsg(msg) };
    }

    async function markRead(ticketId, role) {
        const sb = await _sb(); if (!sb) return false;
        const isAdmin = role === 'admin' || role === 'employee';
        const field = isAdmin ? 'read_by_admin' : 'read_by_customer';
        await sb.from('support_messages')
            .update({ [field]: true })
            .eq('ticket_id', ticketId)
            .eq(field, false);
        return true;
    }

    async function getUnreadCount(ticketId, role) {
        const sb = await _sb(); if (!sb) return 0;
        const isAdmin = role === 'admin' || role === 'employee';
        const field = isAdmin ? 'read_by_admin' : 'read_by_customer';
        const { count } = await sb.from('support_messages')
            .select('*', { count: 'exact', head: true })
            .eq('ticket_id', ticketId)
            .eq(field, false);
        return count || 0;
    }

    window.SupportService = {
        listTickets, getTicket, createTicket, updateTicket,
        deleteTicket, listMessages, sendMessage, markRead,
        getUnreadCount, normalizeStatus: _normStatus
    };
})();
