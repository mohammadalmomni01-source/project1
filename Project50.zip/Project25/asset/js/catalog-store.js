// catalog-store.js — fetches from Supabase, localStorage is cache only
(function () {
    const K = { items: 'app_products', suppliers: 'app_suppliers' };

    let _items = [], _suppliers = [], _readyResolve;
    const _ready = new Promise(r => { _readyResolve = r; });

    function _normItem(it) {
        if (!it) return null;
        const img = it.image_url || it.image || it.img || '';
        const desc = it.description || it.desc || '';
        const sid = it.provider_id || it.supplierId || it.supplier_id || '';
        const bp = Number(it.price ?? it.basePrice ?? 0);
        return {
            id: it.id || '', name: it.name || '', category: it.category || 'General',
            supplierId: sid, supplierName: it.supplierName || it.supplier_name || '',
            price: bp, basePrice: bp, stock: Number(it.stock ?? 0),
            image: img, img, image_url: img, description: desc, desc,
            deliveryDays: it.deliveryDays || { standard: 3, express: 2 },
            created_at: it.created_at || ''
        };
    }

    function _normSupplier(s) {
        if (!s) return null;
        return {
            id: s.id || '',
            name: s.company_name || s['company-name'] || s.full_name || 'Provider',
            city: s.city || '', phone: s.phone || '',
            email: s.email || '',
            whatsapp: s.whatsapp || '', avgPrepDays: Number(s.avgPrepDays ?? 2),
            logo: s.logo || '', about: s.about || ''
        };
    }

    function _loadCache() {
        try { const v = localStorage.getItem(K.items); if (v) _items = JSON.parse(v).map(_normItem).filter(Boolean); } catch (e) { }
        try { const v = localStorage.getItem(K.suppliers); if (v) _suppliers = JSON.parse(v).map(_normSupplier).filter(Boolean); } catch (e) { }
    }

    async function _fetchProducts(sb) {
        try {
            // Try Edge Function first
            const res = await sb.functions.invoke('list-products', { body: {} });
            if (!res.error) {
                const raw = Array.isArray(res.data) ? res.data
                    : Array.isArray(res.data?.products) ? res.data.products
                        : Array.isArray(res.data?.data) ? res.data.data : [];
                if (raw.length > 0) {
                    _items = raw.map(_normItem).filter(Boolean);
                    localStorage.setItem(K.items, JSON.stringify(_items));
                    return;
                }
            }
        } catch (e) { console.warn('[CatalogStore] Edge Function failed, trying direct DB:', e.message || e); }

        // Fallback: query the products table directly
        try {
            const { data, error } = await sb.from('products')
                .select('id,name,category,price,stock,image_url,description,provider_id,created_at');
            if (error) throw error;
            _items = (data || []).map(_normItem).filter(Boolean);
            localStorage.setItem(K.items, JSON.stringify(_items));
        } catch (e) { console.warn('[CatalogStore] products direct DB fetch failed:', e.message || e); }
    }

    async function _fetchSuppliers(sb) {
        try {
            const { data, error } = await sb.from('profiles')
                .select('id,full_name,company_name,phone,email,city,country,role')
                .eq('role', 'provider');
            if (error) throw error;
            _suppliers = (data || []).map(_normSupplier).filter(Boolean);
            localStorage.setItem(K.suppliers, JSON.stringify(_suppliers));
        } catch (e) { console.warn('[CatalogStore] suppliers fetch failed:', e.message || e); }
    }

    async function _init() {
        _loadCache(); // serve cache immediately for sync callers

        // Wait up to 3s for either the ES module client (supabaseClient) or the
        // global CDN client (__supabase) to be set — whichever comes first.
        let sb = window.supabaseClient || window.__supabase;
        if (!sb) {
            let tries = 30;
            while (!window.supabaseClient && !window.__supabase && tries-- > 0) {
                await new Promise(r => setTimeout(r, 100));
            }
            sb = window.supabaseClient || window.__supabase;
        }

        if (sb) await Promise.all([_fetchProducts(sb), _fetchSuppliers(sb)]);

        _readyResolve();
        window.dispatchEvent(new CustomEvent('catalogReady', {
            detail: { items: _items, suppliers: _suppliers }
        }));
    }

    document.readyState === 'loading'
        ? document.addEventListener('DOMContentLoaded', _init)
        : _init();

    window.CatalogStore = {
        K,
        ready: _ready,
        getItems() { return _items.slice(); },
        getSuppliers() { return _suppliers.slice(); },
        getSupplier(id) { return _suppliers.find(s => s.id === id) || null; },
        setItems(list) {
            _items = (list || []).map(_normItem).filter(Boolean);
            localStorage.setItem(K.items, JSON.stringify(_items));
        },
        setSuppliers(list) {
            _suppliers = (list || []).map(_normSupplier).filter(Boolean);
            localStorage.setItem(K.suppliers, JSON.stringify(_suppliers));
        },
        refresh() { return _init(); },
        load(key, fb) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fb; } catch (e) { return fb; } },
        save(key, val) { localStorage.setItem(key, JSON.stringify(val)); }
    };
})();
