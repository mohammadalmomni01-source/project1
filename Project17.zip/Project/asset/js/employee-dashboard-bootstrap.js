import { supabase } from './supabaseClient.js';
import { getEmployeeAccessContext } from './employee-guard.js';

const LEGACY_AUTH_KEYS = [
    'adminLoggedIn',
    'adminName',
    'adminEmail',
    'employeeLoggedIn',
    'employeeRole',
    'employeeEmail',
    'employeeName',
    'employeeIntent',
];

const NAV_VIEW_MAP = {
    'nav-dashboard': 'dashboard',
    'nav-orders': 'orders',
    'nav-users': 'users',
    'nav-providers': 'providers',
    'nav-providerRequests': 'providerRequests',
    'nav-itemRequests': 'itemRequests',
    'nav-support': 'support',
    'nav-providerMessages': 'providerMessages',
};

const QUICK_VIEW_MAP = {
    'btn-viewOrders': 'orders',
    'btn-manageUsers': 'users',
    'btn-manageProviders': 'providers',
};

function clearLegacyAuthFlags() {
    LEGACY_AUTH_KEYS.forEach((key) => localStorage.removeItem(key));
}

function toRoleLabel(role) {
    return role === 'supplier_manager' ? 'Supplier Management' : 'Order Support';
}

function setEmployeeLabels(ctx) {
    const userRoleTop = document.getElementById('userRoleTop');
    const userNameTop = document.getElementById('userNameTop');
    const userEmailTop = document.getElementById('userEmailTop');
    const brandTitle = document.querySelector('.brand h1');
    const brandSub = document.querySelector('.brand p');
    const roleLabel = toRoleLabel(ctx.user.employee_role);

    if (userRoleTop) userRoleTop.textContent = `Employee � ${roleLabel}`;
    if (userNameTop) userNameTop.textContent = ctx.user.full_name || 'Employee';
    if (userEmailTop) userEmailTop.textContent = ctx.user.email || '';
    if (brandTitle) brandTitle.textContent = 'EMPLOYEES';
    if (brandSub) brandSub.textContent = roleLabel;
}

function sanitizeView(allowedViews, defaultView, requested) {
    if (!allowedViews.has(requested) || requested === 'dashboard' || requested === 'users') {
        return defaultView;
    }
    return requested;
}

function stripAndReplace(id) {
    const oldNode = document.getElementById(id);
    if (!oldNode) return null;
    const newNode = oldNode.cloneNode(true);
    oldNode.replaceWith(newNode);
    return newNode;
}

function setBlocked(el, blocked) {
    if (!el) return;
    if ('disabled' in el) el.disabled = blocked;

    if (blocked) {
        el.classList.add('is-disabled');
        el.setAttribute('aria-disabled', 'true');
        el.removeAttribute('href');
        el.tabIndex = -1;
        el.style.pointerEvents = 'none';
        el.style.opacity = '0.5';
        el.style.cursor = 'not-allowed';
        el.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            return false;
        });
    } else {
        el.classList.remove('is-disabled');
        el.setAttribute('aria-disabled', 'false');
        el.tabIndex = 0;
        el.style.pointerEvents = '';
        el.style.opacity = '';
        el.style.cursor = '';
    }
}

function wireEmployeeLogout() {
    const handler = async (event) => {
        event.preventDefault();
        const ok = window.confirm('Do you want to logout?');
        if (!ok) return;

        try {
            await supabase.auth.signOut();
        } catch (_) {
            // continue to cleanup and redirect
        }

        clearLegacyAuthFlags();
        window.location.href = '../employees/index.html';
    };

    ['btn-logout', 'btn-logout-top'].forEach((id) => {
        const btn = stripAndReplace(id);
        if (!btn) return;
        btn.addEventListener('click', handler);
    });
}

function applyEmployeeDashboardPermissions(ctx) {
    const allowed = new Set(ctx.permissions.allowedViews || []);
    const defaultView = ctx.permissions.defaultView || 'orders';
    const baseShowView = typeof window.showView === 'function' ? window.showView.bind(window) : null;
    if (!baseShowView) return;

    let mutatingHash = false;

    const lockedShowView = (viewName) => {
        const safeView = sanitizeView(allowed, defaultView, viewName);
        baseShowView(safeView);

        Object.keys(NAV_VIEW_MAP).forEach((id) => {
            const el = document.getElementById(id);
            const view = NAV_VIEW_MAP[id];
            if (!el) return;
            if (!allowed.has(view) || view === 'dashboard' || view === 'users') {
                el.classList.remove('active');
            }
        });

        const nextHash = `#view-${safeView}`;
        if (window.location.hash !== nextHash) {
            mutatingHash = true;
            window.location.hash = nextHash;
            mutatingHash = false;
        }
    };

    Object.entries(NAV_VIEW_MAP).forEach(([id, view]) => {
        const el = stripAndReplace(id);
        if (!el) return;

        const blocked = !allowed.has(view) || view === 'dashboard' || view === 'users';
        setBlocked(el, blocked);

        if (!blocked) {
            el.addEventListener('click', (event) => {
                event.preventDefault();
                lockedShowView(view);
            });
        }
    });

    Object.entries(QUICK_VIEW_MAP).forEach(([id, view]) => {
        const el = stripAndReplace(id);
        if (!el) return;

        const blocked = !allowed.has(view) || view === 'dashboard' || view === 'users';
        setBlocked(el, blocked);

        if (!blocked) {
            el.addEventListener('click', (event) => {
                event.preventDefault();
                lockedShowView(view);
            });
        }
    });

    window.showView = lockedShowView;
    window.addEventListener('hashchange', () => {
        if (mutatingHash) return;
        const raw = (window.location.hash || '').replace(/^#view-/, '').trim();
        lockedShowView(raw || defaultView);
    });

    lockedShowView(defaultView);
}

async function bootEmployeeDashboard() {
    const ctx = await getEmployeeAccessContext({ redirect: false, fallbackPath: '../employees/index.html' });

    if (ctx?.isAdmin) {
        window.location.href = ctx.redirect || '../admin/admin-dashboard-modern.html';
        return;
    }

    if (!ctx?.ok) {
        try {
            await supabase.auth.signOut();
        } catch (_) {
            // continue
        }
        clearLegacyAuthFlags();
        window.location.href = '../employees/index.html';
        return;
    }

    clearLegacyAuthFlags();

    try {
        localStorage.setItem('employeeName', ctx.user.full_name || 'Employee');
        localStorage.setItem('employeeEmail', ctx.user.email || '');
    } catch (_) {
        // ignore storage errors
    }

    setEmployeeLabels(ctx);
    applyEmployeeDashboardPermissions(ctx);
    wireEmployeeLogout();

    if (typeof window.refreshOrders === 'function') window.refreshOrders();
    if (typeof window.refreshUsers === 'function') window.refreshUsers();
    if (typeof window.refreshProviders === 'function') window.refreshProviders();
    if (typeof window.refreshProviderRequests === 'function') window.refreshProviderRequests();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootEmployeeDashboard);
} else {
    bootEmployeeDashboard();
}
