(function () {
    const KEY = 'lab_staff_chats_v1';

    function now() { return new Date().toISOString(); }

    function load() {
        try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; }
    }
    function save(arr) { localStorage.setItem(KEY, JSON.stringify(arr)); }

    function getProviderId() {
        // Provider session keys vary; try common ones
        return localStorage.getItem('providerId') || localStorage.getItem('loggedInProviderId') || localStorage.getItem('currentProviderId') || null;
    }

    function getProviderName() {
        return localStorage.getItem('providerName') || localStorage.getItem('loggedInProviderName') || 'Provider';
    }

    function ensureThread(providerId) {
        const threads = load();
        let t = threads.find(x => x.providerId === providerId);
        if (!t) {
            t = { providerId, messages: [], unreadForStaff: 0, unreadForProvider: 0, createdAt: now(), updatedAt: now(), autoAckSent: false };
            threads.unshift(t);
            save(threads);
        }
        return t;
    }

    function upsertThread(thread) {
        const threads = load();
        const idx = threads.findIndex(x => x.providerId === thread.providerId);
        if (idx >= 0) threads.splice(idx, 1);
        threads.unshift(thread);
        save(threads);
    }

    function listThreads() {
        return load().slice().sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
    }

    function getThread(providerId) {
        return load().find(x => x.providerId === providerId) || null;
    }

    function sendFromProvider(providerId, providerName, text) {
        const t = ensureThread(providerId);
        const msg = { id: 'm_' + Math.random().toString(36).slice(2, 10), fromRole: 'provider', fromId: providerId, fromName: providerName || 'Provider', text: String(text || ''), at: now() };
        t.messages.push(msg);
        t.updatedAt = now();
        t.unreadForStaff = (t.unreadForStaff || 0) + 1;

        // Auto acknowledgement on first provider-initiated message
        if (!t.autoAckSent) {
            t.autoAckSent = true;
            const ack = { id: 'm_' + Math.random().toString(36).slice(2, 10), fromRole: 'staff', fromId: 'staff', fromName: 'Support Team', text: 'Thanks for reaching out. Our team will respond shortly.', at: now(), isAuto: true };
            t.messages.push(ack);
            t.updatedAt = now();
            t.unreadForProvider = (t.unreadForProvider || 0) + 1;
        }

        upsertThread(t);
        return msg;
    }

    function sendFromStaff(providerId, actor, text) {
        const t = ensureThread(providerId);
        const fromName = (actor && actor.name) ? actor.name : 'Staff';
        const fromEmail = (actor && actor.email) ? actor.email : '';
        // Preserve who replied (admin / employee / staff) so the UI can show the correct name.
        const role = (actor && actor.role) ? actor.role : 'staff';
        const msg = { id: 'm_' + Math.random().toString(36).slice(2, 10), fromRole: role, fromId: (actor && actor.id) ? actor.id : role, fromName, fromEmail, text: String(text || ''), at: now() };
        t.messages.push(msg);
        t.updatedAt = now();
        t.unreadForProvider = (t.unreadForProvider || 0) + 1;
        upsertThread(t);
        return msg;
    }

    function markReadForStaff(providerId) {
        const t = getThread(providerId);
        if (!t) return;
        t.unreadForStaff = 0;
        t.updatedAt = now();
        upsertThread(t);
    }
    function markReadForProvider(providerId) {
        const t = getThread(providerId);
        if (!t) return;
        t.unreadForProvider = 0;
        t.updatedAt = now();
        upsertThread(t);
    }

    // Expose
    window.StaffChatService = {
        KEY,
        listThreads,
        getThread,
        sendFromProvider,
        sendFromStaff,
        markReadForStaff,
        markReadForProvider,
        getProviderId,
        getProviderName
    };
})();
