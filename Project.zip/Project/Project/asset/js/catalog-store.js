// catalog-store.js ()
// Makes products/suppliers editable via localStorage so Provider/Admin edits reflect in Customer Shop.
(function(){
  const K = {
    items: 'app_products',
    suppliers: 'app_suppliers'
  };

  function load(key, fallback){
    try{
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    }catch(e){ return fallback; }
  }
  function save(key, val){ localStorage.setItem(key, JSON.stringify(val)); }

  function normItem(it){
    if(!it) return null;
    const id = it.id || ('P-'+Math.random().toString(16).slice(2,8));
    const name = it.name || it.title || 'Item';
    const supplierId = it.supplierId || it.supplier || it.supplier_id || it.providerId || it.companyId || '';
    const category = it.category || 'General';

    // Support both price/basePrice fields (customer uses basePrice; provider uses price)
    const basePrice = Number(it.basePrice ?? it.price ?? 0);
    const price = Number(it.price ?? it.basePrice ?? 0);

    const stock = Number(it.stock ?? it.qty ?? it.quantity ?? 0);

    // Support both image/img fields
    const image = it.image || it.img || it.photo || '';
    const img = it.img || it.image || it.photo || '';

    const deliveryDays = it.deliveryDays || it.delivery || { standard: 3, express: 2 };
    const desc = it.desc || it.description || '';

    return {
      ...it,
      id, name, supplierId, category,
      basePrice, price, stock,
      image, img,
      deliveryDays,
      desc
    };
  }

  function normSupplier(s){
    if(!s) return null;
    const id = s.id || ('S-'+Math.random().toString(16).slice(2,6));
    const name = s.name || s.company || 'Supplier';
    return {
      ...s,
      id,
      name,
      city: s.city || '',
      phone: s.phone || '',
      email: s.email || '',
      website: s.website || '',
      whatsapp: s.whatsapp || '',
      avgPrepDays: Number(s.avgPrepDays ?? 2),
      logo: s.logo || '',
      about: s.about || s.description || ''
    };
  }

  function seedOnce(){
    // Seed from demo arrays if present
    if(!localStorage.getItem(K.suppliers)){
      const seedSup = (window.LAB_SUPPLIERS || window.SUPPLIERS || []).map(normSupplier).filter(Boolean);
      save(K.suppliers, seedSup);
    }
    if(!localStorage.getItem(K.items)){
      const supList = load(K.suppliers, []);
      const supNameById = {};
      supList.forEach(s=>{ if(s && s.id) supNameById[s.id] = s.name; });

      const seedItems = (window.LAB_ITEMS || []).map(it=>{
        const n = normItem(it);
        if(!n) return null;
        if(!n.supplierName) n.supplierName = supNameById[n.supplierId] || '';
        return n;
      }).filter(Boolean);
      save(K.items, seedItems);
    }
  }

  seedOnce();

  function getItemsNormalized(){
    const list = load(K.items, []);
    const fixed = list.map(normItem).filter(Boolean);
    // Lightweight migration: keep storage compatible
    save(K.items, fixed);
    return fixed;
  }

  function getSuppliersNormalized(){
    const list = load(K.suppliers, []);
    const fixed = list.map(normSupplier).filter(Boolean);
    save(K.suppliers, fixed);
    return fixed;
  }

  window.CatalogStore = {
    K,
    load, save,
    getItems(){ return getItemsNormalized(); },
    setItems(list){
      const fixed = (list||[]).map(normItem).filter(Boolean);
      save(K.items, fixed);
    },
    getSuppliers(){ return getSuppliersNormalized(); },
    setSuppliers(list){
      const fixed = (list||[]).map(normSupplier).filter(Boolean);
      save(K.suppliers, fixed);
    },
    getSupplier(id){ return this.getSuppliers().find(s=>s.id===id); }
  };
})();
