// Provider dashboard Supabase wiring is implemented inline in provider-dashboard.html.
export { };
