import { supabase } from "../supabaseClient.js";

const ROLE_ALIASES = {
    supplier_manager: "supplier_management",
    supplier_management: "supplier_management",
    supplier: "supplier_management",
    order_support: "order_support",
    support: "order_support",
};

const PERMISSIONS = {
    supplier_management: {
        stats: ["providerRequests", "itemRequests"],
        tables: {
            recentRequests: "provider_requests",
            reviewRequests: "item_requests",
            providers: "providers",
        },
    },
    order_support: {
        stats: ["totalOrders", "pendingOrders"],
        tables: {
            recentOrders: "orders",
            orderDetails: "order_details",
            messages: "messages",
            tickets: "support_tickets",
        },
    },
};

function normalizeRole(rawRole) {
    const key = String(rawRole || "").trim().toLowerCase().replace(/\s+/g, "_");
    return ROLE_ALIASES[key] || null;
}

async function getCurrentUser() {
    const { data, error } = await supabase.auth.getUser();
    if (error) throw error;
    return data?.user || null;
}

async function fetchProfileRole(userId) {
    const profileQueries = [
        supabase.from("profiles").select("role").eq("id", userId).maybeSingle(),
        supabase.from("users").select("role").eq("id", userId).maybeSingle(),
    ];

    for (const query of profileQueries) {
        const { data, error } = await query;
        if (!error && data?.role) {
            return data.role;
        }
    }

    return null;
}

async function countRows(tableName, builder) {
    let query = supabase.from(tableName).select("id", { count: "exact", head: true });
    if (typeof builder === "function") {
        query = builder(query) || query;
    }
    const { count, error } = await query;
    if (error) return 0;
    return count || 0;
}

async function listRows(tableName, options = {}) {
    const {
        select = "*",
        orderBy = "created_at",
        ascending = false,
        limit = 5,
        builder,
    } = options;

    let query = supabase.from(tableName).select(select);
    if (typeof builder === "function") {
        query = builder(query) || query;
    }

    if (orderBy) {
        query = query.order(orderBy, { ascending });
    }

    if (limit > 0) {
        query = query.limit(limit);
    }

    const { data, error } = await query;
    if (error) return [];
    return Array.isArray(data) ? data : [];
}

export async function getEmployeeRole() {
    const user = await getCurrentUser();
    if (!user) return null;

    const dbRole = await fetchProfileRole(user.id);
    const normalizedRole = normalizeRole(dbRole);

    return {
        user,
        rawRole: dbRole,
        role: normalizedRole,
        permissions: normalizedRole ? PERMISSIONS[normalizedRole] : null,
    };
}

export async function getDashboardData() {
    const roleContext = await getEmployeeRole();
    const role = roleContext?.role;

    if (!role || !PERMISSIONS[role]) {
        return {
            role,
            stats: {
                totalOrders: 0,
                pendingOrders: 0,
                providerRequests: 0,
                itemRequests: 0,
            },
            recentOrders: [],
            recentRequests: [],
            messages: [],
        };
    }

    const stats = {
        totalOrders: 0,
        pendingOrders: 0,
        providerRequests: 0,
        itemRequests: 0,
    };

    if (role === "supplier_management") {
        const [providerRequests, itemRequests, recentRequests] = await Promise.all([
            countRows("provider_requests"),
            countRows("item_requests"),
            listRows("provider_requests", { limit: 10 }),
        ]);

        stats.providerRequests = providerRequests;
        stats.itemRequests = itemRequests;

        return {
            role,
            stats,
            recentOrders: [],
            recentRequests,
            messages: [],
        };
    }

    const [
        totalOrders,
        pendingOrders,
        recentOrders,
        messages,
    ] = await Promise.all([
        countRows("orders"),
        countRows("orders", (query) => query.in("status", ["pending", "Pending", "processing", "Processing"])),
        listRows("orders", { limit: 10 }),
        listRows("messages", { limit: 10 }),
    ]);

    stats.totalOrders = totalOrders;
    stats.pendingOrders = pendingOrders;

    return {
        role,
        stats,
        recentOrders,
        recentRequests: [],
        messages,
    };
}

export default {
    getEmployeeRole,
    getDashboardData,
};
