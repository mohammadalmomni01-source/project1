/**
 * ProviderCustomerChatService
 * Handles direct messages between providers and customers
 * Uses the `provider_customer_messages` Supabase table
 */
(function () {
    const TABLE = 'provider_customer_messages';

    async function _sb() {
        let s = window.__supabase || window.__providerSupabase || window.__shopSupabase;
        if (!s) {
            for (let i = 0; i < 40; i++) {
                await new Promise(r => setTimeout(r, 100));
                s = window.__supabase || window.__providerSupabase || window.__shopSupabase;
                if (s) break;
            }
        }
        return s || null;
    }

    /**
     * Get all messages for a given order between a provider and customer
     */
    async function listMessages(orderId) {
        const sb = await _sb();
        if (!sb) return [];
        const { data, error } = await sb
            .from(TABLE)
            .select('*')
            .eq('order_id', orderId)
            .order('created_at', { ascending: true });
        if (error) { console.warn('[PCChat] listMessages error:', error); return []; }
        return data || [];
    }

    /**
     * Send a message
     * @param {string} orderId
     * @param {string} providerId
     * @param {string} customerEmail
     * @param {'customer'|'provider'} senderRole
     * @param {string} senderName
     * @param {string} senderEmail
     * @param {string} message
     */
    async function sendMessage(orderId, providerId, customerEmail, senderRole, senderName, senderEmail, message) {
        const sb = await _sb();
        if (!sb) return null;
        const clean = String(message || '').trim();
        if (!clean) return null;
        const { data, error } = await sb
            .from(TABLE)
            .insert({
                order_id: orderId,
                provider_id: providerId,
                customer_email: customerEmail,
                sender_role: senderRole,
                sender_name: senderName || '',
                sender_email: senderEmail || '',
                message: clean,
                read_by_customer: senderRole === 'customer',
                read_by_provider: senderRole === 'provider'
            })
            .select()
            .single();
        if (error) { console.warn('[PCChat] sendMessage error:', error); return null; }
        return data;
    }

    /**
     * Get all threads for a provider (grouped by order_id + customer_email)
     */
    async function listThreadsForProvider(providerId) {
        const sb = await _sb();
        if (!sb) return [];
        const { data, error } = await sb
            .from(TABLE)
            .select('*')
            .eq('provider_id', providerId)
            .order('created_at', { ascending: false });
        if (error) { console.warn('[PCChat] listThreadsForProvider error:', error); return []; }
        // Group by order_id
        const threads = {};
        for (const m of (data || [])) {
            if (!threads[m.order_id]) {
                threads[m.order_id] = {
                    orderId: m.order_id,
                    providerId: m.provider_id,
                    customerEmail: m.customer_email,
                    customerName: '',
                    lastMessage: m.message,
                    lastAt: m.created_at,
                    unreadForProvider: 0,
                    messages: []
                };
            }
            threads[m.order_id].messages.push(m);
            if (!m.read_by_provider && m.sender_role === 'customer') {
                threads[m.order_id].unreadForProvider++;
            }
            // Pick the most recent last message
            if (m.created_at > threads[m.order_id].lastAt) {
                threads[m.order_id].lastMessage = m.message;
                threads[m.order_id].lastAt = m.created_at;
            }
            // Try to get customer name from messages
            if (m.sender_role === 'customer' && m.sender_name) {
                threads[m.order_id].customerName = m.sender_name;
            }
        }
        return Object.values(threads).sort((a, b) => b.lastAt.localeCompare(a.lastAt));
    }

    /**
     * Get all threads for a customer (grouped by order_id)
     */
    async function listThreadsForCustomer(customerEmail) {
        const sb = await _sb();
        if (!sb) return [];
        const { data, error } = await sb
            .from(TABLE)
            .select('*')
            .eq('customer_email', customerEmail)
            .order('created_at', { ascending: false });
        if (error) { console.warn('[PCChat] listThreadsForCustomer error:', error); return []; }
        // Group by order_id
        const threads = {};
        for (const m of (data || [])) {
            if (!threads[m.order_id]) {
                threads[m.order_id] = {
                    orderId: m.order_id,
                    providerId: m.provider_id,
                    customerEmail: m.customer_email,
                    providerName: '',
                    providerEmail: '',
                    lastMessage: m.message,
                    lastAt: m.created_at,
                    unreadForCustomer: 0,
                    messages: []
                };
            }
            threads[m.order_id].messages.push(m);
            if (!m.read_by_customer && m.sender_role === 'provider') {
                threads[m.order_id].unreadForCustomer++;
            }
            if (m.created_at > threads[m.order_id].lastAt) {
                threads[m.order_id].lastMessage = m.message;
                threads[m.order_id].lastAt = m.created_at;
            }
            // Try to get provider name from messages
            if (m.sender_role === 'provider' && m.sender_name) {
                threads[m.order_id].providerName = m.sender_name;
                threads[m.order_id].providerEmail = m.sender_email || '';
            }
        }
        return Object.values(threads).sort((a, b) => b.lastAt.localeCompare(a.lastAt));
    }

    /**
     * Mark all messages in an order as read for a role
     */
    async function markRead(orderId, role) {
        const sb = await _sb();
        if (!sb) return;
        const col = role === 'customer' ? 'read_by_customer' : 'read_by_provider';
        await sb.from(TABLE).update({ [col]: true }).eq('order_id', orderId).eq('sender_role', role === 'customer' ? 'provider' : 'customer');
    }

    window.ProviderCustomerChatService = {
        listMessages,
        sendMessage,
        listThreadsForProvider,
        listThreadsForCustomer,
        markRead
    };
})();
