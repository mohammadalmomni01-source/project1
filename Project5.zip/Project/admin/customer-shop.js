// Customer shop Supabase wiring is implemented inline in customer-shop.html.
export { };
