/* ItemRequestsService -  approval queue for provider item actions (ADD/EDIT/DELETE) */
(function(global){
  'use strict';

  const KEY = 'admin_item_requests_v1';

  function _nowISO(){ return new Date().toISOString(); }
  function _load(){
    try{ return JSON.parse(localStorage.getItem(KEY) || '[]') || []; }
    catch(e){ return []; }
  }
  function _save(list){
    localStorage.setItem(KEY, JSON.stringify(list || []));
  }
  function _id(prefix){
    return (prefix||'REQ') + '-' + Date.now().toString(36) + '-' + Math.floor(Math.random()*1e6).toString(36);
  }
  function _productId(existing){
    const set = new Set((existing||[]).map(x=>String(x.id||'')));
    let id;
    do{ id = 'P-' + Date.now().toString(36) + '-' + Math.floor(Math.random()*1e6).toString(36); }while(set.has(id));
    return id;
  }

  function _safeNum(x, fallback){
    const n = Number(x);
    return isFinite(n) ? n : (fallback ?? 0);
  }

  function _create(kind, payload){
    const list=_load();
    const req={
      id:_id('REQ'),
      kind: kind,
      status:'Pending',
      createdAt:_nowISO(),
      updatedAt:_nowISO(),
      providerId: payload.providerId || '',
      providerName: payload.providerName || '',
      providerEmail: payload.providerEmail || '',
      itemId: payload.itemId || '',
      itemDraft: payload.itemDraft || {},
      meta: payload.meta || {}
    };
    list.unshift(req);
    _save(list);
    return req;
  }

  const ItemRequestsService = {
    KEY,
    all: ()=>_load(),
    byId: (rid)=>_load().find(r=>r && r.id===rid) || null,
    byProvider: (providerId)=>_load().filter(r=>r && r.providerId===providerId),

    createAddItemRequest: function({providerId, providerName, providerEmail, itemDraft}){
      return _create('ADD_ITEM', {providerId, providerName, providerEmail, itemDraft});
    },

    createEditItemRequest: function({providerId, providerName, providerEmail, itemId, itemDraft, originalItem}){
      return _create('EDIT_ITEM', {
        providerId, providerName, providerEmail,
        itemId: itemId || '',
        itemDraft: itemDraft || {},
        meta: { originalItem: originalItem || null }
      });
    },

    createDeleteItemRequest: function({providerId, providerName, providerEmail, itemId, itemDraft}){
      return _create('DELETE_ITEM', {
        providerId, providerName, providerEmail,
        itemId: itemId || '',
        itemDraft: itemDraft || {}
      });
    },

    setStatus: function(rid, status, meta){
      const list=_load();
      const r=list.find(x=>x && x.id===rid);
      if(!r) return {ok:false, error:'Request not found'};
      r.status = status;
      r.updatedAt = _nowISO();
      if(meta && typeof meta === 'object'){
        r.meta = Object.assign({}, r.meta||{}, meta);
      }
      _save(list);
      return {ok:true, request:r};
    },

    approve: function(rid, adminName){
      const list=_load();
      const r=list.find(x=>x && x.id===rid);
      if(!r) return {ok:false, error:'Request not found'};
      if(r.status === 'Approved') return {ok:true, request:r};

      const storeOk = (global.CatalogStore && global.CatalogStore.getItems && global.CatalogStore.setItems);
      const items = storeOk ? global.CatalogStore.getItems() : [];
      const draft = r.itemDraft || {};

      if(r.kind === 'ADD_ITEM'){
        const finalImg = draft.img || draft.image || '';
        const newItem = {
          id: _productId(items),
          name: draft.name || 'Untitled',
          supplierId: r.providerId || draft.supplierId || '',
          supplierName: r.providerName || draft.supplierName || '',
          price: _safeNum(draft.price, 0),
          basePrice: _safeNum(draft.price, 0),
          stock: _safeNum(draft.stock, 0),
          category: draft.category || 'General',
          img: finalImg,
          image: finalImg,
          deliveryDays: draft.deliveryDays || { standard: 3, express: 2 },
          desc: (draft.desc || '').trim()
        };
        items.unshift(newItem);
        if(storeOk) global.CatalogStore.setItems(items);

        r.status='Approved';
        r.approvedItemId=newItem.id;
        r.updatedAt=_nowISO();
        r.meta = Object.assign({}, r.meta||{}, {approvedBy: adminName||'Admin'});
        _save(list);
        return {ok:true, request:r, item:newItem};
      }

      if(r.kind === 'EDIT_ITEM'){
        const id = r.itemId || draft.id || '';
        if(!id) return {ok:false, error:'Missing itemId on edit request'};
        const idx = items.findIndex(x => String(x.id) === String(id));
        if(idx < 0) return {ok:false, error:'Item not found (maybe deleted)'};

        const it = items[idx];
        // Ensure edits keep ownership consistent
        it.supplierId = it.supplierId || r.providerId || '';
        it.supplierName = it.supplierName || r.providerName || '';

        if(draft.name != null) it.name = String(draft.name || '').trim() || it.name;
        if(draft.category != null) it.category = String(draft.category || 'General');
        if(draft.desc != null) it.desc = String(draft.desc || '').trim();
        if(draft.price != null){
          const p = _safeNum(draft.price, it.price || 0);
          it.price = p;
          it.basePrice = p;
        }
        if(draft.stock != null) it.stock = _safeNum(draft.stock, it.stock || 0);

        const finalImg = draft.img || draft.image;
        if(finalImg != null){
          it.img = String(finalImg || '');
          it.image = String(finalImg || '');
        }

        items[idx] = it;
        if(storeOk) global.CatalogStore.setItems(items);

        r.status='Approved';
        r.approvedItemId = it.id;
        r.updatedAt=_nowISO();
        r.meta = Object.assign({}, r.meta||{}, {approvedBy: adminName||'Admin'});
        _save(list);
        return {ok:true, request:r, item:it};
      }

      if(r.kind === 'DELETE_ITEM'){
        const id = r.itemId || draft.id || '';
        if(!id) return {ok:false, error:'Missing itemId on delete request'};
        const before = items.length;
        const next = items.filter(x => String(x.id) !== String(id));
        if(storeOk && next.length !== before) global.CatalogStore.setItems(next);

        r.status='Approved';
        r.deletedItemId = id;
        r.updatedAt=_nowISO();
        r.meta = Object.assign({}, r.meta||{}, {approvedBy: adminName||'Admin'});
        _save(list);
        return {ok:true, request:r, deleted:(next.length!==before)};
      }

      return {ok:false, error:'Unknown request kind: ' + String(r.kind)};
    },

    reject: function(rid, adminName, reason){
      return this.setStatus(rid, 'Rejected', {rejectedBy: adminName||'Admin', reason: reason||''});
    },

    remove: function(rid){
      const list=_load().filter(r=>r && r.id!==rid);
      _save(list);
      return {ok:true};
    }
  };

  global.ItemRequestsService = ItemRequestsService;
})(window);
