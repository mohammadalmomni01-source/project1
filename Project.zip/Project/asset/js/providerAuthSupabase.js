import { supabase } from "./supabaseClient.js";

async function getProfile(uid) {
    const { data, error } = await supabase
        .from("profiles")
        .select("full_name, role")
        .eq("id", uid)
        .single();
    if (error) return null;
    return data || null;
}

function setLegacyProviderSession({ id, email, name }) {
    try {
        localStorage.setItem("providerLoggedIn", "true");
        localStorage.setItem("providerEmail", email || "");
        localStorage.setItem("providerName", name || "Service Provider");

        let pid = localStorage.getItem("providerId");
        if (!pid) {
            const short = String(id || "").replace(/-/g, "").slice(0, 6).toUpperCase();
            pid = "S-" + (short || (1000 + Math.floor(Math.random() * 9000)));
            localStorage.setItem("providerId", pid);
        }
    } catch (_) { }
}

async function rejectAndLogout(message) {
    try {
        await supabase.auth.signOut();
    } catch (_) { }

    try {
        localStorage.removeItem("providerLoggedIn");
        localStorage.removeItem("providerEmail");
        localStorage.removeItem("providerName");
        localStorage.removeItem("providerId");
    } catch (_) { }

    return { ok: false, error: message };
}

window.__providerLogin = async (email, password) => {
    const normalizedEmail = (email || "").trim().toLowerCase();

    const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password,
    });

    if (error || !data?.session) {
        return { ok: false, error: error?.message || "Login failed" };
    }

    const profile = await getProfile(data.user.id);
    const role = profile?.role;

    if (role === "provider") {
        setLegacyProviderSession({
            id: data.user.id,
            email: data.user.email || normalizedEmail,
            name: profile.full_name || "Service Provider",
        });
        return { ok: true };
    }

    if (role === "pending_provider") {
        return await rejectAndLogout("Pending admin approval");
    }

    if (role === "rejected_provider") {
        return await rejectAndLogout("Rejected");
    }

    return await rejectAndLogout("Not authorized as provider");
};

window.__providerLogout = async (redirectTo) => {
    await supabase.auth.signOut();
    if (redirectTo) window.location.href = redirectTo;
};

window.__providerRequireSession = async (redirectTo) => {
    const { data } = await supabase.auth.getSession();
    const session = data?.session;

    if (!session) {
        window.location.href = redirectTo;
        return false;
    }

    const profile = await getProfile(session.user.id);
    if (profile?.role !== "provider") {
        await rejectAndLogout("Not authorized as provider");
        window.location.href = redirectTo;
        return false;
    }

    setLegacyProviderSession({
        id: session.user.id,
        email: session.user.email || "",
        name: profile.full_name || "Service Provider",
    });

    return true;
};
