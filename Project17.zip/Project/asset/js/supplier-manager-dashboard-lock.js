export function applySupplierManagerDashboardLock({ setEmployeeViews, showView } = {}) {
    const providerRequestsView = document.getElementById('view-providerRequests');
    const defaultView = providerRequestsView ? 'providerRequests' : 'providers';

    if (typeof setEmployeeViews === 'function') {
        setEmployeeViews(['providers', 'providerRequests', 'itemRequests', 'providerMessages'], defaultView);
    }

    const btnDashboard = document.getElementById('nav-dashboard');
    if (btnDashboard) btnDashboard.disabled = true;

    const btnOrders = document.getElementById('nav-orders');
    if (btnOrders) btnOrders.disabled = true;

    const btnUsers = document.getElementById('nav-users');
    if (btnUsers) btnUsers.disabled = true;

    const btnProviders = document.getElementById('nav-providers');
    if (btnProviders) btnProviders.disabled = false;

    const btnProviderRequests = document.getElementById('nav-providerRequests');
    if (btnProviderRequests) btnProviderRequests.disabled = false;

    const btnItemRequests = document.getElementById('nav-itemRequests');
    if (btnItemRequests) btnItemRequests.disabled = false;

    const btnSupport = document.getElementById('nav-support');
    if (btnSupport) btnSupport.disabled = true;

    const btnProviderMessages = document.getElementById('nav-providerMessages');
    if (btnProviderMessages) btnProviderMessages.disabled = false;

    const quickViewOrders = document.getElementById('btn-viewOrders');
    if (quickViewOrders) quickViewOrders.disabled = true;

    const quickManageUsers = document.getElementById('btn-manageUsers');
    if (quickManageUsers) quickManageUsers.disabled = true;

    const quickManageProviders = document.getElementById('btn-manageProviders');
    if (quickManageProviders) quickManageProviders.disabled = false;

    const allowed = new Set(['providers', 'providerRequests', 'itemRequests', 'providerMessages']);
    const forceAllowedDefault = () => {
        if (typeof showView === 'function') showView(defaultView);
    };

    const lockForbiddenView = () => {
        const current = (window.location.hash || '').replace('#view-', '').trim();
        if (current && !allowed.has(current)) {
            forceAllowedDefault();
        }
    };

    const originalShowView = typeof showView === 'function' ? showView : null;
    if (originalShowView) {
        window.showView = (which) => {
            if (!allowed.has(which)) {
                return originalShowView(defaultView);
            }
            return originalShowView(which);
        };
    }

    window.addEventListener('hashchange', lockForbiddenView);
    lockForbiddenView();
}
