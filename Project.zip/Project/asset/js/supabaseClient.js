import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const url = (window.SUPABASE_URL || "https://ranqskqvcpywcnekhvfs.supabase.co").trim();
const key = (window.SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhbnFza3F2Y3B5d2NuZWtodmZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MjczODQsImV4cCI6MjA4NjQwMzM4NH0.0nypi0ARFvfjm0mIC02pFO9fwdUL0PI5bru_amanq34").trim();

if (!url || !key) {
    console.warn("Supabase is not configured. Set SUPABASE_URL and SUPABASE_ANON_KEY in asset/js/supabase-config.js");
}

export const supabase = createClient(url, key, {
    auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
    },
});
