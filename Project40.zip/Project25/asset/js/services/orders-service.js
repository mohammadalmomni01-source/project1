(function () {
    async function _sb() {
        if (window.supabaseClient) return window.supabaseClient;
        if (window._supabaseForEmployee) return window._supabaseForEmployee;
        
        if (!window.__supabase && window.supabase && window.SUPABASE_URL) {
            window.__supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY, {
                auth: { persistSession: true, autoRefreshToken: true }
            });
        }
        let retries = 20;
        while (!window.__supabase && !window.supabaseClient && !window._supabaseForEmployee && retries > 0) {
            await new Promise(r => setTimeout(r, 250));
            retries--;
        }
        if (window.supabaseClient) return window.supabaseClient;
        if (window._supabaseForEmployee) return window._supabaseForEmployee;
        if (!window.__supabase) console.error("[OrdersService] Supabase client failed to initialize in time.");
        return window.__supabase;
    }

    async function getById(orderId) {
        const sb = await _sb(); if (!sb) return null;
        const cleanId = String(orderId || '').trim();
        try {
            const res = await sb.functions.invoke('provider-orders-get',
                { body: { order_id: cleanId } });
            if (!res.error && res.data) return res.data.order || res.data;
        } catch (e) { }
        const { data, error } = await sb.from('orders')
            .select('*, order_items(*)').eq('id', cleanId).maybeSingle();
        if (error) console.error("OrdersService.getById Error:", error);
        return error ? null : data;
    }

    async function updateStatus(orderId, toStatus, actor) {
        console.log("[OrdersService.updateStatus] Start", {orderId, toStatus});
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        const to = String(toStatus || 'pending').toLowerCase();

        if (actor?.role === 'provider') {
            console.log("[OrdersService.updateStatus] Provider role, calling edge function...");
            const res = await sb.functions.invoke('provider-orders-update-status',
                { body: { order_id: orderId, status: to } });
            console.log("[OrdersService.updateStatus] Edge function responded:", res);
            if (res.error) return { ok: false, error: res.error.message };
            return { ok: true, order: res.data?.order || null };
        }

        console.log("[OrdersService.updateStatus] Updating status in DB...");
        const { error } = await sb.from('orders')
            .update({ status: to, updated_at: new Date().toISOString() })
            .eq('id', orderId);
        console.log("[OrdersService.updateStatus] DB update responded:", {error});
        if (error) return { ok: false, error: error.message };

        console.log("[OrdersService.updateStatus] Logging event...");
        await sb.from('order_events').insert({
            order_id: orderId,
            actor_role: (actor?.role === 'employee' || actor?.role === 'order_support') ? 'admin' : (actor?.role || 'admin'),
            actor_id: actor?.id || null,
            event_type: 'status_change',
            message: `Status updated to ${to}`,
            meta: { to }
        });
        console.log("[OrdersService.updateStatus] Event logged.");

        return { ok: true };
    }

    async function cancel(orderId, actor) {
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        const { data: ord } = await sb.from('orders')
            .select('status').eq('id', orderId).maybeSingle();
        if (!ord) return { ok: false, error: 'Order not found' };
        const st = (ord.status || '').toLowerCase();
        if (actor?.role === 'customer' && !['pending', 'confirmed'].includes(st))
            return { ok: false, error: 'This order can no longer be cancelled.' };
        return updateStatus(orderId, 'Cancelled', actor);
    }

    async function confirmDelivered(orderId, actor) {
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        const { data: ord } = await sb.from('orders')
            .select('status').eq('id', orderId).maybeSingle();
        if (!ord) return { ok: false, error: 'Order not found' };
        if ((ord.status || '').toLowerCase() !== 'shipped')
            return { ok: false, error: 'You can confirm delivery only after the order is shipped.' };
        return updateStatus(orderId, 'Delivered', actor);
    }

    async function updateOrder(orderId, patch, actor) {
        console.log("[OrdersService.updateOrder] Start", {orderId, patch});
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        const p = patch || {};

        if (actor?.role === 'provider') {
            console.log("[OrdersService.updateOrder] Provider role, calling edge function...");
            const res = await sb.functions.invoke('provider-orders-update',
                { body: { order_id: orderId, ...p } });
            if (res.error) return { ok: false, error: res.error.message };
            return { ok: true };
        }

        const safe = { updated_at: new Date().toISOString() };
        if (p.payment != null) safe.payment_method = p.payment;
        if (p.delivery != null) safe.delivery_method = p.delivery;
        if (p.customerName != null) safe.shipping_full_name = p.customerName;
        if (p.customerPhone != null) safe.shipping_phone = p.customerPhone;
        if (p.subtotal != null) safe.subtotal = p.subtotal;
        if (p.tax != null) safe.tax = p.tax;
        if (p.deliveryFee != null) safe.delivery_fee = p.deliveryFee;
        if (p.total != null) safe.total = p.total;
        if (p.shipping) {
            const s = p.shipping;
            if (s.name != null) safe.shipping_full_name = s.name;
            if (s.phone != null) safe.shipping_phone = s.phone;
            if (s.country != null) safe.shipping_country = s.country;
            if (s.city != null) safe.shipping_city = s.city;
            if (s.address != null || s.addr != null)
                safe.shipping_address = s.address || s.addr;
            if (s.notes != null) safe.shipping_notes = s.notes;
        }
        console.log("[OrdersService.updateOrder] Updating DB with payload:", safe);
        const { error } = await sb.from('orders').update(safe).eq('id', orderId);
        console.log("[OrdersService.updateOrder] DB responded:", {error});
        
        // Log event if update was successful
        if (!error && actor) {
            console.log("[OrdersService.updateOrder] Logging event...");
            await sb.from('order_events').insert({
                order_id: orderId,
                actor_role: (actor?.role === 'employee' || actor?.role === 'order_support') ? 'admin' : (actor?.role || 'admin'),
                actor_id: actor.id || null,
                event_type: 'update',
                message: 'Order details updated',
                meta: { patch: Object.keys(p) }
            });
            console.log("[OrdersService.updateOrder] Event logged.");
        }

        return error ? { ok: false, error: error.message } : { ok: true };
    }

    async function updateOrderItems(orderId, lines) {
        console.log("[OrdersService.updateOrderItems] Start", {orderId, linesCount: lines?.length});
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };

        // Fetch existing items first so we can preserve product_ids
        console.log("[OrdersService.updateOrderItems] Fetching existing items...");
        const { data: existing, error: fetchErr } = await sb.from('order_items').select('*').eq('order_id', orderId);
        if (fetchErr) console.warn("[OrdersService.updateOrderItems] Fetch existing failed:", fetchErr);

        // Delete existing items
        console.log("[OrdersService.updateOrderItems] Deleting old items...");
        const { error: delErr } = await sb.from('order_items').delete().eq('order_id', orderId);
        if (delErr) {
            console.error("[OrdersService.updateOrderItems] Delete failed:", delErr);
            return { ok: false, error: delErr.message };
        }

        if (!lines || lines.length === 0) return { ok: true };

        // Insert new items
        const rows = lines.map(l => {
            const q = Number(l.qty || 0);
            const u = Number(l.unitPrice || 0);
            const name = l.itemId || l.productName || '';
            
            let pid = l.productId;
            // If frontend forgot the productId (due to cache), recover it from the database
            if (!pid || pid === '00000000-0000-0000-0000-000000000000' || pid === 'undefined') {
                const match = (existing || []).find(e => e.product_name === name || e.product_id === l.itemId);
                if (match && match.product_id) {
                    pid = match.product_id;
                } else {
                    pid = null; // Use null so it doesn't violate foreign key if it's a custom item
                }
            }
            if (pid === '00000000-0000-0000-0000-000000000000') pid = null;

            return {
                order_id: orderId,
                product_id: pid, // Null if truly custom
                product_name: name,
                qty: q,
                unit_price: u,
                line_total: q * u
            };
        });

        console.log("[OrdersService.updateOrderItems] Inserting new items:", rows);
        const { error: insErr } = await sb.from('order_items').insert(rows);
        console.log("[OrdersService.updateOrderItems] Insert responded:", {error: insErr});
        return insErr ? { ok: false, error: insErr.message } : { ok: true };
    }

    // Fetch order_events for an order (history / timeline)
    async function getOrderEvents(orderId) {
        const sb = await _sb(); if (!sb) return [];
        const { data, error } = await sb.from('order_events')
            .select('*').eq('order_id', orderId).order('created_at', { ascending: true });
        return error ? [] : (data || []);
    }

    async function remove(orderId) {
        const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
        // Delete items first (Supabase usually handles cascades, but doing it manually is safe)
        await sb.from('order_items').delete().eq('order_id', orderId);
        // Delete order events
        await sb.from('order_events').delete().eq('order_id', orderId);
        // Delete the order itself
        const { error } = await sb.from('orders').delete().eq('id', orderId);
        return error ? { ok: false, error: error.message } : { ok: true };
    }

    async function listAll() {
        console.log("[OrdersService.listAll] Start");
        const sb = await _sb(); if (!sb) return [];
        console.log("[OrdersService.listAll] Querying database (cache-busted)...");
        const { data, error } = await sb.from('orders')
            .select('*, order_items(*)')
            .order('created_at', { ascending: false });
        
        if (error) {
            console.error("[OrdersService.listAll] Failed:", error);
            return [];
        }

        // The orders table doesn't natively store email, so we fetch it from the profiles table
        if (data && data.length > 0) {
            const customerIds = [...new Set(data.map(o => o.customer_id).filter(Boolean))];
            if (customerIds.length > 0) {
                const { data: profs } = await sb.from('profiles').select('id, email').in('id', customerIds);
                if (profs) {
                    const profMap = {};
                    profs.forEach(p => profMap[p.id] = p.email);
                    data.forEach(o => {
                        if (!o.customer_email) o.customer_email = profMap[o.customer_id] || '';
                        o.customerEmail = o.customer_email;
                    });
                }
            }
        }

        console.log("[OrdersService.listAll] Loaded orders:", data?.length);
        return data || [];
    }

    async function adminUpdateOrder(orderId, patch, items, status, actor) {
        console.log("[OrdersService] Starting adminUpdateOrder (DEBUG-Y) for:", orderId);
        try {
            // 1. Update fields
            if (patch && Object.keys(patch).length > 0) {
                console.log("[OrdersService] Updating order fields:", patch);
                const res = await updateOrder(orderId, patch, actor || { role: 'admin' });
                if (!res.ok) throw new Error("Field update failed: " + res.error);
            }
            // 2. Update items
            if (Array.isArray(items)) {
                console.log("[OrdersService] Updating order items:", items);
                const res = await updateOrderItems(orderId, items);
                if (!res.ok) throw new Error("Item update failed: " + res.error);
            }
            // 3. Update status
            if (status) {
                console.log("[OrdersService] Updating order status:", status);
                const res = await updateStatus(orderId, status, actor || { role: 'admin' });
                if (!res.ok) throw new Error("Status update failed: " + res.error);
            }
            
            console.log("[OrdersService] All steps succeeded. Fetching updated order...");
            const sb = await _sb();
            const { data, error } = await sb.from('orders').select('*, order_items(*)').eq('id', orderId).maybeSingle();
            if (error) throw new Error("Final fetch failed: " + error.message);
            
            return { ok: true, order: data };
        } catch (e) {
            console.error("[OrdersService] adminUpdateOrder CRASHED:", e);
            return { ok: false, error: e.message };
        }
    }

    window.OrdersService = {
        getById, updateStatus, cancel, confirmDelivered,
        updateOrder, updateOrderItems, getOrderEvents, remove, listAll,
        adminUpdateOrder
    };
})();
