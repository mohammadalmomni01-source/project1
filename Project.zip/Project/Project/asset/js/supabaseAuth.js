import { supabase } from "./supabaseClient.js";

export async function getSession() {
  const { data } = await supabase.auth.getSession();
  return data?.session || null;
}

export async function getMyRole() {
  const session = await getSession();
  if (!session) return null;

  const { data, error } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", session.user.id)
    .single();

  if (error) return null;
  return data?.role || null;
}

export async function requireRole(role, redirectTo) {
  const session = await getSession();
  if (!session) {
    window.location.href = redirectTo;
    return false;
  }
  const myRole = await getMyRole();
  if (myRole !== role) {
    await supabase.auth.signOut();
    window.location.href = redirectTo;
    return false;
  }
  return true;
}

export async function signOut(redirectTo) {
  await supabase.auth.signOut();
  if (redirectTo) window.location.href = redirectTo;
}
