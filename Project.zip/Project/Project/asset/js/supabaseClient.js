// asset/js/supabaseClient.js
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const url = window.SUPABASE_URL;
const key = window.SUPABASE_ANON_KEY;

if (!url || !key) {
    console.warn("Supabase keys are not set. Edit asset/js/supabase-config.js");
}

export const supabase = createClient(url, key, {
    auth: { persistSession: true, autoRefreshToken: true },
});

