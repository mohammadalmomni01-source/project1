(function(){
  function _loadOrders(){
    if(!window.CustomerStore) return [];
    return CustomerStore.load(CustomerStore.K.orders, []);
  }
  function _saveOrders(list){
    if(!window.CustomerStore) return;
    CustomerStore.save(CustomerStore.K.orders, list);
  }

  function getById(orderId){
    const all = _loadOrders();
    return all.find(o=> String(o.id) === String(orderId)) || null;
  }

  function _computeTimeline(order, newStatus, now){
    if(!order) return;
    const ns = window.OrderStatus ? OrderStatus.normalizeStatus(newStatus) : String(newStatus||'Pending');
    order.timeline = Array.isArray(order.timeline) ? order.timeline : [];

    // Ensure common steps exist
    const want = ['Pending','Confirmed','Preparing','Shipped','Delivered'];
    for(const w of want){
      if(!order.timeline.find(t => String(t.label||t.status||'') === w)){
        order.timeline.push({label:w, at:null});
      }
    }
    const hit = order.timeline.find(t => (window.OrderStatus ? OrderStatus.normalizeStatus(t.label||t.status||'') : (t.label||t.status)) === ns);
    if(hit && !hit.at) hit.at = now;
  }

  function _pushHistory(order, from, to, now, byRole, byId){
    order.statusHistory = Array.isArray(order.statusHistory) ? order.statusHistory : [];
    order.statusHistory.push({
      from, to, at: now,
      byRole: byRole || null,
      byId: byId || null
    });
  }

  function _updateOrder(orderId, updater){
    const all = _loadOrders();
    const idx = all.findIndex(o=> String(o.id) === String(orderId));
    if(idx < 0) return {ok:false, error:'Order not found'};
    const o = all[idx];

    const res = updater(o);
    // If updater explicitly returned {ok:false,...} then do NOT persist.
    if(res && typeof res === 'object' && res.ok === false){
      return res;
    }

    all[idx] = o;
    _saveOrders(all);
    return {ok:true, order:o, result:res};
  }


  function updateStatus(orderId, toStatus, actor){
    const to = window.OrderStatus ? OrderStatus.normalizeStatus(toStatus) : String(toStatus||'Pending');
    return _updateOrder(orderId, (order)=>{
      const from = window.OrderStatus ? OrderStatus.normalizeStatus(order.status) : String(order.status||'Pending');

      // Provider guard (only enforce for provider actor)
      if(actor && actor.role === 'provider' && window.OrderStatus){
        if(!OrderStatus.canProviderTransition(from, to)){
          return {ok:false, error:`Invalid transition ${from} -> ${to}`};
        }
      }

      order.status = to;
      order.updatedAt = new Date().toISOString();
      _computeTimeline(order, to, order.updatedAt);
      _pushHistory(order, from, to, order.updatedAt, actor?.role, actor?.id);

      // System message (optional)
      if(window.MessagesService){
        const num = order.orderNumber || order.id;
        MessagesService.system(order.id, `Status updated for order ${num}: ${from} → ${to}.`);
      }
      return {ok:true};
    });
  }

  function cancel(orderId, actor){
    // Customer: only Pending/Confirmed
    const ord = getById(orderId);
    if(!ord) return {ok:false, error:'Order not found'};
    const st = window.OrderStatus ? OrderStatus.normalizeStatus(ord.status) : String(ord.status||'Pending');
    if(actor?.role === 'customer' && window.OrderStatus && !OrderStatus.customerCanCancel(st)){
      return {ok:false, error:'This order can no longer be cancelled.'};
    }
    if(actor?.role === 'provider' && window.OrderStatus && !OrderStatus.canProviderTransition(st,'Cancelled')){
      return {ok:false, error:'This order can no longer be cancelled.'};
    }
    return updateStatus(orderId, 'Cancelled', actor);
  }

  function confirmDelivered(orderId, actor){
    const ord = getById(orderId);
    if(!ord) return {ok:false, error:'Order not found'};
    const st = window.OrderStatus ? OrderStatus.normalizeStatus(ord.status) : String(ord.status||'Pending');
    if(actor?.role === 'customer' && window.OrderStatus && !OrderStatus.customerCanConfirmDelivered(st)){
      return {ok:false, error:'You can confirm delivery only after the order is shipped.'};
    }
    return updateStatus(orderId, 'Delivered', actor);
  }

  // Recalculate totals from lines (keeps delivery fee, uses existing tax rate if present)
  function _recalcTotals(order){
    if(!order) return;
    const lines = Array.isArray(order.lines) ? order.lines : [];
    let subtotal = 0;
    for(const l of lines){
      const qty = Number(l.qty||0);
      const unit = Number((l.unitPrice ?? l.price ?? 0));
      subtotal += qty * unit;
    }

    order.totals = (order.totals && typeof order.totals === 'object') ? order.totals : {};
    const taxRate = (order.totals.taxRate != null)
      ? Number(order.totals.taxRate)
      : (window.CustomerStore ? Number(CustomerStore.TAX_RATE || 0) : 0);
    const deliveryFee = Number(order.totals.deliveryFee ?? order.deliveryFee ?? 0);
    const tax = Number.isFinite(taxRate) ? (subtotal * taxRate) : Number(order.totals.tax ?? 0);
    const total = subtotal + tax + deliveryFee;

    order.totals.subtotal = subtotal;
    order.totals.tax = tax;
    order.totals.deliveryFee = deliveryFee;
    order.totals.total = total;
    order.total = total;
  }

  function updateOrder(orderId, patch, actor){
    const p = (patch && typeof patch === 'object') ? patch : {};
    return _updateOrder(orderId, (order)=>{
      // Basic access guard for provider
      if(actor && actor.role === 'provider'){
        if(String(order.supplierId||'') !== String(actor.id||'')){
          return {ok:false, error:'You do not have access to this order.'};
        }
      }

      // Apply patch (only allow known top-level fields)
      if(p.payment != null) order.payment = String(p.payment||'');
      if(p.delivery != null) order.delivery = String(p.delivery||'');
      if(p.expectedDate != null) order.expectedDate = String(p.expectedDate||'');

      if(p.shipping && typeof p.shipping === 'object'){
        order.shipping = (order.shipping && typeof order.shipping === 'object') ? order.shipping : {};
        const s = p.shipping;
        for(const k of ['name','phone','addr','address','country','countryCode','city','location','notes']){
          if(s[k] != null) order.shipping[k] = s[k];
        }
      }

      if(Array.isArray(p.lines)){
        // Normalize lines
        order.lines = p.lines
          .map(l=>({
            itemId: (l.itemId ?? l.id ?? l.productId) != null ? String(l.itemId ?? l.id ?? l.productId) : '',
            qty: Math.max(1, Number(l.qty||1)),
            unitPrice: Math.max(0, Number(l.unitPrice ?? l.price ?? 0))
          }))
          .filter(l=>l.itemId);
      }

      // Recompute totals after edits
      _recalcTotals(order);

      order.updatedAt = new Date().toISOString();

      // System message
      if(window.MessagesService){
        const num = order.orderNumber || order.id;
        const who = actor?.role ? actor.role : 'system';
        MessagesService.system(order.id, `Order ${num} updated by ${who}.`);
      }

      return {ok:true};
    });
  }
  function remove(orderId, opts){
    const options = opts && typeof opts === 'object' ? opts : {};
    const all = _loadOrders();
    const idx = all.findIndex(o => String(o.id) === String(orderId));
    if(idx < 0) return {ok:false, error:'Order not found'};
    const removed = all.splice(idx, 1)[0];
    _saveOrders(all);

    // Remove message thread for this order (optional; default true)
    const rmMsgs = (options.removeMessages !== false);
    if(rmMsgs && window.CustomerStore){
      const db = CustomerStore.load(CustomerStore.K.messages, {});
      if(db && typeof db === 'object' && db[String(orderId)]){
        delete db[String(orderId)];
        CustomerStore.save(CustomerStore.K.messages, db);
      }
    }
    return {ok:true, removed};
  }


  window.OrdersService = { getById, updateStatus, cancel, confirmDelivered, updateOrder, remove };
})();
