import { supabase } from "./supabaseClient.js";

function saveLocalSession(partial) {
    try {
        if (!window.CustomerStore) return;
        const s = window.CustomerStore.load(window.CustomerStore.K.session, null) || {};
        window.CustomerStore.save(window.CustomerStore.K.session, { ...s, ...partial });
    } catch (e) { }
}

function clearCustomerLocalState() {
    try {
        if (window.CustomerStore) {
            window.CustomerStore.save(window.CustomerStore.K.session, null);
        }
    } catch (e) { }

    try {
        sessionStorage.removeItem("customer_signup_email");
    } catch (e) { }
}

function stripOAuthCallbackParamsFromUrl() {
    try {
        const url = new URL(window.location.href);
        const oauthKeys = ["code", "state", "access_token", "refresh_token", "token_type", "expires_at", "expires_in"];
        let changed = false;
        oauthKeys.forEach((k) => {
            if (url.searchParams.has(k)) {
                url.searchParams.delete(k);
                changed = true;
            }
        });
        if (window.location.hash && /(access_token|refresh_token|token_type|expires_at|expires_in)/i.test(window.location.hash)) {
            url.hash = "";
            changed = true;
        }
        if (changed) {
            window.history.replaceState({}, document.title, url.pathname + url.search + url.hash);
        }
    } catch (e) { }
}

async function getProfile(uid) {
    const { data, error } = await supabase
        .from("profiles")
        .select("full_name, role, org_type")
        .eq("id", uid)
        .single();
    if (error) return null;
    return data || null;
}

async function signUpWithMetadata(email, password, metadata) {
    const emailRedirectTo = getCustomerVerifyRedirectUrl();
    const first = await supabase.auth.signUp({
        email,
        password,
        options: {
            data: metadata,
            emailRedirectTo
        }
    });

    const msg = (first?.error?.message || "").toLowerCase();
    if (first?.error && msg.includes("redirect")) {
        return await supabase.auth.signUp({
            email,
            password,
            options: { data: metadata }
        });
    }

    return first;
}


function getCustomerVerifyRedirectUrl() {
    try {
        return new URL("customer-verify-email.html", window.location.href).toString();
    } catch (e) {
        return undefined;
    }
}

function getCustomerLoginRedirectUrl() {
    try {
        return new URL("customer-login.html", window.location.href).toString();
    } catch (e) {
        return undefined;
    }
}

function mapSignupError(error) {
    const raw = (error?.message || "Signup failed").trim();
    const m = raw.toLowerCase();

    if (m.includes("error sending confirmation email") || m.includes("sending confirmation email") || m.includes("smtp") || m.includes("mail")) {
        return "We could not send the verification email right now. Please try again in a moment.";
    }

    return raw;
}

function isEmailUnverifiedError(message) {
    const m = (message || "").toLowerCase();
    return (
        m.includes("email not confirmed") ||
        m.includes("email not verified") ||
        m.includes("confirm your email") ||
        m.includes("not confirmed")
    );
}

window.__customerLogin = async (email, password) => {
    email = (email || "").trim().toLowerCase();

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data?.session) {
        if (isEmailUnverifiedError(error?.message)) {
            return { ok: false, error: "Please verify your email first before logging in." };
        }
        return { ok: false, error: error?.message || "Login failed" };
    }

    const prof = await getProfile(data.user.id);
    if (!prof) {
        await supabase.auth.signOut();
        return {
            ok: false,
            error: "Your email is verified, but your account setup is not finished. Please complete verification again."
        };
    }

    if (prof.role !== "customer") {
        await supabase.auth.signOut();
        return { ok: false, error: "Not authorized" };
    }

    saveLocalSession({
        loggedIn: true,
        id: data.user.id,
        email,
        name: prof.full_name || "Customer",
        orgType: prof.org_type || null
    });

    return { ok: true, orgType: prof.org_type || null };
};

window.__customerSignup = async (email, password, name) => {
    email = (email || "").trim().toLowerCase();
    name = (name || "").trim();

    let { data, error } = await signUpWithMetadata(email, password, {
        full_name: name,
        role: "customer",
        signup_kind: "customer"
    });

    if (error && /database error saving new user/i.test(error.message || "")) {
        const retry = await signUpWithMetadata(email, password, {
            full_name: name,
            signup_kind: "customer"
        });
        data = retry.data;
        error = retry.error;
    }

    if (error) {
        const message = error.message || "Signup failed";
        if (/already registered|user already exists|already been registered/i.test(message)) {
            return { ok: false, error: "This email is already registered. Please log in or verify your email first." };
        }
        return { ok: false, error: mapSignupError(error) };
    }

    if (!data?.user) {
        return { ok: false, error: "Signup failed. Please try again." };
    }

    return {
        ok: true,
        otpRequired: true,
        email
    };
};

export async function customerVerifySignupOtp(email, otp) {
    email = (email || "").trim().toLowerCase();
    otp = (otp || "").trim();

    if (!email || !otp) {
        return { ok: false, error: "Email and verification code are required." };
    }

    // Supabase JS v2 verifyOtp email-signup type: "signup"
    const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: otp,
        type: "signup"
    });

    if (error) {
        const message = (error.message || "").toLowerCase();
        if (message.includes("token has expired") || message.includes("otp has expired") || message.includes("expired")) {
            return { ok: false, error: "This verification code expired. Please request a new one." };
        }
        if (message.includes("invalid") || message.includes("token") || message.includes("otp")) {
            return { ok: false, error: "The verification code is incorrect. Please try again." };
        }
        return { ok: false, error: error.message || "OTP verification failed." };
    }

    let session = data?.session || null;
    let user = data?.user || session?.user || null;

    if (!session) {
        const sessRes = await supabase.auth.getSession();
        session = sessRes?.data?.session || null;
        user = user || session?.user || null;
    }

    if (!session || !user?.id) {
        return {
            ok: false,
            error: "Verification succeeded, but we could not start your session. Please log in."
        };
    }

    return { ok: true, email: user.email || email };
}

export async function customerFinalizeSignup() {
    const { data: sData } = await supabase.auth.getSession();
    const session = sData?.session;
    if (!session) return { ok: false, error: "Not logged in" };

    const { data, error } = await supabase.functions.invoke("finalize-customer-signup", {
        body: {}
    });

    if (error) {
        return { ok: false, error: error.message || "Could not finalize your account." };
    }

    if (!data?.ok) {
        return { ok: false, error: data?.error || "Could not finalize your account." };
    }

    const prof = await getProfile(session.user.id);
    if (!prof || prof.role !== "customer") {
        await supabase.auth.signOut();
        return { ok: false, error: "Your customer profile is not ready yet. Please try again." };
    }

    saveLocalSession({
        loggedIn: true,
        id: session.user.id,
        email: session.user.email,
        name: prof.full_name || "Customer",
        orgType: prof.org_type || null
    });

    return { ok: true, orgType: prof.org_type || null };
}

export async function customerResendSignupOtp(email) {
    email = (email || "").trim().toLowerCase();
    if (!email) return { ok: false, error: "Email is required." };

    // Supabase JS v2 resend email-signup verification type: "signup"
    const { error } = await supabase.auth.resend({
        type: "signup",
        email,
        options: {
            emailRedirectTo: getCustomerVerifyRedirectUrl()
        }
    });

    if (error) {
        const message = (error.message || "").toLowerCase();
        if (message.includes("already confirmed") || message.includes("already verified")) {
            return { ok: false, error: "This email is already verified. Please log in." };
        }
        return { ok: false, error: error.message || "Unable to resend verification code." };
    }

    return { ok: true, message: "A new verification code was sent to your email." };
}

window.__customerVerifySignupOtp = customerVerifySignupOtp;
window.__customerFinalizeSignup = customerFinalizeSignup;
window.__customerResendSignupOtp = customerResendSignupOtp;

window.__customerGoogleLogin = async () => {
    const redirectTo = getCustomerLoginRedirectUrl();
    const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo }
    });

    if (error) {
        return { ok: false, error: error.message || "Google sign-in failed." };
    }

    return { ok: true };
};

window.__customerHandleOAuthReturn = async () => {
    const { data } = await supabase.auth.getSession();
    const session = data?.session;
    if (!session) return { ok: false, noSession: true };

    const prof = await getProfile(session.user.id);
    if (!prof) {
        await supabase.auth.signOut();
        return {
            ok: false,
            error: "Your Google account signed in, but no customer profile was found. Use your customer account or contact support."
        };
    }

    if (prof.role !== "customer") {
        await supabase.auth.signOut();
        return { ok: false, error: "Not authorized" };
    }

    saveLocalSession({
        loggedIn: true,
        id: session.user.id,
        email: session.user.email,
        name: prof.full_name || "Customer",
        orgType: prof.org_type || null
    });

    try { sessionStorage.removeItem("customer_just_logged_out"); } catch (e) { }
    stripOAuthCallbackParamsFromUrl();
    return { ok: true, orgType: prof.org_type || null };
};

window.__customerSetOrgType = async (orgType) => {
    const { data } = await supabase.auth.getSession();
    const sess = data?.session;
    if (!sess) return { ok: false, error: "Not logged in" };

    const { error } = await supabase
        .from("profiles")
        .update({ org_type: orgType })
        .eq("id", sess.user.id);

    if (error) return { ok: false, error: error.message };

    saveLocalSession({ orgType });
    return { ok: true };
};

window.__customerRequireSession = async (redirectTo) => {
    const { data } = await supabase.auth.getSession();
    if (!data?.session) {
        window.location.href = redirectTo;
        return false;
    }

    const prof = await getProfile(data.session.user.id);
    if (!prof || prof.role !== "customer") {
        await supabase.auth.signOut();
        window.location.href = redirectTo;
        return false;
    }

    saveLocalSession({
        loggedIn: true,
        id: data.session.user.id,
        email: data.session.user.email,
        name: prof.full_name || "Customer",
        orgType: prof.org_type || null
    });

    return true;
};

window.__customerLogout = async (redirectTo) => {
    const target = redirectTo || "customer-login.html?logout=1";

    clearCustomerLocalState();

    try {
        await supabase.auth.signOut({ scope: "local" });
    } catch (e) {
        try { await supabase.auth.signOut(); } catch (e2) { }
    }

    try {
        const { data } = await supabase.auth.getSession();
        if (data?.session) {
            try { await supabase.auth.signOut(); } catch (e3) { }
        }
    } catch (e) { }

    clearCustomerLocalState();
    try { sessionStorage.setItem("customer_just_logged_out", "1"); } catch (e) { }
    window.location.href = target;
};
