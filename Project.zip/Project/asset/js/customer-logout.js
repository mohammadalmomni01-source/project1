import "./customerAuthSupabase.js";
const btn = document.getElementById("btn-logout") || document.getElementById("logoutBtn");
if (btn) btn.addEventListener("click", async () => {
    await window.__customerLogout("../customer/customer-login.html");
});
