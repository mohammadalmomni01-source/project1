import "./supabaseClient.js";
import "./customerAuthSupabase.js";

await window.__customerRequireSession("customer-login.html");
