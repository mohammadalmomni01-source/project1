import { supabase } from "./supabaseClient.js";

export async function requireRole(requiredRole, loginPath) {
    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;

    if (!session) {
        window.location.href = loginPath;
        return null;
    }

    const { data: profile, error } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", session.user.id)
        .single();

    if (error || !profile || profile.role !== requiredRole) {
        await supabase.auth.signOut();
        window.location.href = loginPath;
        return null;
    }

    return session;
}
