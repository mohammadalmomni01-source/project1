import { supabase } from "./supabaseClient.js";

export async function getSession() {
    const { data } = await supabase.auth.getSession();
    return data?.session || null;
}

export async function getMyRole() {
    const profile = await getMyProfile();
    return profile?.role ? String(profile.role).trim() : null;
}

export async function getMyProfile() {
    const session = await getSession();
    if (!session) return null;

    const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", session.user.id)
        .single();

    if (error) {
        console.error("[Auth] Error fetching profile:", error.message || error);
        return null;
    }
    return data;
}

export async function requireRole(role, redirectTo) {
    console.log("[Auth] Checking role:", role);
    const session = await getSession();
    if (!session) {
        console.warn("[Auth] No active session found. Redirecting to:", redirectTo);
        window.location.href = redirectTo;
        return false;
    }
    
    console.log("[Auth] Session found for:", session.user.email);
    const rawRole = await getMyRole();
    const myRole = (rawRole || "").toLowerCase().trim();
    const roles = (Array.isArray(role) ? role : [role]).map(r => String(r).toLowerCase().trim());
    
    console.log(`[Auth] User role: "${rawRole}", expected:`, roles);
    
    if (!roles.includes(myRole)) {
        console.warn(`[Auth] Role mismatch. User has "${rawRole}", expected one of: ${roles.join(", ")}`);
        window.location.href = redirectTo;
        return false;
    }
    
    console.log("[Auth] Role verified. Access granted.");
    return true;
}

export async function signOut(redirectTo) {
    await supabase.auth.signOut();
    if (redirectTo) window.location.href = redirectTo;
}
