import { supabase } from "../asset/js/supabaseClient.js";
import { normalizeEmployeeRole } from "../asset/js/employee-guard.js";

const EMAIL_SELECTOR = "#email";
const PASSWORD_SELECTOR = "#password";
const LOGIN_SELECTOR = "#loginBtn";
const ERROR_SELECTOR = "#err";

function getRequiredRole() {
    const path = window.location.pathname.toLowerCase();
    if (path.includes("order-support")) return "order_support";
    if (path.includes("supplier-manager-login") || path.includes("supplier_management")) return "supplier_manager";
    return null;
}

function showError(message) {
    const err = document.querySelector(ERROR_SELECTOR);
    if (!err) return;
    err.textContent = message;
    err.style.display = "block";
}

function clearError() {
    const err = document.querySelector(ERROR_SELECTOR);
    if (!err) return;
    err.style.display = "none";
}

function clearLegacyAuthFlags() {
    [
        "adminLoggedIn",
        "adminName",
        "adminEmail",
        "employeeLoggedIn",
        "employeeRole",
        "employeeEmail",
        "employeeName",
        "employeeIntent",
    ].forEach((key) => {
        try {
            localStorage.removeItem(key);
        } catch (_) { }
    });
}

async function handleLogin() {
    clearError();

    const email = (document.querySelector(EMAIL_SELECTOR)?.value || "").trim();
    const password = (document.querySelector(PASSWORD_SELECTOR)?.value || "").trim();
    const requiredRole = getRequiredRole();

    if (!email || !password || !requiredRole) {
        showError("Wrong email or password.");
        return;
    }

    const { error: loginError } = await supabase.auth.signInWithPassword({ email, password });
    if (loginError) {
        showError("Wrong email or password.");
        return;
    }

    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;
    if (!session?.user?.id) {
        await supabase.auth.signOut();
        showError("Authenticated account was not found.");
        return;
    }

    const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("id, role, employee_role, status, full_name")
        .eq("id", session.user.id)
        .maybeSingle();

    if (profileError || !profile) {
        await supabase.auth.signOut();
        showError("Authenticated account does not match an employee profile.");
        return;
    }

    const accountRole = String(profile.role || "").trim().toLowerCase();
    if (accountRole === "admin") {
        window.location.href = "../admin/admin-dashboard-modern.html";
        return;
    }

    const accountStatus = String(profile.status || "").trim().toLowerCase();
    const employeeRole = normalizeEmployeeRole(profile.employee_role);
    if (accountRole !== "employee" || (accountStatus && accountStatus !== "active")) {
        await supabase.auth.signOut();
        showError("Authenticated account is not an active employee.");
        return;
    }

    if (!["order_support", "supplier_manager"].includes(employeeRole)) {
        await supabase.auth.signOut();
        showError("Authenticated account does not have a valid employee role.");
        return;
    }

    if (employeeRole !== normalizeEmployeeRole(requiredRole)) {
        await supabase.auth.signOut();
        showError("Not authorized for this employee login page.");
        return;
    }

    clearLegacyAuthFlags();

    // display-only compatibility state (not used as source of truth)
    try {
        localStorage.setItem("employeeName", profile.full_name || "Employee");
        localStorage.setItem("employeeEmail", session.user.email || email);
    } catch (_) { }

    window.location.href = "../employees/admin-dashboard-modern.html";
}

const loginBtn = document.querySelector(LOGIN_SELECTOR);
const emailInput = document.querySelector(EMAIL_SELECTOR);
const passInput = document.querySelector(PASSWORD_SELECTOR);

if (loginBtn) loginBtn.addEventListener("click", handleLogin);
if (emailInput) emailInput.addEventListener("input", clearError);
if (passInput) passInput.addEventListener("input", clearError);

document.addEventListener("keydown", (e) => {
    if (e.key === "Enter") handleLogin();
});
