(function (global) {
    'use strict';

    async function _sb() {
        let s = window.__supabase;
        if (!s) { await new Promise(r => setTimeout(r, 250)); s = window.__supabase; }
        return s;
    }

    function _map(r) {
        if (!r) return null;
        const img = r.image_url || '';
        return {
            id: r.id, kind: r.request_type || 'ADD_ITEM',
            status: r.status || 'pending',
            createdAt: r.created_at, updatedAt: r.reviewed_at || r.created_at,
            providerId: r.provider_id, providerName: r.provider_name, providerEmail: r.provider_email,
            itemId: r.item_id || '',
            itemDraft: {
                name: r.name, category: r.category, price: r.price, stock: r.stock,
                image_url: img, img, image: img, description: r.description, desc: r.description
            },
            meta: r.meta || {}, adminNote: r.admin_note || ''
        };
    }

    function _draft(itemDraft) {
        const d = itemDraft || {};
        return {
            name: d.name || '',
            category: d.category || 'General',
            price: Number(d.price || 0),
            stock: Number(d.stock || 0),
            image_url: d.image_url || d.img || d.image || '',
            description: d.description || d.desc || ''
        };
    }

    const ItemRequestsService = {
        KEY: 'product_requests',

        async all() {
            const sb = await _sb(); if (!sb) return [];
            const { data, error } = await sb.from('product_requests')
                .select('*').order('created_at', { ascending: false });
            return error ? [] : (data || []).map(_map);
        },

        async byId(rid) {
            const sb = await _sb(); if (!sb) return null;
            const { data, error } = await sb.from('product_requests')
                .select('*').eq('id', rid).maybeSingle();
            return error ? null : _map(data);
        },

        async byProvider(providerId) {
            const sb = await _sb(); if (!sb) return [];
            const { data, error } = await sb.from('product_requests')
                .select('*').eq('provider_id', providerId).order('created_at', { ascending: false });
            return error ? [] : (data || []).map(_map);
        },

        async createAddItemRequest({ providerId, providerName, providerEmail, itemDraft }) {
            const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
            const { data, error } = await sb.from('product_requests')
                .insert([{
                    provider_id: providerId, provider_name: providerName,
                    provider_email: providerEmail, request_type: 'ADD_ITEM',
                    status: 'pending', ..._draft(itemDraft)
                }])
                .select().single();
            return error ? { ok: false, error: error.message } : { ok: true, request: _map(data) };
        },

        async createEditItemRequest({ providerId, providerName, providerEmail, itemId, itemDraft }) {
            const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
            const { data, error } = await sb.from('product_requests')
                .insert([{
                    provider_id: providerId, provider_name: providerName,
                    provider_email: providerEmail, request_type: 'EDIT_ITEM',
                    item_id: itemId || null, status: 'pending', ..._draft(itemDraft)
                }])
                .select().single();
            return error ? { ok: false, error: error.message } : { ok: true, request: _map(data) };
        },

        async createDeleteItemRequest({ providerId, providerName, providerEmail, itemId, itemDraft }) {
            const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
            const { data, error } = await sb.from('product_requests')
                .insert([{
                    provider_id: providerId, provider_name: providerName,
                    provider_email: providerEmail, request_type: 'DELETE_ITEM',
                    item_id: itemId || null, status: 'pending', ..._draft(itemDraft)
                }])
                .select().single();
            return error ? { ok: false, error: error.message } : { ok: true, request: _map(data) };
        },

        async setStatus(rid, status, meta) {
            const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
            const upd = { status, reviewed_at: new Date().toISOString() };
            if (meta?.reason) upd.admin_note = meta.reason;
            const { data, error } = await sb.from('product_requests')
                .update(upd).eq('id', rid).select().single();
            return error ? { ok: false, error: error.message } : { ok: true, request: _map(data) };
        },

        async approve(rid, adminName) {
            const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
            const res = await sb.functions.invoke('approve-product',
                { body: { request_id: rid, admin_name: adminName || 'Admin' } });
            if (res.error) return { ok: false, error: res.error.message };
            if (res.data?.error) return { ok: false, error: res.data.error };
            return { ok: true };
        },

        async reject(rid, adminName, reason) {
            const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
            const res = await sb.functions.invoke('reject-product',
                { body: { request_id: rid, admin_name: adminName || 'Admin', reason: reason || '' } });
            if (res.error) return { ok: false, error: res.error.message };
            if (res.data?.error) return { ok: false, error: res.data.error };
            return { ok: true };
        },

        async remove(rid) {
            const sb = await _sb(); if (!sb) return { ok: false, error: 'Not connected' };
            const { error } = await sb.from('product_requests').delete().eq('id', rid);
            return error ? { ok: false, error: error.message } : { ok: true };
        }
    };

    global.ItemRequestsService = ItemRequestsService;
})(window);
