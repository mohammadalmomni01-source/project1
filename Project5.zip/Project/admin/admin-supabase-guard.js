import { requireRole } from "../asset/js/supabaseAuth.js";
await requireRole("admin", "admin-login.html");
