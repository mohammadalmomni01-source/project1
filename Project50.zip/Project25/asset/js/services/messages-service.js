(function () {
    async function _sb() {
        let s = window.__supabase;
        if (!s) { await new Promise(r => setTimeout(r, 250)); s = window.__supabase; }
        return s;
    }

    function _mapMsg(row) {
        if (!row) return null;
        const meta = row.meta && typeof row.meta === 'object' ? row.meta : {};
        const readBy = (meta.readBy && typeof meta.readBy === 'object')
            ? meta.readBy
            : { customer: false, provider: false };
        return {
            id: row.id,
            orderId: row.order_id,
            fromRole: row.actor_role || 'system',
            fromId: row.actor_id || null,
            fromName: meta.fromName || '',
            text: row.message || '',
            createdAt: row.created_at,
            readBy
        };
    }

    async function listByOrder(orderId) {
        const sb = await _sb(); if (!sb) return [];
        const { data, error } = await sb
            .from('order_events')
            .select('*')
            .eq('order_id', orderId)
            .eq('event_type', 'message')
            .order('created_at', { ascending: true });
        return error ? [] : (data || []).map(_mapMsg).filter(Boolean);
    }

    async function send(orderId, { fromRole, fromId = null, text, fromName = '' }) {
        const sb = await _sb(); if (!sb) return null;
        const clean = String(text || '').trim();
        if (!clean) return null;
        const readBy = {
            customer: fromRole === 'customer',
            provider: fromRole === 'provider'
        };
        const { data, error } = await sb
            .from('order_events')
            .insert({
                order_id: orderId,
                actor_role: fromRole,
                actor_id: fromId,
                event_type: 'message',
                message: clean,
                meta: { fromName, readBy }
            })
            .select().single();
        return error ? null : _mapMsg(data);
    }

    async function system(orderId, text) {
        return send(orderId, { fromRole: 'system', fromId: null, text, fromName: 'System' });
    }

    async function markRead(orderId, role) {
        const sb = await _sb(); if (!sb) return false;
        const msgs = await listByOrder(orderId);
        const unread = msgs.filter(m => m.fromRole !== role && !m.readBy[role]);
        if (!unread.length) return false;

        await Promise.all(unread.map(async m => {
            const newReadBy = { ...m.readBy, [role]: true };
            try {
                await sb.from('order_events')
                    .update({ meta: { fromName: m.fromName, readBy: newReadBy } })
                    .eq('id', m.id);
            } catch (_) { }
        }));
        return true;
    }

    async function hasUnread(orderId, role) {
        const msgs = await listByOrder(orderId);
        return msgs.some(m => m.fromRole !== role && !m.readBy[role]);
    }

    async function getUnreadCount(orderId, role) {
        const msgs = await listByOrder(orderId);
        return msgs.filter(m => m.fromRole !== role && !m.readBy[role]).length;
    }

    window.MessagesService = { listByOrder, send, system, markRead, hasUnread, getUnreadCount };
})();
