import { supabase } from "../asset/js/supabaseClient.js";

const LOGIN_URL = "./admin-login.html";
const reqBody = document.getElementById("reqBody");
const reqFilter = document.getElementById("reqFilter");
const reqRefresh = document.getElementById("reqRefresh");

let requestsCache = [];
let handlersBound = false;

async function requireAdmin() {
    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;

    if (!session) {
        window.location.href = LOGIN_URL;
        return null;
    }

    const { data: profile, error } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", session.user.id)
        .maybeSingle();

    if (error || profile?.role !== "admin") {
        await supabase.auth.signOut();
        window.location.href = LOGIN_URL;
        return null;
    }

    return session;
}

function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (m) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
    }[m]));
}

function money(value) {
    const n = Number(value || 0);
    return `$${Number.isFinite(n) ? n.toFixed(2) : "0.00"}`;
}

function prettyDate(value) {
    if (!value) return "�";
    try {
        return new Date(value).toLocaleString();
    } catch (_) {
        return String(value);
    }
}

async function invokeFn(fnName, body) {
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData?.session?.access_token;

    if (!token) {
        const err = new Error("Missing session token");
        err.status = 401;
        throw err;
    }

    const { data, error } = await supabase.functions.invoke(fnName, {
        body,
        headers: {
            Authorization: `Bearer ${token}`,
        },
    });

    if (error) {
        const status = error?.context?.status || error?.status || 500;
        const message = error?.message || "Function invoke failed";
        console.error("Function invoke error", { fnName, status, error });
        alert(`${fnName} failed (${status}): ${message}`);
        const err = new Error(message);
        err.status = status;
        throw err;
    }

    return data;
}

function renderRows(list) {
    if (!reqBody) return;
    reqBody.innerHTML = (list || []).map((r) => `
    <tr>
      <td>${esc(prettyDate(r.created_at))}</td>
      <td>${esc(r.provider_name || "")}</td>
      <td>${esc(r.provider_email || "")}</td>
      <td>${esc(r.name || "")}</td>
      <td>${esc(r.category || "")}</td>
      <td>${esc(money(r.price))}</td>
      <td>${esc(r.stock ?? 0)}</td>
      <td>${esc(r.status || "pending")}</td>
      <td>
        <button data-act="view" data-id="${esc(r.id)}">View</button>
        <button data-act="approve" data-id="${esc(r.id)}">Approve</button>
        <button data-act="reject" data-id="${esc(r.id)}">Reject</button>
      </td>
    </tr>
  `).join("") || `<tr><td colspan="9">No requests found.</td></tr>`;
}

async function loadRequests() {
    let query = supabase
        .from("product_requests")
        .select("id,created_at,provider_name,provider_email,name,category,price,stock,status")
        .order("created_at", { ascending: false });

    const selected = String(reqFilter?.value || "all").toLowerCase();
    if (selected !== "all") query = query.eq("status", selected);

    const { data, error } = await query;
    if (error) {
        console.error("loadRequests error", error);
        alert(`Failed to load requests: ${error.message || "Unknown error"}`);
        return;
    }

    requestsCache = data || [];
    renderRows(requestsCache);
}

async function onView(id) {
    const { data, error } = await supabase
        .from("product_requests")
        .select("id,name,category,price,stock,provider_email,provider_name,description,image_url,status")
        .eq("id", id)
        .maybeSingle();

    if (error || !data) {
        alert(`Failed to load details: ${error?.message || "Not found"}`);
        return;
    }

    alert(
        [
            `Name: ${data.name || ""}`,
            `Category: ${data.category || ""}`,
            `Price: ${money(data.price)}`,
            `Stock: ${data.stock ?? 0}`,
            `Provider: ${data.provider_name || ""}`,
            `Provider Email: ${data.provider_email || ""}`,
            `Description: ${data.description || ""}`,
            `Image URL: ${data.image_url || ""}`,
            `Status: ${data.status || "pending"}`,
        ].join("\n")
    );
}

async function onApprove(id) {
    if (!confirm("Approve this item?")) return;
    try {
        const data = await invokeFn("approve-product", { request_id: id });
        console.log("approve request_id", id);
        console.log("approve response", data);
        alert("Approved ?");
        await loadRequests();
    } catch (err) {
        const status = err?.status || "unknown";
        alert(`Approve failed (${status}): ${err?.message || "Unknown error"}`);
    }
}

async function onReject(id) {
    if (!confirm("Reject this item?")) return;
    try {
        const data = await invokeFn("reject-product", { request_id: id });
        console.log("reject request_id", id);
        console.log("reject response", data);
        alert("Rejected ?");
        await loadRequests();
    } catch (err) {
        const status = err?.status || "unknown";
        alert(`Reject failed (${status}): ${err?.message || "Unknown error"}`);
    }
}

function bindHandlers() {
    if (handlersBound) return;
    handlersBound = true;

    document.addEventListener("click", async (e) => {
        const btn = e.target.closest("button[data-act][data-id]");
        if (!btn) return;

        const id = btn.getAttribute("data-id");
        const act = btn.getAttribute("data-act");
        if (!id || !act) return;

        if (act === "view") return onView(id);
        if (act === "approve") return onApprove(id);
        if (act === "reject") return onReject(id);
    });

    reqFilter?.addEventListener("change", () => {
        loadRequests().catch((err) => console.error(err));
    });

    reqRefresh?.addEventListener("click", () => {
        loadRequests().catch((err) => console.error(err));
    });
}

async function init() {
    const session = await requireAdmin();
    if (!session) return;
    bindHandlers();
    await loadRequests();
}

init().catch((err) => {
    console.error("item-requests init error", err);
    alert(`Item Requests failed: ${err?.message || "Unknown error"}`);
});
