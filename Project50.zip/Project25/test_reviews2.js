
const { createClient } = require('@supabase/supabase-js');
const sb = createClient('https://ranqskqvcpywcnekhvfs.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhbnFza3F2Y3B5d2NuZWtodmZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MjczODQsImV4cCI6MjA4NjQwMzM4NH0.0nypi0ARFvfjm0mIC02pFO9fwdUL0PI5bru_amanq34');
async function run() {
    const { data, error } = await sb.from('reviews')
        .select('*')
        .eq('supplier_id', '941bf6ce-7a33-4726-90b0-52e8570cf1d8')
        .order('created_at', { ascending: false });
    console.log(JSON.stringify({data, error}, null, 2));
}
run();

