
const { createClient } = require('@supabase/supabase-js');
const sb = createClient('https://ranqskqvcpywcnekhvfs.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhbnFza3F2Y3B5d2NuZWtodmZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MjczODQsImV4cCI6MjA4NjQwMzM4NH0.0nypi0ARFvfjm0mIC02pFO9fwdUL0PI5bru_amanq34');
async function run() {
    const { data, error } = await sb.from('reviews')
        .select('*, customer:customer_id(company_name, contact_name, role)')
        .eq('supplier_id', 'ea12080b-53cb-4d28-8508-ba784f2afa12')
        .eq('rating_type', 'supplier');
    console.log(JSON.stringify({data, error}, null, 2));
}
run();

