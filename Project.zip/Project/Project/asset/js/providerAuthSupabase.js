import { supabase } from "./supabaseClient.js";

async function getProfile(uid) {
    const { data, error } = await supabase
        .from("profiles")
        .select("full_name, role")
        .eq("id", uid)
        .single();
    if (error) return null;
    return data || null;
}

async function getApprovedProviderRequest(email) {
    const normalizedEmail = (email || "").trim().toLowerCase();
    if (!normalizedEmail) return null;

    const { data, error } = await supabase
        .from("provider_requests")
        .select("id, full_name, email, status")
        .ilike("email", normalizedEmail)
        .or("status.eq.approved,status.eq.Approved")
        .order("id", { ascending: false })
        .limit(1)
        .maybeSingle();

    if (error) {
        console.warn("provider request check failed:", error);
        return null;
    }

    return data || null;
}

async function ensureProviderRoleIfApproved(uid, email) {
    const approvedRequest = await getApprovedProviderRequest(email);
    if (!approvedRequest) return false;

    const fullName = (approvedRequest.full_name || "").trim();
    const profilePatch = {
        role: "provider",
        ...(fullName ? { full_name: fullName } : {}),
    };

    const { data: existing } = await supabase
        .from("profiles")
        .select("id")
        .eq("id", uid)
        .maybeSingle();

    if (existing?.id) {
        const { error: updateError } = await supabase
            .from("profiles")
            .update(profilePatch)
            .eq("id", uid);

        if (!updateError) return true;
        console.warn("provider role update failed:", updateError);
    }

    const { error } = await supabase
        .from("profiles")
        .upsert({ id: uid, ...profilePatch }, { onConflict: "id" });

    if (error) {
        console.warn("provider role sync failed:", error);
        return false;
    }

    return true;
}

window.__providerLogin = async (email, password) => {
    email = (email || "").trim().toLowerCase();

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data?.session) return { ok: false, error: error?.message || "Login failed" };

    let prof = await getProfile(data.user.id);
    if (!prof || prof.role !== "provider") {
        const upgraded = await ensureProviderRoleIfApproved(data.user.id, data.user.email || email);
        if (upgraded) {
            prof = await getProfile(data.user.id);
        }
    }

    if (!prof || prof.role !== "provider") {
        await supabase.auth.signOut();
        return { ok: false, error: "Not authorized (not provider)" };
    }

    return { ok: true };
};

window.__providerLogout = async (redirectTo) => {
    await supabase.auth.signOut();
    if (redirectTo) window.location.href = redirectTo;
};

window.__providerRequireSession = async (redirectTo) => {
    const { data } = await supabase.auth.getSession();
    if (!data?.session) {
        window.location.href = redirectTo;
        return false;
    }

    let prof = await getProfile(data.session.user.id);
    if (!prof || prof.role !== "provider") {
        const upgraded = await ensureProviderRoleIfApproved(
            data.session.user.id,
            data.session.user.email || ""
        );
        if (upgraded) {
            prof = await getProfile(data.session.user.id);
        }
    }

    if (!prof || prof.role !== "provider") {
        await supabase.auth.signOut();
        window.location.href = redirectTo;
        return false;
    }

    return true;
};



