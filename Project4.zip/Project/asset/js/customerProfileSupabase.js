import { supabase } from "./supabaseClient.js";

const LOGIN_PATH = "customer-login.html";

const COUNTRY_DATA = (window.GeoData && Array.isArray(window.GeoData.COUNTRIES))
    ? window.GeoData.COUNTRIES
    : [];

const els = {
    guestNote: document.getElementById("guestNote"),
    name: document.getElementById("name"),
    email: document.getElementById("email"),
    type: document.getElementById("type"),
    phone: document.getElementById("phone"),
    country: document.getElementById("country"),
    city: document.getElementById("city"),
    location: document.getElementById("location"),
    address: document.getElementById("address"),
    save: document.getElementById("save"),
    change: document.getElementById("change"),
    logout: document.getElementById("logout"),
    info: document.getElementById("info"),
};

function setInfo(text) {
    if (els.info) els.info.textContent = text || "";
}

function redirectToLogin() {
    window.location.href = LOGIN_PATH;
}

function getCountryByCode(code) {
    return COUNTRY_DATA.find((c) => c.code === code) || null;
}

function getCountryByName(name) {
    if (!name) return null;
    const value = String(name).trim().toLowerCase();
    return COUNTRY_DATA.find((c) => c.name.toLowerCase() === value) || null;
}

function renderCountries(selectedCode) {
    if (!els.country) return;
    els.country.innerHTML = "";
    const opt0 = document.createElement("option");
    opt0.value = "";
    opt0.textContent = "Select country";
    els.country.appendChild(opt0);

    COUNTRY_DATA.forEach((c) => {
        const o = document.createElement("option");
        o.value = c.code;
        o.textContent = c.name;
        if (selectedCode && selectedCode === c.code) o.selected = true;
        els.country.appendChild(o);
    });
}

function renderCities(countryCode, selectedCity) {
    if (!els.city) return;
    els.city.innerHTML = "";

    const opt0 = document.createElement("option");
    opt0.value = "";
    opt0.textContent = countryCode ? "Select city" : "Select country first";
    els.city.appendChild(opt0);

    const country = getCountryByCode(countryCode);
    if (!country) return;

    country.cities.forEach((name) => {
        const o = document.createElement("option");
        o.value = name;
        o.textContent = name;
        if (selectedCity && selectedCity.toLowerCase() === name.toLowerCase()) o.selected = true;
        els.city.appendChild(o);
    });

    if (selectedCity && !country.cities.some((x) => x.toLowerCase() === selectedCity.toLowerCase())) {
        const o = document.createElement("option");
        o.value = selectedCity;
        o.textContent = selectedCity;
        o.selected = true;
        els.city.appendChild(o);
    }
}

let prevDial = null;
function applyDialForCountry(countryCode) {
    const c = getCountryByCode(countryCode);
    if (!c || !els.phone) {
        prevDial = null;
        return;
    }

    const dial = c.dial;
    const phoneValue = (els.phone.value || "").trim();

    if (!phoneValue) {
        els.phone.value = `${dial} `;
    } else if (prevDial && phoneValue.startsWith(prevDial)) {
        els.phone.value = dial + phoneValue.slice(prevDial.length);
    } else if (!phoneValue.startsWith("+")) {
        els.phone.value = `${dial} ${phoneValue}`;
    }

    prevDial = dial;
}

function syncLocation() {
    if (!els.location || !els.country || !els.city) return;
    const c = getCountryByCode(els.country.value);
    const countryName = c ? c.name : "";
    const city = els.city.value || "";

    if (city && countryName) {
        els.location.value = `${city}, ${countryName}`;
    } else {
        els.location.value = "";
    }
}

function parseLocation(str) {
    if (!str) return { city: "", country: "" };
    const s = String(str).trim();
    const parts = s.includes(",") ? s.split(",") : (s.includes("/") ? s.split("/") : []);
    if (parts.length >= 2) {
        return { city: parts[0].trim(), country: parts.slice(1).join(",").trim() };
    }
    return { city: "", country: "" };
}

function saveLocalSession(partial) {
    try {
        if (!window.CustomerStore) return;
        const current = window.CustomerStore.load(window.CustomerStore.K.session, null) || {};
        window.CustomerStore.save(window.CustomerStore.K.session, { ...current, ...partial });
    } catch (_) {
        // no-op
    }
}

async function loadProfile() {
    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;

    if (!session) {
        redirectToLogin();
        return;
    }

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData?.user) {
        redirectToLogin();
        return;
    }

    const user = userData.user;

    const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("id, role, full_name, org_type, phone, address, country, city")
        .eq("id", user.id)
        .single();

    if (profileError) {
        alert(profileError.message || "Failed to load profile.");
        return;
    }

    if (!profile || profile.role !== "customer") {
        await supabase.auth.signOut();
        redirectToLogin();
        return;
    }

    if (els.guestNote) els.guestNote.style.display = "none";
    if (els.name) {
        els.name.disabled = false;
        els.name.value = profile.full_name || user.user_metadata?.full_name || "";
    }
    if (els.email) els.email.value = user.email || "";
    if (els.type) els.type.value = profile.org_type || "Small Lab";
    if (els.phone) els.phone.value = profile.phone || "";
    if (els.address) els.address.value = profile.address || "";

    const parsed = parseLocation(els.location?.value || "");
    const initialCountryCode = (getCountryByName(profile.country || parsed.country) || {}).code || "";
    const initialCity = profile.city || parsed.city || "";

    renderCountries(initialCountryCode);
    renderCities(initialCountryCode, initialCity);
    syncLocation();
    applyDialForCountry(initialCountryCode);

    saveLocalSession({
        loggedIn: true,
        id: user.id,
        email: user.email || "",
        name: profile.full_name || user.user_metadata?.full_name || "Customer",
        orgType: profile.org_type || null,
        phone: profile.phone || "",
        address: profile.address || "",
        country: profile.country || "",
        city: profile.city || "",
        location: els.location?.value || "",
    });

    if (els.country) {
        els.country.addEventListener("change", () => {
            renderCities(els.country.value, "");
            applyDialForCountry(els.country.value);
            syncLocation();
        });
    }

    if (els.city) {
        els.city.addEventListener("change", () => {
            syncLocation();
        });
    }

    if (els.save) {
        els.save.addEventListener("click", async () => {
            setInfo("");

            const fullName = (els.name?.value || "").trim();
            const orgType = els.type?.value || "Small Lab";
            const phone = (els.phone?.value || "").trim();
            const address = (els.address?.value || "").trim();
            const countryCode = els.country?.value || "";
            const country = (getCountryByCode(countryCode) || {}).name || "";
            const city = els.city?.value || "";

            syncLocation();

            const { error: authUpdateError } = await supabase.auth.updateUser({
                data: { full_name: fullName },
            });

            if (authUpdateError) {
                alert(authUpdateError.message || "Failed to update auth profile.");
                return;
            }

            const { error: profileUpdateError } = await supabase
                .from("profiles")
                .update({
                    full_name: fullName,
                    org_type: orgType,
                    phone,
                    address,
                    country,
                    city,
                })
                .eq("id", user.id);

            if (profileUpdateError) {
                alert(profileUpdateError.message || "Failed to save profile.");
                return;
            }

            saveLocalSession({
                name: fullName,
                orgType,
                phone,
                address,
                country,
                city,
                location: els.location?.value || "",
            });

            setInfo("Saved. Your profile is synced.");
        });
    }
}

if (els.change) {
    els.change.addEventListener("click", async () => {
        const ok = window.confirm("Are you sure you want to delete your account? This cannot be undone.");
        if (!ok) return;

        const { data: sessionData } = await supabase.auth.getSession();
        const session = sessionData?.session;
        if (!session) {
            alert("Please login again.");
            window.location.href = "customer-login.html";
            return;
        }

        const { error } = await supabase.functions.invoke("delete-account", {
            headers: { Authorization: `Bearer ${session.access_token}` },
        });

        if (error) {
            alert(error.message || "Failed to delete account.");
            return;
        }

        alert("Account deleted successfully.");
        await supabase.auth.signOut();
        window.location.href = "customer-login.html";
    });
}

if (els.logout) {
    els.logout.addEventListener("click", async (e) => {
        e.preventDefault();
        if (window.confirm("Logout?")) {
            await supabase.auth.signOut();
            try {
                if (window.CustomerStore) {
                    window.CustomerStore.save(window.CustomerStore.K.session, null);
                }
            } catch (_) {
                // no-op
            }
            redirectToLogin();
        }
    });
}

loadProfile();
