import { supabase } from "../asset/js/supabaseClient.js";

const tbody = document.getElementById("reqBody");
const errBox = document.getElementById("err");

function showErr(msg) {
    if (!errBox) return;
    errBox.textContent = msg || "";
    errBox.style.display = msg ? "block" : "none";
}

function escapeHtml(s) {
    return String(s ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function render(rows) {
    if (!tbody) return;

    tbody.innerHTML = (rows || [])
        .map((r) => {
            const status = (r.status || "pending").toLowerCase();
            const canAct = status === "pending";

            const approveBtn = canAct
                ? `<button class="btn approve" data-act="approve" data-id="${r.id}">Approve</button>`
                : "";
            const rejectBtn = canAct
                ? `<button class="btn reject" data-act="reject" data-id="${r.id}">Reject</button>`
                : "";

            return `
        <tr>
          <td><code>${r.id}</code></td>
          <td>${escapeHtml(r.full_name)}</td>
          <td>${escapeHtml(r.email)}</td>
          <td>${escapeHtml(r.phone)}</td>
          <td>${escapeHtml(r.company_name || "")}</td>
          <td style="font-weight:800">${escapeHtml(status)}</td>
          <td>${escapeHtml(r.notes || "")}</td>
          <td style="display:flex; gap:8px; flex-wrap:wrap">${approveBtn}${rejectBtn}</td>
        </tr>
      `;
        })
        .join("");
}

async function requireAdmin() {
    let { data: sData } = await supabase.auth.getSession();
    let session = sData?.session;

    if (!session) {
        alert("Session expired. Please login again.");
        window.location.href = "../admin/admin-login.html";
        return null;
    }

    const expiresAtMs = (session.expires_at || 0) * 1000;
    const soon = Date.now() + 60 * 1000;
    if (expiresAtMs && expiresAtMs < soon) {
        const { data: rData, error: rErr } = await supabase.auth.refreshSession();
        if (rErr || !rData?.session) {
            alert("Session expired. Please login again.");
            await supabase.auth.signOut();
            window.location.href = "../admin/admin-login.html";
            return null;
        }
        session = rData.session;
    }

    const { data: prof, error } = await supabase
        .from("profiles")
        .select("role, full_name")
        .eq("id", session.user.id)
        .single();

    if (error || !prof || prof.role !== "admin") {
        alert("Not authorized");
        await supabase.auth.signOut();
        window.location.href = "../admin/admin-login.html";
        return null;
    }

    return { session, prof };
}

async function invokeWithJwt(fnName, bodyObj) {
    const ok = await requireAdmin();
    if (!ok) return { data: null, error: new Error("Not authorized") };

    const token = ok.session.access_token;
    return await supabase.functions.invoke(fnName, {
        body: bodyObj,
        headers: {
            Authorization: `Bearer ${token}`,
        },
    });
}

async function fallbackApproveRequest(requestId) {
    const { error } = await supabase
        .from("provider_requests")
        .update({ status: "approved" })
        .eq("id", requestId);

    if (error) {
        return { ok: false, error: error.message || "Failed to mark as approved" };
    }

    return { ok: true };
}

async function fallbackRejectRequest(requestId) {
    const { error } = await supabase
        .from("provider_requests")
        .update({ status: "rejected" })
        .eq("id", requestId);

    if (error) {
        return { ok: false, error: error.message || "Failed to mark as rejected" };
    }

    return { ok: true };
}

async function getProviderRequestById(requestId) {
    const { data, error } = await supabase
        .from("provider_requests")
        .select("*")
        .eq("id", requestId)
        .single();

    if (error) {
        console.warn("provider request fetch failed:", error);
        return null;
    }

    return data || null;
}


function pickUserIdFromNotes(notes) {
    const raw = String(notes || "");
    const m = raw.match(/\[uid:([0-9a-fA-F-]{10,})\]/);
    return m?.[1] || null;
}

function normalizeUuidMaybe(value) {
    if (typeof value !== "string") return null;
    const v = value.trim();
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)
        ? v
        : null;
}

function pickProviderUserId(requestRow, approveData) {
    const fromRequest = requestRow
        ? [
            requestRow.user_id,
            requestRow.auth_user_id,
            requestRow.profile_id,
            requestRow.provider_id,
            pickUserIdFromNotes(requestRow.notes),
        ]
        : [];
    const fromApproveData = approveData
        ? [approveData.user_id, approveData.userId, approveData.auth_user_id, approveData.profile_id]
        : [];

    return [...fromRequest, ...fromApproveData].map(normalizeUuidMaybe).find(Boolean) || null;
}

async function syncApprovedProfile(requestId, approveData) {
    const requestRow = await getProviderRequestById(requestId);
    if (!requestRow) {
        return { ok: false, skipped: true, reason: "Provider request not found" };
    }

    const userId = pickProviderUserId(requestRow, approveData);
    if (!userId) {
        return {
            ok: false,
            skipped: true,
            reason: "No linked user id in provider_requests (user_id/auth_user_id/profile_id)",
        };
    }

    const fullName = (requestRow.full_name || "").trim() || null;
    const phone = (requestRow.phone || "").trim() || null;
    const companyName = (requestRow.company_name || "").trim() || null;

    const profilePatch = {
        role: "provider",
        ...(fullName ? { full_name: fullName } : {}),
        ...(phone ? { phone } : {}),
        ...(companyName ? { company_name: companyName } : {}),
    };

    const { data: existing } = await supabase
        .from("profiles")
        .select("id")
        .eq("id", userId)
        .maybeSingle();

    if (existing?.id) {
        const { error: updateError } = await supabase
            .from("profiles")
            .update(profilePatch)
            .eq("id", userId);

        if (updateError) {
            console.warn("profiles update failed:", updateError);
            return { ok: false, skipped: false, reason: updateError.message || "Failed to update profiles" };
        }

        return { ok: true, skipped: false };
    }

    const { error } = await supabase
        .from("profiles")
        .upsert(
            {
                id: userId,
                ...profilePatch,
            },
            { onConflict: "id" }
        );

    if (error) {
        console.warn("profiles sync failed:", error);
        return {
            ok: false,
            skipped: true,
            reason: "Profile row missing and insert blocked by RLS. Login once with this account to create profile, then approve again.",
        };
    }

    return { ok: true, skipped: false };
}

async function approveRequest(requestId) {
    const ok = await requireAdmin();
    if (!ok) return;

    const { data, error } = await invokeWithJwt("approve-provider", {
        request_id: requestId,
    });

    let usedFallback = false;
    if (error || !data?.ok) {
        console.warn("approve-provider function failed, using DB fallback", {
            error,
            data,
        });

        const fallback = await fallbackApproveRequest(requestId);
        if (!fallback.ok) {
            alert(`Approve failed: ${fallback.error || error?.message || "Unknown error"}`);
            return;
        }

        usedFallback = true;
    }

    const profileSync = await syncApprovedProfile(requestId, data);

    const tempPassword = data?.tempPassword || data?.temp_password;
    const lines = [];
    lines.push("Approved ✅");

    if (tempPassword) lines.push(`Temp password: ${tempPassword}`);
    if (usedFallback) lines.push("Edge Function not available, request status updated directly.");

    if (!profileSync.ok && profileSync.skipped) {
        lines.push(`Note: ${profileSync.reason || "Could not create profile now."}`);
    } else if (!profileSync.ok) {
        lines.push(`Warning: profile sync issue (${profileSync.reason || "Unknown"}).`);
    }

    alert(lines.join("\n"));
    window.location.reload();
}

async function rejectRequest(requestId) {
    const ok = await requireAdmin();
    if (!ok) return;

    const { data, error } = await invokeWithJwt("reject-provider", {
        request_id: requestId,
    });

    if (!error && data?.ok) {
        alert("Rejected ✅");
        window.location.reload();
        return;
    }

    console.warn("reject-provider function failed, using DB fallback", {
        error,
        data,
    });

    const fallback = await fallbackRejectRequest(requestId);
    if (!fallback.ok) {
        alert(`Reject failed: ${fallback.error || error?.message || "Unknown error"}`);
        return;
    }

    alert("Rejected ✅\n(Edge Function not available, request status updated directly)");
    window.location.reload();
}

async function loadRequests() {
    showErr("");
    const { data, error } = await supabase
        .from("provider_requests")
        .select("id, full_name, email, phone, company_name, notes, status, created_at")
        .order("created_at", { ascending: false });

    if (error) {
        console.error(error);
        showErr("Failed to fetch");
        render([]);
        return [];
    }

    render(data || []);
    return data || [];
}

async function main() {
    const admin = await requireAdmin();
    if (!admin) return;

    await loadRequests();

    document.addEventListener("click", (e) => {
        const btn = e.target?.closest?.("button[data-act]");
        if (!btn) return;

        const act = btn.getAttribute("data-act");
        const id = btn.getAttribute("data-id");
        if (!id) return;

        if (act === "approve") approveRequest(id);
        if (act === "reject") rejectRequest(id);
    });
}

main();


