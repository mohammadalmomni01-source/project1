// Configure your Supabase project values here.
// Keep this file loaded BEFORE any module that imports supabaseClient.js
window.SUPABASE_URL = window.SUPABASE_URL || "https://ranqskqvcpywcnekhvfs.supabase.co";
window.SUPABASE_ANON_KEY = window.SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhbnFza3F2Y3B5d2NuZWtodmZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MjczODQsImV4cCI6MjA4NjQwMzM4NH0.0nypi0ARFvfjm0mIC02pFO9fwdUL0PI5bru_amanq34";
