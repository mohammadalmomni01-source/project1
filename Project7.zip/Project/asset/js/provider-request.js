import { supabase } from "./supabaseClient.js";

async function getLatestRequestByEmail(email) {
    const normalizedEmail = (email || "").trim().toLowerCase();
    if (!normalizedEmail) return null;

    const { data, error } = await supabase
        .from("provider_requests")
        .select("id, status, email")
        .ilike("email", normalizedEmail)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

    if (error) {
        console.warn("provider request lookup failed:", error);
        return null;
    }

    return data || null;
}

async function upsertPendingProfile(userId, fullName, companyName, phone) {
    const payload = {
        id: userId,
        full_name: (fullName || "").trim() || null,
        role: "pending_provider",
        org_type: null,
        company_name: (companyName || "").trim() || null,
        phone: (phone || "").trim() || null,
    };

    const { error } = await supabase
        .from("profiles")
        .upsert(payload, { onConflict: "id" });

    return { ok: !error, error };
}

function normalizeStatus(status) {
    return String(status || "").trim().toLowerCase();
}

window.__providerSubmitRequest = async ({ full_name, email, password, phone, company_name, notes }) => {
    try {
        const normalizedEmail = (email || "").trim().toLowerCase();
        const normalizedPassword = password == null ? "" : String(password);

        if (!normalizedEmail) return { ok: false, error: "Email is required." };
        if (normalizedPassword.length < 6) {
            return { ok: false, error: "Password must be at least 6 characters." };
        }

        const existing = await getLatestRequestByEmail(normalizedEmail);
        const existingStatus = normalizeStatus(existing?.status);

        if (existingStatus === "pending") {
            return {
                ok: false,
                code: "ALREADY_PENDING",
                error: "Already pending approval",
                redirectTo: "provider-login.html",
            };
        }

        if (existingStatus === "approved") {
            return {
                ok: false,
                code: "ALREADY_APPROVED",
                error: "Already approved, please login",
                redirectTo: "provider-login.html",
            };
        }

        if (existingStatus === "rejected") {
            return {
                ok: false,
                code: "REJECTED",
                error: "Rejected, cannot signup",
            };
        }

        // Keep `role` metadata (required by app flows) while using a DB-safe auth role.
        const signUpRes = await supabase.auth.signUp({
            email: normalizedEmail,
            password: normalizedPassword,
            options: {
                data: {
                    full_name: full_name || "",
                    role: "provider",
                    requested_role: "pending_provider",
                },
            },
        });

        if (signUpRes?.error) {
            return { ok: false, error: signUpRes.error.message || "Failed to create provider account." };
        }

        const userId = signUpRes?.data?.user?.id;
        if (!userId) {
            return { ok: false, error: "Failed to create provider account." };
        }

        const profileRes = await upsertPendingProfile(userId, full_name, company_name, phone);
        if (!profileRes.ok) {
            await supabase.auth.signOut();
            return {
                ok: false,
                error: profileRes.error?.message || "Failed to create profile.",
            };
        }

        const requestPayload = {
            auth_user_id: userId,
            full_name: full_name || null,
            email: normalizedEmail,
            phone: phone || null,
            company_name: company_name || null,
            notes: notes || null,
            status: "pending",
            created_at: new Date().toISOString(),
        };

        const { error: requestError } = await supabase.from("provider_requests").insert([requestPayload]);

        if (requestError) {
            if (requestError.code === "23505") {
                const latest = await getLatestRequestByEmail(normalizedEmail);
                const latestStatus = normalizeStatus(latest?.status);
                await supabase.auth.signOut();

                if (latestStatus === "pending") {
                    return {
                        ok: false,
                        code: "ALREADY_PENDING",
                        error: "Already pending approval",
                        redirectTo: "provider-login.html",
                    };
                }
                if (latestStatus === "approved") {
                    return {
                        ok: false,
                        code: "ALREADY_APPROVED",
                        error: "Already approved, please login",
                        redirectTo: "provider-login.html",
                    };
                }
                if (latestStatus === "rejected") {
                    return {
                        ok: false,
                        code: "REJECTED",
                        error: "Rejected, cannot signup",
                    };
                }
            }

            await supabase.auth.signOut();
            return { ok: false, error: requestError.message || "Failed to send request." };
        }

        await supabase.auth.signOut();
        return { ok: true, userId, message: "Request submitted. Wait for admin approval.", redirectTo: "provider-login.html" };
    } catch (e) {
        console.error("provider submit request failed:", e);
        await supabase.auth.signOut();
        return { ok: false, error: "Failed to send request." };
    }
};
