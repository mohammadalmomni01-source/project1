// Demo catalog + suppliers data ()
// Used by customer pages.

(function () {
  function svgDataURI(title, subtitle, c1, c2) {
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="800" height="520" viewBox="0 0 800 520">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="${c1}" stop-opacity="0.95"/>
            <stop offset="1" stop-color="${c2}" stop-opacity="0.95"/>
          </linearGradient>
        </defs>
        <rect width="800" height="520" rx="36" fill="#f6f8ff"/>
        <circle cx="660" cy="120" r="180" fill="#eaf0ff"/>
        <rect x="70" y="70" width="660" height="380" rx="28" fill="white" stroke="#e6edff"/>
        <rect x="110" y="120" width="220" height="220" rx="24" fill="url(#g)"/>
        <path d="M170 170h100M170 205h100M170 240h100" stroke="rgba(255,255,255,0.9)" stroke-width="10" stroke-linecap="round"/>
        <text x="360" y="195" font-family="Poppins, Arial" font-size="34" font-weight="700" fill="#0f172a">${title}</text>
        <text x="360" y="235" font-family="Poppins, Arial" font-size="18" font-weight="500" fill="#64748b">${subtitle}</text>
        <text x="110" y="405" font-family="Poppins, Arial" font-size="14" fill="#94a3b8">Lab Supplies • Demo Image</text>
      </svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  }

  // Suppliers
  const suppliers = [
    {
      id: 'sup-aurora',
      name: 'Aurora Scientific',
      city: 'Amman',
      phone: '+962790000001',
      email: 'sales@aurora.example',
      whatsapp: 'https://wa.me/962790000001',
      avgPrepDays: 1,
      logo: svgDataURI('Aurora', 'Scientific Supplier', '#2f87ff', '#6ee7ff'),
      about: 'University-grade lab consumables and glassware.'
    },
    {
      id: 'sup-nova',
      name: 'NovaLab Co.',
      city: 'Irbid',
      phone: '+962790000002',
      email: 'support@novalab.example',
      whatsapp: 'https://wa.me/962790000002',
      avgPrepDays: 2,
      logo: svgDataURI('NovaLab', 'Chemicals & Reagents', '#0ea5e9', '#22c55e'),
      about: 'Certified chemicals and reagents with COA on request.'
    },
    {
      id: 'sup-vertex',
      name: 'Vertex Instruments',
      city: 'Zarqa',
      phone: '+962790000003',
      email: 'hello@vertex.example',
      whatsapp: 'https://wa.me/962790000003',
      avgPrepDays: 3,
      logo: svgDataURI('Vertex', 'Equipment Supplier', '#a855f7', '#2f87ff'),
      about: 'Lab equipment, calibration accessories, and warranties.'
    }
  ];

  // Items
  const items = [
    {
      id: 'it-beaker-500',
      name: 'Beaker 500ml',
      category: 'Glassware',
      supplierId: 'sup-aurora',
      basePrice: 4.5,
      stock: 320,
      deliveryDays: { standard: 3, express: 2 },
      image: svgDataURI('Beaker 500ml', 'Borosilicate Glassware', '#2f87ff', '#6ee7ff'),
      desc: 'Borosilicate beaker with graduation marks. Suitable for general lab use.'
    },
    {
      id: 'it-petri-100',
      name: 'Petri Dish 100mm',
      category: 'Glassware',
      supplierId: 'sup-aurora',
      basePrice: 1.2,
      stock: 900,
      deliveryDays: { standard: 2, express: 1 },
      image: svgDataURI('Petri Dish', 'Sterile / Non-sterile', '#06b6d4', '#2f87ff'),
      desc: '100mm petri dish for microbiology labs. Pack options available.'
    },
    {
      id: 'it-ethanol',
      name: 'Ethanol 95% (1L)',
      category: 'Chemicals',
      supplierId: 'sup-nova',
      basePrice: 9.9,
      stock: 120,
      deliveryDays: { standard: 4, express: 3 },
      image: svgDataURI('Ethanol 95%', 'Reagent Grade • 1L', '#22c55e', '#0ea5e9'),
      desc: 'Reagent grade ethanol. Stored and shipped according to safety guidelines.'
    },
    {
      id: 'it-buffer-ph7',
      name: 'Buffer Solution pH 7 (500ml)',
      category: 'Chemicals',
      supplierId: 'sup-nova',
      basePrice: 6.5,
      stock: 240,
      deliveryDays: { standard: 3, express: 2 },
      image: svgDataURI('Buffer pH 7', 'Calibration • 500ml', '#22c55e', '#f59e0b'),
      desc: 'Calibration buffer solution for pH meters. Traceable lot number.'
    },
    {
      id: 'it-microscope',
      name: 'Student Microscope (40x–400x)',
      category: 'Equipment',
      supplierId: 'sup-vertex',
      basePrice: 129,
      stock: 18,
      deliveryDays: { standard: 7, express: 5 },
      image: svgDataURI('Microscope', '40x–400x • LED', '#a855f7', '#2f87ff'),
      desc: 'Entry-level microscope for teaching labs. Includes basic accessories.'
    },
    {
      id: 'it-labcoat',
      name: 'Lab Coat (Unisex)',
      category: 'Safety',
      supplierId: 'sup-aurora',
      basePrice: 12.5,
      stock: 160,
      deliveryDays: { standard: 3, express: 2 },
      image: svgDataURI('Lab Coat', 'Safety Wear', '#f43f5e', '#2f87ff'),
      desc: 'Comfortable lab coat with pockets. Sizes: S–XXL.'
    }
  ];

  // Expose globally
  window.LAB_SUPPLIERS = suppliers;
  window.LAB_ITEMS = items;
})();
