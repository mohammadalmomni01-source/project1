
const { createClient } = require('@supabase/supabase-js');
const sb = createClient('https://ranqskqvcpywcnekhvfs.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhbnFza3F2Y3B5d2NuZWtodmZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MjczODQsImV4cCI6MjA4NjQwMzM4NH0.0nypi0ARFvfjm0mIC02pFO9fwdUL0PI5bru_amanq34');

async function run() {
    const {data} = await sb.from('order_items').select('*').limit(1);
    console.log(data);
}
run();

