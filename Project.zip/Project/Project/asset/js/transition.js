/* =========================================
   Page Transition – Global (auto)
   - Injects overlay + CSS
   - Provides window.go(url)
   - Auto-intercepts internal <a href="..."> clicks
   ========================================= */
(function () {
  // Inject CSS
  const css = `
  .page-transition{
    position: fixed;
    inset: 0;
    background: radial-gradient(circle at top, #3bc7ff 0%, #0b57b7 40%, #083c8f 85%);
    z-index: 99999;
    opacity: 0;
    pointer-events: none;
    transition: opacity .35s ease;
  }
  .page-transition.active{
    opacity: 1;
    pointer-events: all;
  }
  .page-transition .box{
    position:absolute;
    left:50%;
    top:50%;
    transform: translate(-50%,-50%);
    background: rgba(255,255,255,.14);
    border: 1px solid rgba(255,255,255,.18);
    backdrop-filter: blur(10px);
    padding: 18px 22px;
    border-radius: 18px;
    color:#fff;
    font-weight:700;
    letter-spacing:.4px;
    display:flex;
    align-items:center;
    gap:12px;
  }
  .page-transition .spinner{
    width:18px; height:18px;
    border: 3px solid rgba(255,255,255,.35);
    border-top-color:#fff;
    border-radius: 50%;
    animation: spin .7s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  `;
  const style = document.createElement('style');
  style.setAttribute('data-transition-style', '1');
  style.innerHTML = css;
  document.head.appendChild(style);

  // Inject overlay
  const overlay = document.createElement('div');
  overlay.id = 'pageTransition';
  overlay.className = 'page-transition active';
  overlay.innerHTML = `
    <div class="box">
      <span class="spinner"></span>
      Loading...
    </div>
  `;
  document.addEventListener('DOMContentLoaded', () => {
    document.body.appendChild(overlay);
  });

  // Fade-in on load
  window.addEventListener('load', () => {
    setTimeout(() => overlay.classList.remove('active'), 120);
  });

  // Global go()
  window.go = function (url) {
    if (!url) return;
    overlay.classList.add('active');
    setTimeout(() => {
      window.location.href = url;
    }, 250);
  };

  // Auto-intercept internal links
  document.addEventListener('click', (e) => {
    const a = e.target.closest && e.target.closest('a');
    if (!a) return;

    const href = a.getAttribute('href');
    if (!href) return;

    // allow new tab / downloads / anchors / javascript links
    if (a.target === '_blank') return;
    if (a.hasAttribute('download')) return;
    if (href.startsWith('#')) return;
    if (href.startsWith('javascript:')) return;
    if (href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('https://wa.me') || href.startsWith('whatsapp:')) return;

    // Ignore external absolute URLs (http/https) not same-origin
    if (/^https?:\/\//i.test(href)) {
      try {
        const u = new URL(href);
        if (u.origin !== window.location.origin) return;
      } catch { return; }
    }

    // If user is selecting text or using modifier keys, don't intercept
    if (e.defaultPrevented) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    e.preventDefault();
    window.go(href);
  }, true);
})();
