// Demo data removed — all data comes from Supabase now.
(function () {
    window.LAB_SUPPLIERS = [];
    window.LAB_ITEMS = [];
})();
