import "./providerAuthSupabase.js";

(async () => {
    if (typeof window.__providerRequireSession !== "function") return;

    const ok = await window.__providerRequireSession("provider-login.html");
    if (!ok) {
        window.location.href = "provider-login.html";
    }
})();
