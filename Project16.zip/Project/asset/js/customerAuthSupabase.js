
import { supabase } from "./supabaseClient.js";

function saveLocalSession(partial) {
    try {
        if (!window.CustomerStore) return;
        const s = window.CustomerStore.load(window.CustomerStore.K.session, null) || {};
        window.CustomerStore.save(window.CustomerStore.K.session, { ...s, ...partial });
    } catch (e) { }
}

async function getProfile(uid) {
    const { data, error } = await supabase
        .from("profiles")
        .select("full_name, role, org_type")
        .eq("id", uid)
        .single();
    if (error) return null;
    return data || null;
}

async function signUpWithMetadata(email, password, metadata) {
    return await supabase.auth.signUp({
        email,
        password,
        options: { data: metadata }
    });
}

window.__customerLogin = async (email, password) => {
    email = (email || "").trim().toLowerCase();

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data?.session) return { ok: false, error: error?.message || "Login failed" };

    const prof = await getProfile(data.user.id);
    if (!prof || prof.role !== "customer") {
        await supabase.auth.signOut();
        return { ok: false, error: "Not authorized" };
    }

    saveLocalSession({
        loggedIn: true,
        id: data.user.id,
        email,
        name: prof.full_name || "Customer",
        orgType: prof.org_type || null
    });

    return { ok: true, orgType: prof.org_type || null };
};

window.__customerSignup = async (email, password, name) => {
    email = (email || "").trim().toLowerCase();
    name = (name || "").trim();

    // Profiles row is created by DB trigger (handle_new_user); frontend should not write profiles on signup.
    // Primary metadata contract for customer signup:
    let { data, error } = await signUpWithMetadata(email, password, { full_name: name, role: "customer" });

    // Fallback for projects with legacy auth checks that reject role metadata.
    if (error && /database error saving new user/i.test(error.message || "")) {
        const retry = await signUpWithMetadata(email, password, { full_name: name });
        data = retry.data;
        error = retry.error;
    }

    if (error) return { ok: false, error: error.message };

    let session = data?.session || null;
    let user = data?.user || null;

    if (!session) {
        const loginRes = await supabase.auth.signInWithPassword({ email, password });
        if (loginRes?.error || !loginRes?.data?.session) {
            return {
                ok: false,
                error: "Signup succeeded but no session was created. Disable email confirmation in Supabase Auth settings."
            };
        }
        session = loginRes.data.session;
        user = loginRes.data.user;
    }

    saveLocalSession({
        loggedIn: true,
        id: user.id,
        email: user.email || email,
        name: name || user.email || "Customer",
        orgType: null
    });

    return { ok: true, orgType: null };
};

window.__customerSetOrgType = async (orgType) => {
    const { data } = await supabase.auth.getSession();
    const sess = data?.session;
    if (!sess) return { ok: false, error: "Not logged in" };

    const { error } = await supabase
        .from("profiles")
        .update({ org_type: orgType })
        .eq("id", sess.user.id);

    if (error) return { ok: false, error: error.message };

    saveLocalSession({ orgType });
    return { ok: true };
};

window.__customerRequireSession = async (redirectTo) => {
    const { data } = await supabase.auth.getSession();
    if (!data?.session) {
        window.location.href = redirectTo;
        return false;
    }

    const prof = await getProfile(data.session.user.id);
    if (!prof || prof.role !== "customer") {
        await supabase.auth.signOut();
        window.location.href = redirectTo;
        return false;
    }

    saveLocalSession({
        loggedIn: true,
        id: data.session.user.id,
        email: data.session.user.email,
        name: prof.full_name || "Customer",
        orgType: prof.org_type || null
    });

    return true;
};

window.__customerLogout = async (redirectTo) => {
    await supabase.auth.signOut();
    try {
        if (window.CustomerStore)
            window.CustomerStore.save(window.CustomerStore.K.session, null);
    } catch (e) { }
    if (redirectTo) window.location.href = redirectTo;
};

