-- =========================================================
-- Provider <-> Customer direct messages table
-- Run this once in Supabase SQL Editor
-- =========================================================

-- 1. Main messages table
CREATE TABLE IF NOT EXISTS provider_customer_messages (
    id             uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    order_id       text NOT NULL,           -- links to order for context
    provider_id    text NOT NULL,           -- provider's user id or provider identifier
    customer_email text NOT NULL,           -- customer email (used as identifier)
    sender_role    text NOT NULL CHECK (sender_role IN ('customer', 'provider')),
    sender_name    text NOT NULL DEFAULT '',
    sender_email   text NOT NULL DEFAULT '',
    message        text NOT NULL,
    created_at     timestamptz DEFAULT now() NOT NULL,
    read_by_customer boolean DEFAULT false,
    read_by_provider boolean DEFAULT false
);

-- 2. Indexes for fast queries
CREATE INDEX IF NOT EXISTS idx_pcm_order    ON provider_customer_messages(order_id);
CREATE INDEX IF NOT EXISTS idx_pcm_provider ON provider_customer_messages(provider_id);
CREATE INDEX IF NOT EXISTS idx_pcm_customer ON provider_customer_messages(customer_email);
CREATE INDEX IF NOT EXISTS idx_pcm_created  ON provider_customer_messages(created_at ASC);

-- 3. Enable Row Level Security
ALTER TABLE provider_customer_messages ENABLE ROW LEVEL SECURITY;

-- 4. RLS Policies
-- Allow anyone with the anon key to read and insert
-- (customer and provider both use anon key or service role)
DROP POLICY IF EXISTS "Anyone can read pcm" ON provider_customer_messages;
CREATE POLICY "Anyone can read pcm" ON provider_customer_messages
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Anyone can insert pcm" ON provider_customer_messages;
CREATE POLICY "Anyone can insert pcm" ON provider_customer_messages
    FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can update pcm" ON provider_customer_messages;
CREATE POLICY "Anyone can update pcm" ON provider_customer_messages
    FOR UPDATE USING (true);
