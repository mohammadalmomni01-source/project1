import "./customerAuthSupabase.js?v=otpfix1";

const msg = document.getElementById("msgBox");
const emailLabel = document.getElementById("emailLabel");
const verifyBtn = document.getElementById("verifyBtn");
const resendBtn = document.getElementById("resendBtn");
const otpInput = document.getElementById("otpCode");

function showMsg(kind, text) {
    msg.style.display = "block";
    msg.className = `msg ${kind}`;
    msg.textContent = text;
}

function getSignupEmail() {
    const q = new URLSearchParams(window.location.search).get("email") || "";
    const fromQuery = q.trim().toLowerCase();

    let fromSession = "";
    try {
        fromSession = (sessionStorage.getItem("customer_signup_email") || "").trim().toLowerCase();
    } catch (e) { }

    return fromQuery || fromSession || "";
}

function getVerifyApi() {
    const verify = window.__customerVerifySignupOtp;
    const finalize = window.__customerFinalizeSignup;
    const resend = window.__customerResendSignupOtp;
    if (!verify || !finalize || !resend) return null;
    return { verify, finalize, resend };
}

const signupEmail = getSignupEmail();

if (!signupEmail) {
    emailLabel.textContent = "No signup email found";
    showMsg("error", "Missing signup email. Please sign up again.");
} else {
    emailLabel.textContent = signupEmail;
}

if (!getVerifyApi()) {
    showMsg("error", "Verification module did not load correctly. Please reload the page.");
}

verifyBtn?.addEventListener("click", async () => {
    const otp = (otpInput.value || "").trim();

    if (!signupEmail) {
        showMsg("error", "Missing signup email. Please sign up again.");
        return;
    }

    if (!otp) {
        showMsg("error", "Please enter the verification code.");
        return;
    }

    const api = getVerifyApi();
    if (!api) {
        showMsg("error", "Verification module did not load correctly. Please reload the page.");
        return;
    }

    verifyBtn.disabled = true;
    const verifyRes = await api.verify(signupEmail, otp);
    if (!verifyRes?.ok) {
        verifyBtn.disabled = false;
        showMsg("error", verifyRes?.error || "OTP verification failed.");
        return;
    }

    const finalizeRes = await api.finalize();
    verifyBtn.disabled = false;

    if (!finalizeRes?.ok) {
        showMsg("error", finalizeRes?.error || "Could not finalize your account.");
        return;
    }

    try {
        sessionStorage.removeItem("customer_signup_email");
    } catch (e) { }

    showMsg("success", "Email verified successfully! Redirecting...");
    setTimeout(() => {
        window.location.href = "customer-type.html";
    }, 600);
});

resendBtn?.addEventListener("click", async () => {
    if (!signupEmail) {
        showMsg("error", "Missing signup email. Please sign up again.");
        return;
    }

    const api = getVerifyApi();
    if (!api) {
        showMsg("error", "Verification module did not load correctly. Please reload the page.");
        return;
    }

    const res = await api.resend(signupEmail);
    if (!res?.ok) {
        showMsg("error", res?.error || "Unable to resend OTP.");
        return;
    }

    showMsg("success", res.message || "A new verification code was sent to your email.");
});
