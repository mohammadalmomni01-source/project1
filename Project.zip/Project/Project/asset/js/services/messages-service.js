(function(){
  const U = ()=> (window.Utils || {});

  function _loadDB(){
    if(!window.CustomerStore) return {};
    return CustomerStore.load(CustomerStore.K.messages, {});
  }
  function _saveDB(db){
    if(!window.CustomerStore) return;
    CustomerStore.save(CustomerStore.K.messages, db);
  }

  function _uid(){
    // Reuse CustomerStore uid if available
    if(window.CustomerStore && typeof CustomerStore.uid === 'function') return CustomerStore.uid('msg');
    return `msg-${Math.random().toString(16).slice(2,10)}-${Date.now().toString(16)}`;
  }

  function _normalizeOne(orderId, m){
    if(!m) return null;
    // New format
    if(m.orderId && m.fromRole && m.createdAt){
      const readBy = m.readBy && typeof m.readBy === 'object' ? m.readBy : {customer:false, provider:false};
      return {
        id: m.id || _uid(),
        orderId: m.orderId,
        fromRole: m.fromRole,
        fromId: m.fromId ?? null,
        text: String(m.text ?? ''),
        createdAt: m.createdAt,
        readBy
      };
    }

    // Legacy {from, at, text}
    const rawFrom = String(m.from || 'system');
    const fromRole = (rawFrom === 'me' || rawFrom === 'customer') ? 'customer' : (rawFrom === 'supplier' ? 'provider' : rawFrom);
    const createdAt = m.at || m.createdAt || new Date().toISOString();
    return {
      id: m.id || _uid(),
      orderId,
      fromRole,
      fromId: m.fromId ?? null,
      text: String(m.text ?? ''),
      createdAt,
      readBy: m.readBy && typeof m.readBy === 'object' ? m.readBy : {customer:false, provider:false}
    };
  }

  function listByOrder(orderId){
    const db = _loadDB();
    const raw = Array.isArray(db[orderId]) ? db[orderId] : [];
    const out = raw.map(m=>_normalizeOne(orderId,m)).filter(Boolean);

    // In this project, many threads are stored newest-first (unshift). Sort for display.
    out.sort((a,b)=> String(a.createdAt||'').localeCompare(String(b.createdAt||'')));
    return out;
  }

  function _write(orderId, msg){
    const db = _loadDB();
    db[orderId] = Array.isArray(db[orderId]) ? db[orderId] : [];
    // Keep newest-first in storage to stay compatible with existing pages.
    db[orderId].unshift(msg);
    _saveDB(db);
  }

  function send(orderId, {fromRole, fromId=null, text}){
    const now = new Date().toISOString();
    const legacyFrom = (fromRole === 'customer') ? 'me' : (fromRole === 'provider' ? 'supplier' : 'system');
    const msg = {
      id: _uid(),
      orderId,
      fromRole,
      fromId,
      text: String(text ?? '').trim(),
      createdAt: now,
      // legacy fields (keep other pages working)
      from: legacyFrom,
      at: now,
      ts: new Date(now).toLocaleString(),
      // sender has read it, other side has not
      readBy: {
        customer: fromRole === 'customer',
        provider: fromRole === 'provider'
      }
    };
    if(!msg.text) return null;
    _write(orderId, msg);
    return msg;
  }

  function system(orderId, text){
    const now = new Date().toISOString();
    const msg = {
      id: _uid(),
      orderId,
      fromRole: 'system',
      fromId: null,
      text: String(text ?? '').trim(),
      createdAt: now,
      // legacy fields
      from: 'system',
      at: now,
      ts: new Date(now).toLocaleString(),
      readBy: { customer:false, provider:false }
    };
    if(!msg.text) return null;
    _write(orderId, msg);
    return msg;
  }

  function markRead(orderId, role){
    const db = _loadDB();
    const arr = Array.isArray(db[orderId]) ? db[orderId] : [];
    let changed = false;
    for(const m of arr){
      m.readBy = m.readBy && typeof m.readBy === 'object' ? m.readBy : {customer:false, provider:false};
      if(role === 'customer' && !m.readBy.customer){ m.readBy.customer = true; changed = true; }
      if(role === 'provider' && !m.readBy.provider){ m.readBy.provider = true; changed = true; }
    }
    if(changed){
      db[orderId] = arr;
      _saveDB(db);
    }
    return changed;
  }

  function hasUnread(orderId, role){
    const msgs = listByOrder(orderId);
    for(const m of msgs){
      if(m.fromRole === role) continue;
      const rb = m.readBy || {customer:false, provider:false};
      if(role === 'customer' && !rb.customer) return true;
      if(role === 'provider' && !rb.provider) return true;
    }
    return false;
  }

  function getUnreadCount(orderId, role){
    const msgs = listByOrder(orderId);
    let n = 0;
    for(const m of msgs){
      if(m.fromRole === role) continue;
      const rb = m.readBy || {customer:false, provider:false};
      if(role === 'customer' && !rb.customer) n++;
      if(role === 'provider' && !rb.provider) n++;
    }
    return n;
  }

  window.MessagesService = { listByOrder, send, system, markRead, hasUnread, getUnreadCount };
})();
