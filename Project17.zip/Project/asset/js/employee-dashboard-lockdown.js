const NAV_VIEW_MAP = {
    'nav-dashboard': 'dashboard',
    'nav-orders': 'orders',
    'nav-users': 'users',
    'nav-providers': 'providers',
    'nav-providerRequests': 'providerRequests',
    'nav-itemRequests': 'itemRequests',
    'nav-support': 'support',
    'nav-providerMessages': 'providerMessages',
};

const QUICK_VIEW_MAP = {
    'btn-viewOrders': 'orders',
    'btn-manageUsers': 'users',
    'btn-manageProviders': 'providers',
};

function toRoleLabel(role) {
    if (role === 'supplier_manager') return 'Supplier Management';
    if (role === 'order_support') return 'Order Support';
    return 'Employee';
}

function setDisabledState(el, disabled) {
    if (!el) return;
    if ('disabled' in el) el.disabled = !!disabled;
    if (disabled) {
        el.classList.add('is-disabled');
        el.setAttribute('aria-disabled', 'true');
        el.removeAttribute('href');
        el.tabIndex = -1;
        el.style.pointerEvents = 'none';
        el.style.opacity = '0.5';
        el.style.cursor = 'not-allowed';
        el.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            return false;
        });
    } else {
        el.classList.remove('is-disabled');
        el.setAttribute('aria-disabled', 'false');
        el.removeAttribute('style');
        el.tabIndex = 0;
    }
}

function sanitizeTargetView(allowedViews, defaultView, target) {
    if (!allowedViews.has(target) || target === 'dashboard' || target === 'users') {
        return defaultView;
    }
    return target;
}

export function applyEmployeeDashboardLockdown(config = {}) {
    const {
        employeeRole = '',
        allowedViews = [],
        defaultView = 'orders',
        fullName = 'Employee',
        email = '',
        fallbackShowView,
    } = config;

    const allowed = new Set(allowedViews);
    const navContainer = document.querySelector('.nav');
    const baseShowView = typeof fallbackShowView === 'function' ? fallbackShowView : window.showView;
    if (!navContainer || typeof baseShowView !== 'function') return;

    const userRoleTop = document.getElementById('userRoleTop');
    const userNameTop = document.getElementById('userNameTop');
    const userEmailTop = document.getElementById('userEmailTop');
    const brandTitle = document.querySelector('.brand h1');
    const brandSub = document.querySelector('.brand p');
    const roleLabel = toRoleLabel(employeeRole);

    if (userRoleTop) userRoleTop.textContent = `Employee � ${roleLabel}`;
    if (userNameTop) userNameTop.textContent = fullName || 'Employee';
    if (userEmailTop) userEmailTop.textContent = email || '';
    if (brandTitle) brandTitle.textContent = 'EMPLOYEES';
    if (brandSub) brandSub.textContent = roleLabel;

    const lockedShowView = (viewName) => {
        const safeView = sanitizeTargetView(allowed, defaultView, viewName);
        baseShowView(safeView);

        Object.keys(NAV_VIEW_MAP).forEach((id) => {
            const el = document.getElementById(id);
            if (!el) return;
            const mappedView = NAV_VIEW_MAP[id];
            const isAllowed = allowed.has(mappedView) && mappedView !== 'dashboard' && mappedView !== 'users';
            if (!isAllowed) {
                el.classList.remove('active');
            }
        });

        const safeHash = `#view-${safeView}`;
        if (window.location.hash !== safeHash) {
            window.location.hash = safeHash;
        }
    };

    Object.entries(NAV_VIEW_MAP).forEach(([id, view]) => {
        const oldNode = document.getElementById(id);
        if (!oldNode) return;
        const newNode = oldNode.cloneNode(true);
        oldNode.replaceWith(newNode);

        const isAllowed = allowed.has(view) && view !== 'dashboard' && view !== 'users';
        setDisabledState(newNode, !isAllowed);

        if (isAllowed) {
            newNode.addEventListener('click', (event) => {
                event.preventDefault();
                lockedShowView(view);
            });
        }
    });

    Object.entries(QUICK_VIEW_MAP).forEach(([id, view]) => {
        const oldNode = document.getElementById(id);
        if (!oldNode) return;
        const newNode = oldNode.cloneNode(true);
        oldNode.replaceWith(newNode);

        const isAllowed = allowed.has(view) && view !== 'dashboard' && view !== 'users';
        setDisabledState(newNode, !isAllowed);

        if (isAllowed) {
            newNode.addEventListener('click', (event) => {
                event.preventDefault();
                lockedShowView(view);
            });
        }
    });

    const lockHashRoute = () => {
        const hashView = (window.location.hash || '').replace(/^#view-/, '').trim();
        lockedShowView(hashView || defaultView);
    };

    window.showView = lockedShowView;
    window.addEventListener('hashchange', lockHashRoute);
    lockedShowView(defaultView);
}
