import { supabase as defaultSupabase } from "./supabaseClient.js";

function norm(value) {
    return String(value || "").trim().toLowerCase().replace(/[\s-]+/g, "_");
}

export function normalizeEmployeeRole(value) {
    const role = norm(value);
    if (role === "supplier_management" || role === "supplier_manager") return "supplier_manager";
    if (role === "order_support") return "order_support";
    return "";
}

export function getEmployeeLoginPath(role) {
    const normalized = normalizeEmployeeRole(role);
    if (normalized === "order_support") return "../employees/order-support-login.html";
    if (normalized === "supplier_manager") return "../employees/supplier-manager-login.html";
    return "../employees/index.html";
}

export function getEmployeePermissions(role) {
    const normalized = normalizeEmployeeRole(role);
    if (normalized === "order_support") {
        return {
            role: "order_support",
            allowedViews: ["orders", "support"],
            defaultView: "orders",
        };
    }

    if (normalized === "supplier_manager") {
        return {
            role: "supplier_manager",
            allowedViews: ["providers", "providerRequests", "itemRequests", "providerMessages"],
            defaultView: "providerRequests",
            fallbackDefaultView: "providers",
        };
    }

    return {
        role: "",
        allowedViews: [],
        defaultView: "orders",
    };
}

export async function getCurrentSession(supabase = defaultSupabase) {
    const { data, error } = await supabase.auth.getSession();
    if (error) return { session: null, error };
    return { session: data?.session || null, error: null };
}

export async function requireEmployeeAccess({
    supabase = defaultSupabase,
    redirect = true,
    fallbackPath = "../employees/index.html",
} = {}) {
    return getEmployeeAccessContext({ supabase, redirect, fallbackPath });
}

export async function getEmployeeAccessContext({
    supabase = defaultSupabase,
    redirect = true,
    fallbackPath = "../employees/index.html",
} = {}) {
    const { session } = await getCurrentSession(supabase);
    if (!session?.user?.id) {
        if (redirect) window.location.href = fallbackPath;
        return { ok: false, error: "No active session" };
    }

    const { data: profile, error } = await supabase
        .from("profiles")
        .select("id, role, employee_role, status, full_name")
        .eq("id", session.user.id)
        .maybeSingle();

    if (error || !profile) {
        if (redirect) {
            await supabase.auth.signOut();
            window.location.href = fallbackPath;
        }
        return { ok: false, error: "Employee profile not found for authenticated user id" };
    }

    const role = norm(profile.role);
    if (role === "admin") {
        if (redirect) window.location.href = "../admin/admin-dashboard-modern.html";
        return { ok: false, isAdmin: true, redirect: "../admin/admin-dashboard-modern.html", session, profile };
    }

    const status = norm(profile.status);
    const normalizedEmployeeRole = normalizeEmployeeRole(profile.employee_role);
    if (role !== "employee" || (status && status !== "active") || !normalizedEmployeeRole) {
        if (redirect) {
            await supabase.auth.signOut();
            window.location.href = fallbackPath;
        }
        return { ok: false, error: "Not an active employee account" };
    }

    const permissions = getEmployeePermissions(normalizedEmployeeRole);
    const hasProviderRequests = typeof document !== "undefined" && !!document.getElementById("view-providerRequests");
    const defaultView =
        permissions.role === "supplier_manager" ? (hasProviderRequests ? "providerRequests" : "providers") : "orders";

    return {
        ok: true,
        session,
        user: {
            id: profile.id,
            email: session.user.email || "",
            full_name: profile.full_name || "",
            role: "employee",
            employee_role_raw: profile.employee_role || "",
            employee_role: normalizedEmployeeRole,
            status: status || "active",
        },
        permissions: {
            ...permissions,
            defaultView,
        },
    };
}

export async function requireRole(requiredRole, loginPath) {
    const need = normalizeEmployeeRole(requiredRole);
    const access = await requireEmployeeAccess({
        supabase: defaultSupabase,
        redirect: false,
    });

    if (!access.ok || access.user?.employee_role !== need) {
        await defaultSupabase.auth.signOut();
        window.location.href = loginPath || getEmployeeLoginPath(requiredRole);
        return null;
    }

    return access.session;
}
