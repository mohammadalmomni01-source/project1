export function applyOrderSupportDashboardLock({ setEmployeeViews, showView } = {}) {
    if (typeof setEmployeeViews === 'function') {
        setEmployeeViews(['orders', 'support'], 'orders');
    }

    const btnDashboard = document.getElementById('nav-dashboard');
    if (btnDashboard) btnDashboard.disabled = true;

    const btnOrders = document.getElementById('nav-orders');
    if (btnOrders) btnOrders.disabled = false;

    const btnUsers = document.getElementById('nav-users');
    if (btnUsers) btnUsers.disabled = true;

    const btnProviders = document.getElementById('nav-providers');
    if (btnProviders) btnProviders.disabled = true;

    const btnProviderRequests = document.getElementById('nav-providerRequests');
    if (btnProviderRequests) btnProviderRequests.disabled = true;

    const btnItemRequests = document.getElementById('nav-itemRequests');
    if (btnItemRequests) btnItemRequests.disabled = true;

    const btnSupport = document.getElementById('nav-support');
    if (btnSupport) btnSupport.disabled = false;

    const btnProviderMessages = document.getElementById('nav-providerMessages');
    if (btnProviderMessages) btnProviderMessages.disabled = true;

    const quickViewOrders = document.getElementById('btn-viewOrders');
    if (quickViewOrders) quickViewOrders.disabled = false;

    const quickManageUsers = document.getElementById('btn-manageUsers');
    if (quickManageUsers) quickManageUsers.disabled = true;

    const quickManageProviders = document.getElementById('btn-manageProviders');
    if (quickManageProviders) quickManageProviders.disabled = true;

    const allowed = new Set(['orders', 'support']);
    const forceOrders = () => {
        if (typeof showView === 'function') showView('orders');
    };

    const lockForbiddenView = () => {
        const current = (window.location.hash || '').replace('#view-', '').trim();
        if (current && !allowed.has(current)) {
            forceOrders();
        }
    };

    const originalShowView = typeof showView === 'function' ? showView : null;
    if (originalShowView) {
        window.showView = (which) => {
            if (!allowed.has(which)) {
                return originalShowView('orders');
            }
            return originalShowView(which);
        };
    }

    window.addEventListener('hashchange', lockForbiddenView);
    lockForbiddenView();
}
