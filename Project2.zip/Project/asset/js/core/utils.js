(function () {
    function escapeHtml(str) {
        return String(str ?? '').replace(/[&<>'\"]/g, (c) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        }[c]));
    }

    function escapeAttr(str) {
        // Safe for putting inside single-quoted attributes
        return String(str ?? '')
            .replace(/&/g, '&amp;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function prettyDate(s) {
        if (!s) return '';
        try { return new Date(s).toLocaleString(); } catch (e) { return String(s); }
    }

    function money(n) {
        // Prefer CustomerStore.money if present for consistency
        if (window.CustomerStore && typeof window.CustomerStore.money === 'function') {
            return window.CustomerStore.money(n);
        }
        const x = Number(n || 0);
        return `$${x.toFixed(2)}`;
    }

    function parseQuery() {
        const out = {};
        try {
            const p = new URLSearchParams(window.location.search);
            for (const [k, v] of p.entries()) out[k] = v;
        } catch (e) { }
        return out;
    }

    window.Utils = { escapeHtml, escapeAttr, prettyDate, money, parseQuery };
})();
