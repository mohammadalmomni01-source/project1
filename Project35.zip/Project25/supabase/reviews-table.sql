-- 1. Create the reviews table
CREATE TABLE public.reviews (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    order_id uuid REFERENCES public.orders(id) ON DELETE CASCADE,
    customer_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
    supplier_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
    product_id uuid REFERENCES public.products(id) ON DELETE CASCADE,
    rating_type text NOT NULL CHECK (rating_type IN ('supplier', 'product')),
    rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment text,
    image_url text, -- Allow customers to upload an image with their review
    created_at timestamp with time zone DEFAULT now()
);

-- 2. Enable RLS (Row Level Security)
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- 3. Create policies
-- Anyone can read reviews
CREATE POLICY "Reviews are viewable by everyone" ON public.reviews
    FOR SELECT USING (true);

-- Customers can insert their own reviews
CREATE POLICY "Customers can insert their own reviews" ON public.reviews
    FOR INSERT WITH CHECK (auth.uid() = customer_id);

-- Customers can update their own reviews
CREATE POLICY "Customers can update their own reviews" ON public.reviews
    FOR UPDATE USING (auth.uid() = customer_id);

-- Customers can delete their own reviews
CREATE POLICY "Customers can delete their own reviews" ON public.reviews
    FOR DELETE USING (auth.uid() = customer_id);
