import { supabase } from "../asset/js/supabaseClient.js";

const EMAIL_SELECTOR = "#email";
const PASSWORD_SELECTOR = "#password";
const LOGIN_SELECTOR = "#loginBtn";
const ERROR_SELECTOR = "#err";

const ROLE_MAP = {
    order_support: {
        dashboard: "../employees/order-support-dashboard.html",
    },
    supplier_management: {
        dashboard: "../employees/supplier-manager-dashboard.html",
    },
};

function getRequiredRole() {
    const path = window.location.pathname.toLowerCase();
    if (path.includes("order-support")) return "order_support";
    if (path.includes("supplier-manager-login") || path.includes("supplier_management")) return "supplier_management";
    return null;
}

function showError(message) {
    const err = document.querySelector(ERROR_SELECTOR);
    if (!err) return;
    err.textContent = message;
    err.style.display = "block";
}

function clearError() {
    const err = document.querySelector(ERROR_SELECTOR);
    if (!err) return;
    err.style.display = "none";
}

function normalizeValue(v) {
    return String(v || "").trim().toLowerCase();
}

function normalizeRole(v) {
    return normalizeValue(v).replace(/[\s-]+/g, "_");
}

async function fetchProfile(userId) {
    let query = await supabase
        .from("profiles")
        .select("role, employee_role, status")
        .eq("id", userId)
        .single();

    if (!query.error) return query;

    const msg = String(query.error.message || "").toLowerCase();
    if (!msg.includes("status") || !msg.includes("does not exist")) {
        return query;
    }

    return await supabase
        .from("profiles")
        .select("role, employee_role")
        .eq("id", userId)
        .single();
}

async function redirectWithFallback(requiredRole) {
    const target = ROLE_MAP[requiredRole]?.dashboard;
    const fallback = "../employees/index.html";
    if (!target) {
        window.location.href = fallback;
        return;
    }

    try {
        const res = await fetch(target, { method: "HEAD", cache: "no-store" });
        if (res.ok) {
            window.location.href = target;
            return;
        }
    } catch (_) { }

    window.location.href = fallback;
}

async function signOutAndReject() {
    try {
        await supabase.auth.signOut();
    } catch (_) { }
    showError("Not authorized");
}

async function handleLogin() {
    clearError();

    const email = (document.querySelector(EMAIL_SELECTOR)?.value || "").trim();
    const password = (document.querySelector(PASSWORD_SELECTOR)?.value || "").trim();
    const requiredRole = getRequiredRole();

    if (!email || !password) {
        showError("Wrong email or password.");
        return;
    }

    const { error: loginError } = await supabase.auth.signInWithPassword({ email, password });
    if (loginError) {
        showError("Wrong email or password.");
        return;
    }

    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;
    if (!session?.user?.id) {
        showError("Wrong email or password.");
        return;
    }

    const { data: profile, error: profileError } = await fetchProfile(session.user.id);
    if (profileError || !profile) {
        await signOutAndReject();
        return;
    }

    const role = normalizeRole(profile.role);
    const employeeRole = normalizeRole(profile.employee_role);

    if (role !== "employee" || !requiredRole || employeeRole !== requiredRole) {
        await signOutAndReject();
        return;
    }

    if (Object.prototype.hasOwnProperty.call(profile, "status")) {
        const status = normalizeValue(profile.status);
        if (status && status !== "active") {
            await signOutAndReject();
            return;
        }
    }

    try {
        localStorage.setItem("employeeLoggedIn", "true");
        localStorage.setItem("employeeRole", employeeRole);
        localStorage.setItem("employeeEmail", session.user.email || email);
        localStorage.removeItem("employeeIntent");
    } catch (_) { }

    await redirectWithFallback(requiredRole);
}

const loginBtn = document.querySelector(LOGIN_SELECTOR);
const emailInput = document.querySelector(EMAIL_SELECTOR);
const passInput = document.querySelector(PASSWORD_SELECTOR);

if (loginBtn) {
    loginBtn.addEventListener("click", handleLogin);
}

if (emailInput) emailInput.addEventListener("input", clearError);
if (passInput) passInput.addEventListener("input", clearError);

document.addEventListener("keydown", (e) => {
    if (e.key === "Enter") handleLogin();
});
