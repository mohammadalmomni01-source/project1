import { supabase } from "./supabaseClient.js";

function withUidTag(notes, uid) {
    const clean = String(notes || "").trim();
    if (!uid) return clean || null;
    const tag = `[uid:${uid}]`;
    return clean ? `${clean} ${tag}` : tag;
}

window.__providerSubmitRequest = async ({ full_name, email, password, phone, company_name, notes }) => {
    try {
        email = (email || "").trim().toLowerCase();
        password = password == null ? "" : String(password);

        if (!email) return { ok: false, error: "Email is required." };
        if (password.length < 6) return { ok: false, error: "Password must be at least 6 characters (without removing spaces)." };

        const signUpRes = await supabase.auth.signUp({
            email,
            password,
            options: {
                data: {
                    full_name: full_name || "",
                    role: "provider_pending"
}
            }
        });

        const signUpError = signUpRes?.error;
        const signUpData = signUpRes?.data;

        if (signUpError) {
            return { ok: false, error: signUpError.message || "Failed to create provider account." };
        }

        const userId = signUpData?.user?.id || signUpData?.session?.user?.id || null;

        // Keep UID in notes so admin approval can sync profiles even if provider_requests lacks user_id column.
        const notesWithUid = withUidTag(notes, userId);

        const payload = {
            full_name: full_name || null,
            email,
            phone: phone || null,
            company_name: company_name || null,
            notes: notesWithUid,
            user_id: userId,
            status: "pending"
        };

        let { error: reqError } = await supabase.from("provider_requests").insert([payload]);

        // Backward compatibility: some schemas do not include user_id yet.
        if (reqError && /column\s+"?user_id"?\s+of\s+relation/i.test(reqError.message || "")) {
            const legacyPayload = { ...payload };
            delete legacyPayload.user_id;
            ({ error: reqError } = await supabase.from("provider_requests").insert([legacyPayload]));
        }

        if (reqError) {
            return { ok: false, error: reqError.message || "Failed to send request." };
        }

        return { ok: true, userId };
    } catch (e) {
        return { ok: false, error: "Failed to send request." };
    }
};




