import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Note: Temporarily bypassing strict Auth since frontend uses localStorage for admin session.
    // Once Supabase Auth is fully integrated in the admin panel, uncomment this block.
    /*
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Missing Authorization header");

    const anonClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user }, error: authError } = await anonClient.auth.getUser();
    if (authError || !user) throw new Error("Not authenticated");

    const { data: profile } = await anonClient
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .maybeSingle();
    if (profile?.role !== "admin") throw new Error("Unauthorized: admin only");
    */

    // Use service role for bypassing RLS
    const sb = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const body = await req.json();
    const { order_id, patch, items, status } = body;

    if (!order_id) throw new Error("order_id is required");

    const results: Record<string, unknown> = {};

    // 1. Update order fields (patch)
    if (patch && Object.keys(patch).length > 0) {
      const safe: Record<string, unknown> = {
        updated_at: new Date().toISOString(),
      };
      if (patch.status != null) safe.status = patch.status;
      if (patch.payment != null) safe.payment_method = patch.payment;
      if (patch.delivery != null) safe.delivery_method = patch.delivery;
      if (patch.customerName != null)
        safe.shipping_full_name = patch.customerName;
      if (patch.customerPhone != null) safe.shipping_phone = patch.customerPhone;
      if (patch.subtotal != null) safe.subtotal = Number(patch.subtotal);
      if (patch.tax != null) safe.tax = Number(patch.tax);
      if (patch.deliveryFee != null)
        safe.delivery_fee = Number(patch.deliveryFee);
      if (patch.total != null) safe.total = Number(patch.total);

      if (patch.shipping) {
        const s = patch.shipping;
        if (s.name != null) safe.shipping_full_name = s.name;
        if (s.phone != null) safe.shipping_phone = s.phone;
        if (s.country != null) safe.shipping_country = s.country;
        if (s.countryCode != null) safe.shipping_country_code = s.countryCode;
        if (s.city != null) safe.shipping_city = s.city;
        if (s.addr != null || s.address != null)
          safe.shipping_address = s.addr ?? s.address;
        if (s.notes != null) safe.shipping_notes = s.notes;
      }

      const { error: ordErr } = await sb
        .from("orders")
        .update(safe)
        .eq("id", order_id);
      if (ordErr) throw new Error("Order update failed: " + ordErr.message);
      results.orderUpdated = true;
    }

    // 2. Replace order_items (full replace)
    if (Array.isArray(items)) {
      const { error: delErr } = await sb
        .from("order_items")
        .delete()
        .eq("order_id", order_id);
      if (delErr)
        throw new Error("Failed to clear items: " + delErr.message);

      if (items.length > 0) {
        const rows = items.map((l: {
          productId?: string;
          itemId?: string;
          productName?: string;
          qty?: number;
          unitPrice?: number;
        }) => ({
          order_id,
          product_id: l.productId && l.productId !== "00000000-0000-0000-0000-000000000000" ? l.productId : null,
          product_name: l.itemId || l.productName || "",
          qty: Number(l.qty ?? 0),
          unit_price: Number(l.unitPrice ?? 0),
        }));

        const { error: insErr } = await sb.from("order_items").insert(rows);
        if (insErr)
          throw new Error("Failed to insert items: " + insErr.message);
      }
      results.itemsUpdated = true;
    }

    // 3. Log status change event (if status changed)
    if (status) {
      await sb
        .from("order_events")
        .insert({
          order_id,
          actor_role: "admin",
          actor_id: null, // user.id, - bypassed for now
          event_type: "status_change",
          message: `Status updated to ${status}`,
          meta: { to: status },
        });
      results.eventLogged = true;
    }

    // 4. Return the updated order with items
    const { data: updatedOrder, error: fetchErr } = await sb
      .from("orders")
      .select("*, order_items(*)")
      .eq("id", order_id)
      .maybeSingle();

    if (fetchErr) throw new Error("Failed to fetch updated order: " + fetchErr.message);

    return new Response(
      JSON.stringify({ ok: true, order: updatedOrder, results }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ ok: false, error: (error as Error).message }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
