(function () {
    async function _sb() {
        let s = window.__supabase;
        if (!s) { await new Promise(r => setTimeout(r, 250)); s = window.__supabase; }
        return s;
    }

    function _mapThread(t, msgs) {
        if (!t) return null;
        return {
            providerId: t.provider_id,
            unreadForStaff: t.unread_for_staff || 0,
            unreadForProvider: t.unread_for_provider || 0,
            autoAckSent: t.auto_ack_sent || false,
            createdAt: t.created_at,
            updatedAt: t.updated_at,
            messages: Array.isArray(msgs) ? msgs : []
        };
    }

    function _mapMsg(m) {
        if (!m) return null;
        return {
            id: m.id,
            fromRole: m.from_role,
            fromId: m.from_id || '',
            fromName: m.from_name || '',
            fromEmail: m.from_email || '',
            text: m.text,
            at: m.created_at,
            isAuto: m.is_auto || false
        };
    }

    // Get or create thread for a provider
    async function _ensureThread(sb, providerId) {
        let { data, error } = await sb.from('staff_chat_threads')
            .select('*').eq('provider_id', providerId).maybeSingle();
        if (!data && !error) {
            const ins = await sb.from('staff_chat_threads')
                .insert({ provider_id: providerId }).select().single();
            data = ins.data;
            error = ins.error;
        }
        return error ? null : data;
    }

    async function listThreads() {
        const sb = await _sb(); if (!sb) return [];
        const { data: threads, error } = await sb.from('staff_chat_threads')
            .select('*').order('updated_at', { ascending: false });
        if (error || !threads) return [];

        // Fetch latest messages for each thread
        const result = [];
        for (const t of threads) {
            const { data: msgs } = await sb.from('staff_chat_messages')
                .select('*').eq('thread_id', t.id).order('created_at', { ascending: true });
            result.push(_mapThread(t, (msgs || []).map(_mapMsg)));
        }
        return result;
    }

    async function getThread(providerId) {
        const sb = await _sb(); if (!sb) return null;
        const { data: t } = await sb.from('staff_chat_threads')
            .select('*').eq('provider_id', providerId).maybeSingle();
        if (!t) return null;
        const { data: msgs } = await sb.from('staff_chat_messages')
            .select('*').eq('thread_id', t.id).order('created_at', { ascending: true });
        return _mapThread(t, (msgs || []).map(_mapMsg));
    }

    async function sendFromProvider(providerId, providerName, text) {
        const sb = await _sb(); if (!sb) return null;
        const thread = await _ensureThread(sb, providerId);
        if (!thread) return null;

        const { data: msg } = await sb.from('staff_chat_messages').insert({
            thread_id: thread.id, from_role: 'provider',
            from_id: providerId, from_name: providerName || 'Provider',
            text: String(text || '').trim()
        }).select().single();

        // Update unread count
        await sb.from('staff_chat_threads')
            .update({ unread_for_staff: (thread.unread_for_staff || 0) + 1 })
            .eq('id', thread.id);

        // Auto-ack on first message
        if (!thread.auto_ack_sent) {
            await sb.from('staff_chat_messages').insert({
                thread_id: thread.id, from_role: 'staff',
                from_id: 'staff', from_name: 'Support Team', is_auto: true,
                text: 'Thanks for reaching out. Our team will respond shortly.'
            });
            await sb.from('staff_chat_threads')
                .update({
                    auto_ack_sent: true,
                    unread_for_provider: (thread.unread_for_provider || 0) + 1
                })
                .eq('id', thread.id);
        }

        return msg ? _mapMsg(msg) : null;
    }

    async function sendFromStaff(providerId, actor, text) {
        const sb = await _sb(); if (!sb) return null;
        const thread = await _ensureThread(sb, providerId);
        if (!thread) return null;

        const { data: msg } = await sb.from('staff_chat_messages').insert({
            thread_id: thread.id,
            from_role: actor?.role || 'staff',
            from_id: actor?.id || 'staff',
            from_name: actor?.name || 'Staff',
            from_email: actor?.email || '',
            text: String(text || '').trim()
        }).select().single();

        await sb.from('staff_chat_threads')
            .update({ unread_for_provider: (thread.unread_for_provider || 0) + 1 })
            .eq('id', thread.id);

        return msg ? _mapMsg(msg) : null;
    }

    async function markReadForStaff(providerId) {
        const sb = await _sb(); if (!sb) return;
        const { data: t } = await sb.from('staff_chat_threads')
            .select('id').eq('provider_id', providerId).maybeSingle();
        if (!t) return;
        await sb.from('staff_chat_threads').update({ unread_for_staff: 0 }).eq('id', t.id);
    }

    async function markReadForProvider(providerId) {
        const sb = await _sb(); if (!sb) return;
        const { data: t } = await sb.from('staff_chat_threads')
            .select('id').eq('provider_id', providerId).maybeSingle();
        if (!t) return;
        await sb.from('staff_chat_threads').update({ unread_for_provider: 0 }).eq('id', t.id);
    }

    function getProviderId() {
        return localStorage.getItem('providerId')
            || localStorage.getItem('loggedInProviderId')
            || localStorage.getItem('currentProviderId')
            || null;
    }

    function getProviderName() {
        return localStorage.getItem('providerName')
            || localStorage.getItem('loggedInProviderName')
            || 'Provider';
    }

    window.StaffChatService = {
        listThreads, getThread, sendFromProvider, sendFromStaff,
        markReadForStaff, markReadForProvider, getProviderId, getProviderName
    };
})();
