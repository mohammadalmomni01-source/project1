// Auto-generated geo data (countries + capital city + dial code where available)
// Used for checkout/admin dropdowns.
// Note: City list contains the capital (demo-friendly) to keep data reliable and lightweight.
(function(){
  const COUNTRIES = [{"code": "AW", "name": "Aruba", "dial": "+297", "cities": ["Oranjestad"]}, {"code": "AF", "name": "Afghanistan", "dial": "+93", "cities": ["Kabul"]}, {"code": "AO", "name": "Angola", "dial": "+244", "cities": ["Luanda"]}, {"code": "AI", "name": "Anguilla", "dial": "+1264", "cities": ["The Valley"]}, {"code": "AX", "name": "Ãland Islands", "dial": "", "cities": []}, {"code": "AL", "name": "Albania", "dial": "+355", "cities": ["Tirana"]}, {"code": "AD", "name": "Andorra", "dial": "", "cities": []}, {"code": "AE", "name": "United Arab Emirates", "dial": "+971", "cities": ["Abu Dhabi"]}, {"code": "AR", "name": "Argentina", "dial": "+54", "cities": ["Buenos Aires"]}, {"code": "AM", "name": "Armenia", "dial": "+374", "cities": ["Yerevan"]}, {"code": "AS", "name": "American Samoa", "dial": "+1684", "cities": ["Pago Pago"]}, {"code": "AQ", "name": "Antarctica", "dial": "", "cities": []}, {"code": "TF", "name": "French Southern Territories", "dial": "+", "cities": ["Port-aux-FranÃ§ais"]}, {"code": "AG", "name": "Antigua and Barbuda", "dial": "+1268", "cities": ["Saint John's"]}, {"code": "AU", "name": "Australia", "dial": "+61", "cities": ["Canberra"]}, {"code": "AT", "name": "Austria", "dial": "+43", "cities": ["Vienna"]}, {"code": "AZ", "name": "Azerbaijan", "dial": "+994", "cities": ["Baku"]}, {"code": "BI", "name": "Burundi", "dial": "+257", "cities": ["Bujumbura"]}, {"code": "BE", "name": "Belgium", "dial": "+32", "cities": ["Brussels"]}, {"code": "BJ", "name": "Benin", "dial": "+229", "cities": ["Porto-Novo"]}, {"code": "BQ", "name": "Bonaire, Sint Eustatius and Saba", "dial": "", "cities": []}, {"code": "BF", "name": "Burkina Faso", "dial": "+226", "cities": ["Ouagadougou"]}, {"code": "BD", "name": "Bangladesh", "dial": "+880", "cities": ["Dhaka"]}, {"code": "BG", "name": "Bulgaria", "dial": "+359", "cities": ["Sofia"]}, {"code": "BH", "name": "Bahrain", "dial": "+973", "cities": ["Manama"]}, {"code": "BS", "name": "Bahamas", "dial": "+1242", "cities": ["Nassau"]}, {"code": "BA", "name": "Bosnia and Herzegovina", "dial": "+387", "cities": ["Sarajevo"]}, {"code": "BL", "name": "Saint BarthÃ©lemy", "dial": "", "cities": []}, {"code": "BY", "name": "Belarus", "dial": "+375", "cities": ["Minsk"]}, {"code": "BZ", "name": "Belize", "dial": "+501", "cities": ["Belmopan"]}, {"code": "BM", "name": "Bermuda", "dial": "+1441", "cities": ["Hamilton"]}, {"code": "BO", "name": "Bolivia", "dial": "+591", "cities": ["Sucre"]}, {"code": "BR", "name": "Brazil", "dial": "+55", "cities": ["BrasÃ­lia"]}, {"code": "BB", "name": "Barbados", "dial": "+1246", "cities": ["Bridgetown"]}, {"code": "BN", "name": "Brunei Darussalam", "dial": "+673", "cities": ["Bandar Seri Begawan"]}, {"code": "BT", "name": "Bhutan", "dial": "+975", "cities": ["Thimphu"]}, {"code": "BV", "name": "Bouvet Island", "dial": "", "cities": []}, {"code": "BW", "name": "Botswana", "dial": "+267", "cities": ["Gaborone"]}, {"code": "CF", "name": "Central African Republic", "dial": "+236", "cities": ["Bangui"]}, {"code": "CA", "name": "Canada", "dial": "+1", "cities": ["Ottawa"]}, {"code": "CC", "name": "Cocos (Keeling) Islands", "dial": "+61", "cities": ["West Island"]}, {"code": "CH", "name": "Switzerland", "dial": "+41", "cities": ["Bern"]}, {"code": "CL", "name": "Chile", "dial": "+56", "cities": ["Santiago"]}, {"code": "CN", "name": "China", "dial": "+86", "cities": ["Beijing"]}, {"code": "CI", "name": "CÃ´te d'Ivoire", "dial": "+225", "cities": ["Yamoussoukro"]}, {"code": "CM", "name": "Cameroon", "dial": "+237", "cities": ["YaoundÃ©"]}, {"code": "CD", "name": "Congo, The Democratic Republic of the", "dial": "+243", "cities": ["Kinshasa"]}, {"code": "CG", "name": "Congo", "dial": "+242", "cities": ["Brazzaville"]}, {"code": "CK", "name": "Cook Islands", "dial": "+682", "cities": ["Avarua"]}, {"code": "CO", "name": "Colombia", "dial": "+57", "cities": ["BogotÃ¡"]}, {"code": "KM", "name": "Comoros", "dial": "+269", "cities": ["Moroni"]}, {"code": "CV", "name": "Cabo Verde", "dial": "+238", "cities": ["Praia"]}, {"code": "CR", "name": "Costa Rica", "dial": "+506", "cities": ["San JosÃ©"]}, {"code": "CU", "name": "Cuba", "dial": "+53", "cities": ["Havana"]}, {"code": "CW", "name": "CuraÃ§ao", "dial": "", "cities": []}, {"code": "CX", "name": "Christmas Island", "dial": "+61", "cities": ["Flying Fish Cove"]}, {"code": "KY", "name": "Cayman Islands", "dial": "+1345", "cities": ["George Town"]}, {"code": "CY", "name": "Cyprus", "dial": "+357", "cities": ["Nicosia"]}, {"code": "CZ", "name": "Czechia", "dial": "+420", "cities": ["Prague"]}, {"code": "DE", "name": "Germany", "dial": "+49", "cities": ["Berlin"]}, {"code": "DJ", "name": "Djibouti", "dial": "+253", "cities": ["Djibouti"]}, {"code": "DM", "name": "Dominica", "dial": "+1767", "cities": ["Roseau"]}, {"code": "DK", "name": "Denmark", "dial": "+45", "cities": ["Copenhagen"]}, {"code": "DO", "name": "Dominican Republic", "dial": "+1809", "cities": ["Santo Domingo"]}, {"code": "DZ", "name": "Algeria", "dial": "+213", "cities": ["Algiers"]}, {"code": "EC", "name": "Ecuador", "dial": "+593", "cities": ["Quito"]}, {"code": "EG", "name": "Egypt", "dial": "+20", "cities": ["Cairo"]}, {"code": "ER", "name": "Eritrea", "dial": "+291", "cities": ["Asmara"]}, {"code": "EH", "name": "Western Sahara", "dial": "+212", "cities": ["El AaiÃºn"]}, {"code": "ES", "name": "Spain", "dial": "+34", "cities": ["Madrid"]}, {"code": "EE", "name": "Estonia", "dial": "+372", "cities": ["Tallinn"]}, {"code": "ET", "name": "Ethiopia", "dial": "+251", "cities": ["Addis Ababa"]}, {"code": "FI", "name": "Finland", "dial": "+358", "cities": ["Helsinki"]}, {"code": "FJ", "name": "Fiji", "dial": "+679", "cities": ["Suva"]}, {"code": "FK", "name": "Falkland Islands (Malvinas)", "dial": "+500", "cities": ["Stanley"]}, {"code": "FR", "name": "France", "dial": "+33", "cities": ["Paris"]}, {"code": "FO", "name": "Faroe Islands", "dial": "+298", "cities": ["TÃ³rshavn"]}, {"code": "FM", "name": "Micronesia, Federated States of", "dial": "+691", "cities": ["Palikir"]}, {"code": "GA", "name": "Gabon", "dial": "+241", "cities": ["Libreville"]}, {"code": "GB", "name": "United Kingdom", "dial": "+44", "cities": ["London"]}, {"code": "GE", "name": "Georgia", "dial": "+995", "cities": ["Tbilisi"]}, {"code": "GG", "name": "Guernsey", "dial": "+44", "cities": ["St. Peter Port"]}, {"code": "GH", "name": "Ghana", "dial": "+233", "cities": ["Accra"]}, {"code": "GI", "name": "Gibraltar", "dial": "+350", "cities": ["Gibraltar"]}, {"code": "GN", "name": "Guinea", "dial": "+224", "cities": ["Conakry"]}, {"code": "GP", "name": "Guadeloupe", "dial": "+590", "cities": ["Basse-Terre"]}, {"code": "GM", "name": "Gambia", "dial": "+220", "cities": ["Banjul"]}, {"code": "GW", "name": "Guinea-Bissau", "dial": "+245", "cities": ["Bissau"]}, {"code": "GQ", "name": "Equatorial Guinea", "dial": "+240", "cities": ["Malabo"]}, {"code": "GR", "name": "Greece", "dial": "+30", "cities": ["Athens"]}, {"code": "GD", "name": "Grenada", "dial": "+1473", "cities": ["St. George's"]}, {"code": "GL", "name": "Greenland", "dial": "+299", "cities": ["Nuuk"]}, {"code": "GT", "name": "Guatemala", "dial": "+502", "cities": ["Guatemala City"]}, {"code": "GF", "name": "French Guiana", "dial": "+594", "cities": ["Cayenne"]}, {"code": "GU", "name": "Guam", "dial": "+1671", "cities": ["HagÃ¥tÃ±a"]}, {"code": "GY", "name": "Guyana", "dial": "+592", "cities": ["Georgetown"]}, {"code": "HK", "name": "Hong Kong", "dial": "+852", "cities": ["City of Victoria"]}, {"code": "HM", "name": "Heard Island and McDonald Islands", "dial": "+", "cities": []}, {"code": "HN", "name": "Honduras", "dial": "+504", "cities": ["Tegucigalpa"]}, {"code": "HR", "name": "Croatia", "dial": "+385", "cities": ["Zagreb"]}, {"code": "HT", "name": "Haiti", "dial": "+509", "cities": ["Port-au-Prince"]}, {"code": "HU", "name": "Hungary", "dial": "+36", "cities": ["Budapest"]}, {"code": "ID", "name": "Indonesia", "dial": "+62", "cities": ["Jakarta"]}, {"code": "IM", "name": "Isle of Man", "dial": "+44", "cities": ["Douglas"]}, {"code": "IN", "name": "India", "dial": "+91", "cities": ["New Delhi"]}, {"code": "IO", "name": "British Indian Ocean Territory", "dial": "+246", "cities": ["Diego Garcia"]}, {"code": "IE", "name": "Ireland", "dial": "+353", "cities": ["Dublin"]}, {"code": "IR", "name": "Iran, Islamic Republic of", "dial": "+98", "cities": ["Tehran"]}, {"code": "IQ", "name": "Iraq", "dial": "+964", "cities": ["Baghdad"]}, {"code": "IS", "name": "Iceland", "dial": "+354", "cities": ["Reykjavik"]}, {"code": "IT", "name": "Italy", "dial": "+39", "cities": ["Rome"]}, {"code": "JM", "name": "Jamaica", "dial": "+1876", "cities": ["Kingston"]}, {"code": "JE", "name": "Jersey", "dial": "+44", "cities": ["Saint Helier"]}, {"code": "JO", "name": "Jordan", "dial": "+962", "cities": ["Amman"]}, {"code": "JP", "name": "Japan", "dial": "+81", "cities": ["Tokyo"]}, {"code": "KZ", "name": "Kazakhstan", "dial": "+76", "cities": ["Astana"]}, {"code": "KE", "name": "Kenya", "dial": "+254", "cities": ["Nairobi"]}, {"code": "KG", "name": "Kyrgyzstan", "dial": "+996", "cities": ["Bishkek"]}, {"code": "KH", "name": "Cambodia", "dial": "+855", "cities": ["Phnom Penh"]}, {"code": "KI", "name": "Kiribati", "dial": "+686", "cities": ["South Tarawa"]}, {"code": "KN", "name": "Saint Kitts and Nevis", "dial": "+1869", "cities": ["Basseterre"]}, {"code": "KR", "name": "Korea, Republic of", "dial": "+82", "cities": ["Seoul"]}, {"code": "KW", "name": "Kuwait", "dial": "+965", "cities": ["Kuwait City"]}, {"code": "LA", "name": "Lao People's Democratic Republic", "dial": "+856", "cities": ["Vientiane"]}, {"code": "LB", "name": "Lebanon", "dial": "+961", "cities": ["Beirut"]}, {"code": "LR", "name": "Liberia", "dial": "+231", "cities": ["Monrovia"]}, {"code": "LY", "name": "Libya", "dial": "+218", "cities": ["Tripoli"]}, {"code": "LC", "name": "Saint Lucia", "dial": "+1758", "cities": ["Castries"]}, {"code": "LI", "name": "Liechtenstein", "dial": "+423", "cities": ["Vaduz"]}, {"code": "LK", "name": "Sri Lanka", "dial": "+94", "cities": ["Colombo"]}, {"code": "LS", "name": "Lesotho", "dial": "+266", "cities": ["Maseru"]}, {"code": "LT", "name": "Lithuania", "dial": "+370", "cities": ["Vilnius"]}, {"code": "LU", "name": "Luxembourg", "dial": "+352", "cities": ["Luxembourg"]}, {"code": "LV", "name": "Latvia", "dial": "+371", "cities": ["Riga"]}, {"code": "MO", "name": "Macao", "dial": "+853", "cities": []}, {"code": "MF", "name": "Saint Martin (French part)", "dial": "", "cities": []}, {"code": "MA", "name": "Morocco", "dial": "+212", "cities": ["Rabat"]}, {"code": "MC", "name": "Monaco", "dial": "+377", "cities": ["Monaco"]}, {"code": "MD", "name": "Moldova", "dial": "+373", "cities": ["ChiÈinÄu"]}, {"code": "MG", "name": "Madagascar", "dial": "+261", "cities": ["Antananarivo"]}, {"code": "MV", "name": "Maldives", "dial": "+960", "cities": ["MalÃ©"]}, {"code": "MX", "name": "Mexico", "dial": "+52", "cities": ["Mexico City"]}, {"code": "MH", "name": "Marshall Islands", "dial": "+692", "cities": ["Majuro"]}, {"code": "MK", "name": "North Macedonia", "dial": "+389", "cities": ["Skopje"]}, {"code": "ML", "name": "Mali", "dial": "+223", "cities": ["Bamako"]}, {"code": "MT", "name": "Malta", "dial": "+356", "cities": ["Valletta"]}, {"code": "MM", "name": "Myanmar", "dial": "", "cities": []}, {"code": "ME", "name": "Montenegro", "dial": "", "cities": []}, {"code": "MN", "name": "Mongolia", "dial": "+976", "cities": ["Ulan Bator"]}, {"code": "MP", "name": "Northern Mariana Islands", "dial": "+1670", "cities": ["Saipan"]}, {"code": "MZ", "name": "Mozambique", "dial": "+258", "cities": ["Maputo"]}, {"code": "MR", "name": "Mauritania", "dial": "+222", "cities": ["Nouakchott"]}, {"code": "MS", "name": "Montserrat", "dial": "+1664", "cities": ["Plymouth"]}, {"code": "MQ", "name": "Martinique", "dial": "+596", "cities": ["Fort-de-France"]}, {"code": "MU", "name": "Mauritius", "dial": "+230", "cities": ["Port Louis"]}, {"code": "MW", "name": "Malawi", "dial": "+265", "cities": ["Lilongwe"]}, {"code": "MY", "name": "Malaysia", "dial": "+60", "cities": ["Kuala Lumpur"]}, {"code": "YT", "name": "Mayotte", "dial": "+262", "cities": ["Mamoudzou"]}, {"code": "NA", "name": "Namibia", "dial": "+264", "cities": ["Windhoek"]}, {"code": "NC", "name": "New Caledonia", "dial": "+687", "cities": ["NoumÃ©a"]}, {"code": "NE", "name": "Niger", "dial": "+227", "cities": ["Niamey"]}, {"code": "NF", "name": "Norfolk Island", "dial": "+672", "cities": ["Kingston"]}, {"code": "NG", "name": "Nigeria", "dial": "+234", "cities": ["Abuja"]}, {"code": "NI", "name": "Nicaragua", "dial": "+505", "cities": ["Managua"]}, {"code": "NU", "name": "Niue", "dial": "+683", "cities": ["Alofi"]}, {"code": "NL", "name": "Netherlands", "dial": "+31", "cities": ["Amsterdam"]}, {"code": "NO", "name": "Norway", "dial": "+47", "cities": ["Oslo"]}, {"code": "NP", "name": "Nepal", "dial": "+977", "cities": ["Kathmandu"]}, {"code": "NR", "name": "Nauru", "dial": "+674", "cities": ["Yaren"]}, {"code": "NZ", "name": "New Zealand", "dial": "+64", "cities": ["Wellington"]}, {"code": "OM", "name": "Oman", "dial": "+968", "cities": ["Muscat"]}, {"code": "PK", "name": "Pakistan", "dial": "+92", "cities": ["Islamabad"]}, {"code": "PA", "name": "Panama", "dial": "+507", "cities": ["Panama City"]}, {"code": "PN", "name": "Pitcairn", "dial": "+64", "cities": ["Adamstown"]}, {"code": "PE", "name": "Peru", "dial": "+51", "cities": ["Lima"]}, {"code": "PH", "name": "Philippines", "dial": "+63", "cities": ["Manila"]}, {"code": "PW", "name": "Palau", "dial": "+680", "cities": ["Ngerulmud"]}, {"code": "PG", "name": "Papua New Guinea", "dial": "+675", "cities": ["Port Moresby"]}, {"code": "PL", "name": "Poland", "dial": "+48", "cities": ["Warsaw"]}, {"code": "PR", "name": "Puerto Rico", "dial": "+1787", "cities": ["San Juan"]}, {"code": "KP", "name": "Korea, Democratic People's Republic of", "dial": "+850", "cities": ["Pyongyang"]}, {"code": "PT", "name": "Portugal", "dial": "+351", "cities": ["Lisbon"]}, {"code": "PY", "name": "Paraguay", "dial": "+595", "cities": ["AsunciÃ³n"]}, {"code": "PS", "name": "Palestine, State of", "dial": "", "cities": []}, {"code": "PF", "name": "French Polynesia", "dial": "+689", "cities": ["PapeetÄ"]}, {"code": "QA", "name": "Qatar", "dial": "+974", "cities": ["Doha"]}, {"code": "RE", "name": "RÃ©union", "dial": "+262", "cities": ["Saint-Denis"]}, {"code": "RO", "name": "Romania", "dial": "+40", "cities": ["Bucharest"]}, {"code": "RU", "name": "Russian Federation", "dial": "+7", "cities": ["Moscow"]}, {"code": "RW", "name": "Rwanda", "dial": "+250", "cities": ["Kigali"]}, {"code": "SA", "name": "Saudi Arabia", "dial": "+966", "cities": ["Riyadh"]}, {"code": "SD", "name": "Sudan", "dial": "+249", "cities": ["Khartoum"]}, {"code": "SN", "name": "Senegal", "dial": "+221", "cities": ["Dakar"]}, {"code": "SG", "name": "Singapore", "dial": "+65", "cities": ["Singapore"]}, {"code": "GS", "name": "South Georgia and the South Sandwich Islands", "dial": "+500", "cities": ["King Edward Point"]}, {"code": "SH", "name": "Saint Helena, Ascension and Tristan da Cunha", "dial": "+290", "cities": ["Jamestown"]}, {"code": "SJ", "name": "Svalbard and Jan Mayen", "dial": "+4779", "cities": ["Longyearbyen"]}, {"code": "SB", "name": "Solomon Islands", "dial": "+677", "cities": ["Honiara"]}, {"code": "SL", "name": "Sierra Leone", "dial": "+232", "cities": ["Freetown"]}, {"code": "SV", "name": "El Salvador", "dial": "+503", "cities": ["San Salvador"]}, {"code": "SM", "name": "San Marino", "dial": "+378", "cities": ["City of San Marino"]}, {"code": "SO", "name": "Somalia", "dial": "+252", "cities": ["Mogadishu"]}, {"code": "PM", "name": "Saint Pierre and Miquelon", "dial": "+508", "cities": ["Saint-Pierre"]}, {"code": "RS", "name": "Serbia", "dial": "", "cities": []}, {"code": "SS", "name": "South Sudan", "dial": "+211", "cities": ["Juba"]}, {"code": "ST", "name": "Sao Tome and Principe", "dial": "+239", "cities": ["SÃ£o TomÃ©"]}, {"code": "SR", "name": "Suriname", "dial": "+597", "cities": ["Paramaribo"]}, {"code": "SK", "name": "Slovakia", "dial": "+421", "cities": ["Bratislava"]}, {"code": "SI", "name": "Slovenia", "dial": "+386", "cities": ["Ljubljana"]}, {"code": "SE", "name": "Sweden", "dial": "+46", "cities": ["Stockholm"]}, {"code": "SZ", "name": "Eswatini", "dial": "+268", "cities": ["Lobamba"]}, {"code": "SX", "name": "Sint Maarten (Dutch part)", "dial": "", "cities": []}, {"code": "SC", "name": "Seychelles", "dial": "+248", "cities": ["Victoria"]}, {"code": "SY", "name": "Syrian Arab Republic", "dial": "+963", "cities": ["Damascus"]}, {"code": "TC", "name": "Turks and Caicos Islands", "dial": "", "cities": []}, {"code": "TD", "name": "Chad", "dial": "+235", "cities": ["N'Djamena"]}, {"code": "TG", "name": "Togo", "dial": "+228", "cities": ["LomÃ©"]}, {"code": "TH", "name": "Thailand", "dial": "+66", "cities": ["Bangkok"]}, {"code": "TJ", "name": "Tajikistan", "dial": "+992", "cities": ["Dushanbe"]}, {"code": "TK", "name": "Tokelau", "dial": "+690", "cities": ["Fakaofo"]}, {"code": "TM", "name": "Turkmenistan", "dial": "+993", "cities": ["Ashgabat"]}, {"code": "TL", "name": "Timor-Leste", "dial": "+670", "cities": ["Dili"]}, {"code": "TO", "name": "Tonga", "dial": "+676", "cities": ["Nuku'alofa"]}, {"code": "TT", "name": "Trinidad and Tobago", "dial": "+1868", "cities": ["Port of Spain"]}, {"code": "TN", "name": "Tunisia", "dial": "+216", "cities": ["Tunis"]}, {"code": "TR", "name": "Turkey", "dial": "+90", "cities": ["Ankara"]}, {"code": "TV", "name": "Tuvalu", "dial": "+688", "cities": ["Funafuti"]}, {"code": "TW", "name": "Taiwan", "dial": "+886", "cities": ["Taipei"]}, {"code": "TZ", "name": "Tanzania", "dial": "+255", "cities": ["Dodoma"]}, {"code": "UG", "name": "Uganda", "dial": "+256", "cities": ["Kampala"]}, {"code": "UA", "name": "Ukraine", "dial": "+380", "cities": ["Kiev"]}, {"code": "UM", "name": "United States Minor Outlying Islands", "dial": "", "cities": []}, {"code": "UY", "name": "Uruguay", "dial": "+598", "cities": ["Montevideo"]}, {"code": "US", "name": "United States", "dial": "+1", "cities": ["Washington D.C."]}, {"code": "UZ", "name": "Uzbekistan", "dial": "+998", "cities": ["Tashkent"]}, {"code": "VA", "name": "Holy See (Vatican City State)", "dial": "", "cities": []}, {"code": "VC", "name": "Saint Vincent and the Grenadines", "dial": "+1784", "cities": ["Kingstown"]}, {"code": "VE", "name": "Venezuela", "dial": "+58", "cities": ["Caracas"]}, {"code": "VG", "name": "Virgin Islands, British", "dial": "", "cities": []}, {"code": "VI", "name": "Virgin Islands, U.S.", "dial": "", "cities": []}, {"code": "VN", "name": "Vietnam", "dial": "+84", "cities": ["Hanoi"]}, {"code": "VU", "name": "Vanuatu", "dial": "+678", "cities": ["Port Vila"]}, {"code": "WF", "name": "Wallis and Futuna", "dial": "+681", "cities": ["Mata-Utu"]}, {"code": "WS", "name": "Samoa", "dial": "+685", "cities": ["Apia"]}, {"code": "YE", "name": "Yemen", "dial": "+967", "cities": ["Sana'a"]}, {"code": "ZA", "name": "South Africa", "dial": "+27", "cities": ["Pretoria"]}, {"code": "ZM", "name": "Zambia", "dial": "+260", "cities": ["Lusaka"]}, {"code": "ZW", "name": "Zimbabwe", "dial": "+263", "cities": ["Harare"]}];

  // Data patches for a few places where upstream metadata can be missing in offline datasets
  (function patch(){
    const byCode = (code)=>COUNTRIES.find(c=>c.code===code);
    const set = (code, patch)=>{ const c=byCode(code); if(!c) return; Object.assign(c, patch); };

    set('PS', { name:'Palestine', dial:'+970', cities:['Jerusalem','Ramallah','Nablus','Hebron','Gaza'] });
    set('AD', { dial:'+376', cities:['Andorra la Vella'] });

    // MENA (common city lists)
    // Use double-quoted city strings to safely handle apostrophes.
    set('JO', { cities:["Amman","Zarqa","Irbid","Aqaba","Salt","Madaba","Karak","Jerash","Ajloun","Ma'an"] });
    set('AE', { cities:['Abu Dhabi','Dubai','Sharjah','Ajman','Ras Al Khaimah','Fujairah','Umm Al Quwain'] });
    set('SA', { cities:['Riyadh','Jeddah','Mecca','Medina','Dammam','Khobar','Taif','Tabuk','Abha','Buraidah'] });
    set('EG', { cities:['Cairo','Alexandria','Giza','Sharm El Sheikh','Luxor','Aswan','Port Said','Suez','Tanta'] });
    set('IQ', { cities:['Baghdad','Basra','Mosul','Erbil','Najaf','Karbala','Kirkuk','Sulaymaniyah'] });
    set('LB', { cities:['Beirut','Tripoli','Sidon','Tyre','Byblos','Zahle','Baalbek'] });
    set('SY', { cities:['Damascus','Aleppo','Homs','Latakia','Hama','Tartus','Deir ez-Zor'] });
    set('QA', { cities:['Doha','Al Rayyan','Al Wakrah','Al Khor'] });
    set('KW', { cities:['Kuwait City','Al Ahmadi','Hawalli','Salmiya','Farwaniya'] });
    set('BH', { cities:['Manama','Muharraq','Riffa','Isa Town','Sitra'] });
    set('OM', { cities:['Muscat','Salalah','Sohar','Nizwa','Sur'] });
    set('YE', { cities:["Sana'a","Aden","Taiz","Al Hudaydah","Ibb","Mukalla"] });
    set('MA', { cities:['Rabat','Casablanca','Marrakesh','Fes','Tangier','Agadir','Oujda'] });
    set('DZ', { cities:['Algiers','Oran','Constantine','Annaba','Blida','Setif'] });
    set('TN', { cities:['Tunis','Sfax','Sousse','Kairouan','Bizerte','Gabes'] });
    set('LY', { cities:['Tripoli','Benghazi','Misrata','Sabha','Zawiya'] });

    // Clean obviously-invalid dial codes like '+'
    for(const c of COUNTRIES){
      if(c.dial && String(c.dial).trim() === "+") c.dial="";
    }
  })();

  function norm(s){ return String(s||'').trim().toLowerCase(); }

  function getCountryByCode(code){
    if(!code) return null;
    const c = COUNTRIES.find(x => x.code === code);
    return c || null;
  }

  function getCountryByName(name){
    if(!name) return null;
    const n = norm(name);
    return COUNTRIES.find(x => norm(x.name) === n) || null;
  }

  function renderCountryOptions(selectEl, selectedCode){
    if(!selectEl) return;
    selectEl.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = 'Select country';
    selectEl.appendChild(opt0);
    for(const c of COUNTRIES){
      const o = document.createElement('option');
      o.value = c.code;
      o.textContent = c.name;
      if(selectedCode && selectedCode === c.code) o.selected = true;
      selectEl.appendChild(o);
    }
  }

  function renderCityOptions(citySelectEl, countryCode, selectedCity){
    if(!citySelectEl) return;
    citySelectEl.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = countryCode ? 'Select city' : 'Select country first';
    citySelectEl.appendChild(opt0);

    const c = getCountryByCode(countryCode);
    if(!c) return;

    const list = Array.isArray(c.cities) ? c.cities : [];
    for(const name of list){
      const o = document.createElement('option');
      o.value = name;
      o.textContent = name;
      if(selectedCity && norm(selectedCity) === norm(name)) o.selected = true;
      citySelectEl.appendChild(o);
    }

    // Keep legacy / custom city if it exists (so we never lose data)
    if(selectedCity && selectedCity.trim() && !list.some(x => norm(x) === norm(selectedCity))){
      const o = document.createElement('option');
      o.value = selectedCity;
      o.textContent = selectedCity;
      o.selected = true;
      citySelectEl.appendChild(o);
    }
  }

  function applyDialForCountry(countryCode, phoneInputEl, state){
    // state is an object you hold outside: {prevDial:null}
    if(!phoneInputEl) return;
    const c = getCountryByCode(countryCode);
    const dial = c && c.dial ? c.dial : '';
    if(!dial){ if(state) state.prevDial = null; return; }

    const v = String(phoneInputEl.value || '').trim();
    if(!v){
      phoneInputEl.value = dial + ' ';
    }else if(state && state.prevDial && v.startsWith(state.prevDial)){
      phoneInputEl.value = dial + v.slice(state.prevDial.length);
    }else if(!v.startsWith('+')){
      phoneInputEl.value = dial + ' ' + v;
    }
    if(state) state.prevDial = dial;
  }

  function bindCountryCity(countrySelectEl, citySelectEl, opts){
    const o = opts || {};
    const initCountry = o.initialCountryCode || '';
    const initCity = o.initialCity || '';

    renderCountryOptions(countrySelectEl, initCountry);
    renderCityOptions(citySelectEl, countrySelectEl ? countrySelectEl.value : initCountry, initCity);

    if(countrySelectEl){
      countrySelectEl.addEventListener('change', ()=>{
        renderCityOptions(citySelectEl, countrySelectEl.value, '');
        if(typeof o.onCountryChange === 'function'){
          o.onCountryChange(countrySelectEl.value);
        }
      });
    }
  }

  window.GeoData = {
    COUNTRIES,
    getCountryByCode,
    getCountryByName,
    renderCountryOptions,
    renderCityOptions,
    applyDialForCountry,
    bindCountryCity
  };
})();
