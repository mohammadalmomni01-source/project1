import { supabase } from "./supabaseClient.js";

const LOGIN_PATH = "customer-login.html";

const JORDAN_CITIES = [
    "Amman", "Zarqa", "Irbid", "Mafraq", "Ajloun",
    "Jerash", "Madaba", "Balqa", "Karak", "Tafileh", "Maan", "Aqaba"
];

const els = {
    guestNote: document.getElementById("guestNote"),
    name: document.getElementById("name"),
    email: document.getElementById("email"),
    type: document.getElementById("type"),
    phone: document.getElementById("phone"),
    city: document.getElementById("city"),
    location: document.getElementById("location"),
    address: document.getElementById("address"),
    save: document.getElementById("save"),
    change: document.getElementById("change"),
    logout: document.getElementById("logout"),
    info: document.getElementById("info"),
};

// Pre-select the saved city in the Jordan city dropdown
function renderCities(selectedCity) {
    if (!els.city) return;
    const options = Array.from(els.city.options);
    const match = options.find(o => o.value.toLowerCase() === (selectedCity || "").toLowerCase());
    if (match) match.selected = true;
}

// Enforce +962 prefix on the phone field
function enforceJordanPhone() {
    if (!els.phone) return;
    const raw = (els.phone.value || "").trim();
    if (!raw || raw === "+962" || raw === "+962 ") return;
    if (!raw.startsWith("+962")) {
        const digits = raw.replace(/^\+?\d{1,3}\s?/, "").replace(/\D/g, "");
        els.phone.value = "+962 " + digits;
    }
}

function setInfo(text) {
    if (els.info) els.info.textContent = text || "";
}

function redirectToLogin() {
    window.location.href = LOGIN_PATH;
}

function saveLocalSession(partial) {
    try {
        if (!window.CustomerStore) return;
        const current = window.CustomerStore.load(window.CustomerStore.K.session, null) || {};
        window.CustomerStore.save(window.CustomerStore.K.session, { ...current, ...partial });
    } catch (_) {
        // no-op
    }
}

async function loadProfile() {
    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;

    if (!session) {
        redirectToLogin();
        return;
    }

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData?.user) {
        redirectToLogin();
        return;
    }

    const user = userData.user;

    const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("id, role, full_name, org_type, phone, address, country, city")
        .eq("id", user.id)
        .single();

    if (profileError) {
        alert(profileError.message || "Failed to load profile.");
        return;
    }

    if (!profile || profile.role !== "customer") {
        await supabase.auth.signOut();
        redirectToLogin();
        return;
    }

    if (els.guestNote) els.guestNote.style.display = "none";
    if (els.name) {
        els.name.disabled = false;
        els.name.value = profile.full_name || user.user_metadata?.full_name || "";
    }
    if (els.email) els.email.value = user.email || "";
    if (els.type) els.type.value = profile.org_type || "Small Lab";
    if (els.address) els.address.value = profile.address || "";

    // Phone: enforce +962 prefix
    if (els.phone) {
        const savedPhone = profile.phone || "";
        if (savedPhone && savedPhone.startsWith("+962")) {
            els.phone.value = savedPhone;
        } else if (savedPhone) {
            const digits = savedPhone.replace(/^\+?962?/, "").replace(/\D/g, "");
            els.phone.value = "+962 " + digits;
        } else {
            els.phone.value = "+962 ";
        }
        els.phone.addEventListener("blur", enforceJordanPhone);
        els.phone.addEventListener("focus", () => {
            if (!els.phone.value || els.phone.value.trim() === "") {
                els.phone.value = "+962 ";
            }
        });
    }

    // City: pre-select from profile
    renderCities(profile.city || "");

    // Update location field if present
    if (els.location) {
        els.location.value = profile.city ? profile.city + ", Jordan" : "";
    }

    saveLocalSession({
        loggedIn: true,
        id: user.id,
        email: user.email || "",
        name: profile.full_name || user.user_metadata?.full_name || "Customer",
        orgType: profile.org_type || null,
        phone: profile.phone || "",
        address: profile.address || "",
        country: "Jordan",
        city: profile.city || "",
        location: profile.city ? profile.city + ", Jordan" : "",
    });

    // Update location when city changes
    if (els.city) {
        els.city.addEventListener("change", () => {
            if (els.location) {
                els.location.value = els.city.value ? els.city.value + ", Jordan" : "";
            }
        });
    }

    if (els.save) {
        els.save.addEventListener("click", async () => {
            setInfo("");

            const fullName = (els.name?.value || "").trim();
            const orgType = els.type?.value || "Small Lab";
            const phone = (els.phone?.value || "").trim().replace(/\s+/g, "");
            const address = (els.address?.value || "").trim();
            const city = els.city?.value || "";
            const country = "Jordan";

            // Validate phone
            if (phone && !/^\+962\d{8,9}$/.test(phone)) {
                setInfo("Please enter a valid Jordanian phone number (e.g. +962 79 123 4567).");
                return;
            }

            const { error: authUpdateError } = await supabase.auth.updateUser({
                data: { full_name: fullName },
            });

            if (authUpdateError) {
                alert(authUpdateError.message || "Failed to update auth profile.");
                return;
            }

            const { error: profileUpdateError } = await supabase
                .from("profiles")
                .update({
                    full_name: fullName,
                    org_type: orgType,
                    phone,
                    address,
                    country,
                    city,
                })
                .eq("id", user.id);

            if (profileUpdateError) {
                alert(profileUpdateError.message || "Failed to save profile.");
                return;
            }

            if (els.location) {
                els.location.value = city ? city + ", Jordan" : "";
            }

            saveLocalSession({
                name: fullName,
                orgType,
                phone,
                address,
                country,
                city,
                location: city ? city + ", Jordan" : "",
            });

            setInfo("Saved. Your profile is synced.");
        });
    }
}

if (els.change) {
    els.change.addEventListener("click", async () => {
        const ok = window.confirm("Are you sure you want to delete your account? This cannot be undone.");
        if (!ok) return;

        const { data: sessionData } = await supabase.auth.getSession();
        const session = sessionData?.session;
        if (!session) {
            alert("Please login again.");
            window.location.href = "customer-login.html";
            return;
        }

        const { error } = await supabase.functions.invoke("delete-account", {
            headers: { Authorization: `Bearer ${session.access_token}` },
        });

        if (error) {
            alert(error.message || "Failed to delete account.");
            return;
        }

        alert("Account deleted successfully.");
        await supabase.auth.signOut();
        window.location.href = "customer-login.html";
    });
}

if (els.logout) {
    els.logout.addEventListener("click", async (e) => {
        e.preventDefault();
        if (window.confirm("Logout?")) {
            await supabase.auth.signOut();
            try {
                if (window.CustomerStore) {
                    window.CustomerStore.save(window.CustomerStore.K.session, null);
                }
            } catch (_) {
                // no-op
            }
            redirectToLogin();
        }
    });
}

loadProfile();