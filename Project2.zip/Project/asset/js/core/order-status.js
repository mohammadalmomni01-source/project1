(function () {
    const STATUS_FLOW = ['Pending', 'Confirmed', 'Preparing', 'Shipped', 'Delivered'];
    const ALL_STATUSES = [...STATUS_FLOW, 'Cancelled'];

    const ALLOWED_TRANSITIONS_PROVIDER = {
        Pending: ['Confirmed', 'Cancelled'],
        Confirmed: ['Preparing', 'Cancelled'],
        Preparing: ['Shipped', 'Cancelled'],
        Shipped: ['Delivered'],
        Delivered: [],
        Cancelled: []
    };

    function normalizeStatus(s) {
        const x = String(s || 'Pending').trim();
        const map = {
            pending: 'Pending',
            confirmed: 'Confirmed',
            processing: 'Preparing',
            preparing: 'Preparing',
            shipping: 'Shipped',
            shipped: 'Shipped',
            delivered: 'Delivered',
            cancelled: 'Cancelled',
            canceled: 'Cancelled'
        };
        const k = x.toLowerCase();
        return map[k] || (ALL_STATUSES.includes(x) ? x : 'Pending');
    }

    function providerNext(from) {
        return (ALLOWED_TRANSITIONS_PROVIDER[normalizeStatus(from)] || []).slice();
    }

    function canProviderTransition(from, to) {
        const f = normalizeStatus(from);
        const t = normalizeStatus(to);
        return (ALLOWED_TRANSITIONS_PROVIDER[f] || []).includes(t);
    }

    function customerCanCancel(status) {
        const st = normalizeStatus(status);
        return st === 'Pending' || st === 'Confirmed';
    }

    function customerCanConfirmDelivered(status) {
        return normalizeStatus(status) === 'Shipped';
    }

    function badgeClass(status) {
        const st = normalizeStatus(status);
        if (st === 'Delivered') return 'ok';
        if (st === 'Cancelled') return 'bad';
        if (st === 'Pending' || st === 'Confirmed' || st === 'Preparing' || st === 'Shipped') return 'warn';
        return '';
    }

    window.OrderStatus = {
        STATUS_FLOW,
        ALL_STATUSES,
        normalizeStatus,
        providerNext,
        canProviderTransition,
        customerCanCancel,
        customerCanConfirmDelivered,
        badgeClass
    };
})();
