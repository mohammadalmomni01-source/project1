export function createCustomerOrdersService(supabase) {
    if (!supabase) throw new Error('supabase client is required');

    function toApiStatus(statusValue) {
        const raw = String(statusValue || 'all').trim().toLowerCase();
        if (raw === 'all') return 'all';
        return raw;
    }

    function toApiSort(sortValue) {
        const raw = String(sortValue || 'new').trim().toLowerCase();
        if (raw === 'old') return 'oldest';
        return 'newest';
    }

    async function listCustomerOrders({ customerId, status, search, sort }) {
        const payload = {
            customer_id: String(customerId || '').trim(),
            status: toApiStatus(status),
            search: String(search || '').trim(),
            sort: toApiSort(sort)
        };

        const { data, error } = await supabase.functions.invoke('customer-orders-secure-list', {
            body: payload
        });

        if (error) throw error;
        if (data?.error) throw new Error(data.error);

        const rows = Array.isArray(data?.orders) ? data.orders : [];
        return rows.map((row) => ({
            ...row,
            items: Array.isArray(row.items) ? row.items : [],
            last_event: row.last_event || null
        }));
    }

    return { listCustomerOrders };
}
