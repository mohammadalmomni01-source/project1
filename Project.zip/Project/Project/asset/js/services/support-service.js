(function(){
  const TICKETS_KEY = 'support_tickets';
  const MSG_KEY = 'support_ticket_messages';

  // Support requester roles: customer / provider / admin.
  // Older storage used readBy.customer/admin only.
  // For backwards compatibility we map provider -> customer for read/unread tracking.
  function readKey(role){
    const r = String(role||'').trim().toLowerCase();
    return (r === 'admin' || r === 'employee') ? 'admin' : 'customer';
  }

  function nowISO(){ return new Date().toISOString(); }
  function uid(prefix='tkt'){
    return `${prefix}-${Math.random().toString(16).slice(2,10)}-${Date.now().toString(16)}`;
  }

  function loadTickets(){
    try{ return JSON.parse(localStorage.getItem(TICKETS_KEY) || '[]'); }catch(e){ return []; }
  }
  function saveTickets(list){
    localStorage.setItem(TICKETS_KEY, JSON.stringify(Array.isArray(list)?list:[]));
  }
  function loadMsgsDB(){
    try{ return JSON.parse(localStorage.getItem(MSG_KEY) || '{}'); }catch(e){ return {}; }
  }
  function saveMsgsDB(db){
    localStorage.setItem(MSG_KEY, JSON.stringify(db || {}));
  }

  function normalizeStatus(s){
    const v = String(s||'').trim().toLowerCase();
    if(v === 'answered' || v === 'replied') return 'Answered';
    if(v === 'closed' || v === 'resolved') return 'Closed';
    return 'Open';
  }

  function listTickets({email=null, role=null, customerEmail=null}={}){
    if(!email && customerEmail) email = customerEmail;
    const all = loadTickets();
    let out = all.map(t => ({...t, status: normalizeStatus(t.status)}));
    if(email){
      const e = String(email).trim().toLowerCase();
      out = out.filter(t => String(t.customerEmail||'').trim().toLowerCase() === e);
    }
    if(role){
      const r = String(role).trim().toLowerCase();
      out = out.filter(t => String(t.requesterRole||'customer').trim().toLowerCase() === r);
    }
    out.sort((a,b)=> String(b.updatedAt||b.createdAt||'').localeCompare(String(a.updatedAt||a.createdAt||'')));
    return out;
  }

  function getTicket(ticketId){
    const all = loadTickets();
    const id = String(ticketId||'');
    const t = all.find(x => String(x.id) === id);
    return t ? {...t, status: normalizeStatus(t.status)} : null;
  }

  function createTicket({customerEmail, customerName, subject, category, message, orderRef, requesterRole='customer'}={}){
    const emailRaw = String(customerEmail||'').trim();
    // Block guest sessions (even if user types a different email)
    try{
      const cs = localStorage.getItem('customer_session');
      if(cs && /"isGuest"\s*:\s*true/i.test(cs)){
        return {ok:false, error:'Guest accounts cannot create support tickets'};
      }
    }catch(e){}
    if(emailRaw && /@guest\.local\s*$/i.test(emailRaw)){
      return {ok:false, error:'Guest accounts cannot create support tickets'};
    }
    const createdAt = nowISO();
    const id = uid('tkt');
    const t = {
      id,
      customerEmail: String(customerEmail||'').trim(),
      customerName: String(customerName||'').trim(),
      requesterRole: String(requesterRole||'customer').trim() || 'customer',
      subject: String(subject||'').trim() || 'Help request',
      category: String(category||'General').trim(),
      orderRef: String(orderRef||'').trim(),
      status: 'Open',
      createdAt,
      updatedAt: createdAt,
      lastReplyRole: 'customer'
    };
    const all = loadTickets();
    all.push(t);
    saveTickets(all);

    // Initial message: route through sendMessage so auto-ack + status policy work.
    const text = String(message||'').trim();
    if(text){
      const fromRole = String(requesterRole||'customer').trim().toLowerCase() === 'provider' ? 'provider' : 'customer';
      const res = sendMessage(id, { fromRole, text });
      if(res && res.ok === false){
        // If something goes wrong, fall back to ticket creation only.
        return {ok:false, error: res.error || 'Unable to create ticket message'};
      }
    }

    return t;
  }

  function updateTicket(ticketId, patch={}){
    const all = loadTickets();
    const id = String(ticketId||'');
    const idx = all.findIndex(x => String(x.id) === id);
    if(idx < 0) return {ok:false, error:'Ticket not found'};

    const cur = all[idx];
    const next = {...cur, ...patch};
    if(patch.status) next.status = normalizeStatus(patch.status);
    next.updatedAt = patch.updatedAt || nowISO();
    all[idx] = next;
    saveTickets(all);
    return {ok:true, ticket: next};
  }

  function deleteTicket(ticketId){
    const id = String(ticketId||'');
    const all = loadTickets();
    const next = all.filter(t => String(t.id) !== id);
    saveTickets(next);
    const db = loadMsgsDB();
    if(db[id]){ delete db[id]; saveMsgsDB(db); }
    return {ok:true};
  }

  function listMessages(ticketId){
    const id = String(ticketId||'');
    const db = loadMsgsDB();
    const arr = Array.isArray(db[id]) ? db[id] : [];
    const out = arr.slice().reverse(); // oldest-first for UI
    return out.map(m => ({
      id: m.id || uid('msg'),
      ticketId: id,
      fromRole: m.fromRole || 'customer',
      fromName: m.fromName || '',
      fromEmail: m.fromEmail || '',
      text: String(m.text||''),
      createdAt: m.createdAt || nowISO(),
      readBy: (m.readBy && typeof m.readBy === 'object') ? m.readBy : {customer:false, admin:false}
    }));
  }

  function _writeMessage(ticketId, msg){
    const id = String(ticketId||'');
    const db = loadMsgsDB();
    db[id] = Array.isArray(db[id]) ? db[id] : [];
    db[id].unshift(msg);
    saveMsgsDB(db);
  }

  function sendMessage(ticketId, {fromRole='customer', text, fromName='', fromEmail=''}={}){
    const t0 = getTicket(ticketId);
    if(t0 && t0.customerEmail && /@guest\.local\s*$/i.test(String(t0.customerEmail).trim())){
      return {ok:false, error:'Guest accounts cannot use support messages'};
    }
    const t = getTicket(ticketId);
    if(!t) return {ok:false, error:'Ticket not found'};
    const clean = String(text||'').trim();
    if(!clean) return {ok:false, error:'Empty message'};

    const createdAt = nowISO();
    const rk = readKey(fromRole);
    const msg = {
      id: uid('msg'),
      ticketId: String(ticketId),
      fromRole,
      fromName: String(fromName||''),
      fromEmail: String(fromEmail||''),
      text: clean,
      createdAt,
      readBy: {
        customer: rk === 'customer',
        admin: rk === 'admin'
      }
    };
    _writeMessage(ticketId, msg);

    // Auto-acknowledgement (English): first message from requester gets an instant reply.
    // We send it as an admin message so it shows to the customer/provider immediately.
    // It is only sent once per ticket.
    // Send a one-time auto acknowledgement for the first requester message.
    // (Requester roles: customer/provider). We treat employee as admin.
    if(fromRole !== 'admin' && fromRole !== 'employee' && !t.autoAckSent){
      const ack = {
        id: uid('msg'),
        ticketId: String(ticketId),
        fromRole: 'admin',
        text: 'Thank you for contacting us. We have received your message and will get back to you as soon as possible.',
        createdAt: nowISO(),
        readBy: { customer:false, admin:true }
      };
      _writeMessage(ticketId, ack);
      // Mark that we sent the acknowledgement
      updateTicket(ticketId, { autoAckSent: true });
    }

    // status logic (policy):
    // - Any admin reply => Answered
    // - Any customer/provider reply => Open (re-open if needed)
    const currentStatus = normalizeStatus(t.status);
    const status = (fromRole === 'admin' || fromRole === 'employee') ? (currentStatus === 'Closed' ? 'Closed' : 'Answered') : 'Open';
    updateTicket(ticketId, { status, updatedAt: createdAt, lastReplyRole: fromRole });
    return {ok:true, message: msg};
  }

  function markRead(ticketId, role){
    const id = String(ticketId||'');
    const db = loadMsgsDB();
    const arr = Array.isArray(db[id]) ? db[id] : [];
    let changed = false;
    const rk = readKey(role);
    for(const m of arr){
      m.readBy = (m.readBy && typeof m.readBy === 'object') ? m.readBy : {customer:false, admin:false};
      if(rk === 'customer' && !m.readBy.customer){ m.readBy.customer = true; changed = true; }
      if(rk === 'admin' && !m.readBy.admin){ m.readBy.admin = true; changed = true; }
    }
    if(changed){ db[id] = arr; saveMsgsDB(db); }
    return changed;
  }

  function getUnreadCount(ticketId, role){
    const msgs = listMessages(ticketId);
    const rk = readKey(role);
    let n = 0;
    for(const m of msgs){
      if(m.fromRole === role) continue;
      const rb = m.readBy || {customer:false, admin:false};
      if(rk === 'customer' && !rb.customer) n++;
      if(rk === 'admin' && !rb.admin) n++;
    }
    return n;
  }

  window.SupportService = {
    listTickets,
    getTicket,
    createTicket,
    updateTicket,
    deleteTicket,
    listMessages,
    sendMessage,
    markRead,
    getUnreadCount,
    normalizeStatus
  };
})();
