import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = (window.SUPABASE_URL || "https://ranqskqvcpywcnekhvfs.supabase.co").trim();
const SUPABASE_ANON_KEY = (window.SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhbnFza3F2Y3B5d2NuZWtodmZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MjczODQsImV4cCI6MjA4NjQwMzM4NH0.0nypi0ARFvfjm0mIC02pFO9fwdUL0PI5bru_amanq34").trim();
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});

const reqBody = document.getElementById("reqBody");
const reqFilter = document.getElementById("reqFilter");
const reqRefresh = document.getElementById("reqRefresh");
const errBox = document.getElementById("reqErr");

const reqModalBd = document.getElementById("reqModalBd");
const reqModal = document.getElementById("reqModal");
const modalClose = document.getElementById("modalClose");
const modalTitle = document.getElementById("modalTitle");
const modalMeta = document.getElementById("modalMeta");
const btnEditRequest = document.getElementById("btnEditRequest");
const btnEditProduct = document.getElementById("btnEditProduct");
const btnSaveModal = document.getElementById("btnSaveModal");

const fieldImageWrap = document.getElementById("fieldImageWrap");
const fieldImagePreview = document.getElementById("fieldImagePreview");
const fieldNameWrap = document.getElementById("fieldNameWrap");
const fieldCategoryWrap = document.getElementById("fieldCategoryWrap");
const fieldPriceWrap = document.getElementById("fieldPriceWrap");
const fieldStockWrap = document.getElementById("fieldStockWrap");
const fieldImageUrlWrap = document.getElementById("fieldImageUrlWrap");
const fieldDescriptionWrap = document.getElementById("fieldDescriptionWrap");
const fieldAdminNoteWrap = document.getElementById("fieldAdminNoteWrap");

const fieldName = document.getElementById("fieldName");
const fieldCategory = document.getElementById("fieldCategory");
const fieldPrice = document.getElementById("fieldPrice");
const fieldStock = document.getElementById("fieldStock");
const fieldImageUrl = document.getElementById("fieldImageUrl");
const fieldDescription = document.getElementById("fieldDescription");
const fieldAdminNote = document.getElementById("fieldAdminNote");

const strategyCache = { products: null };

let state = {
    session: null,
    user: null,
    profile: null,
    requests: [],
    currentRequest: null,
    currentMode: "view",
    currentProduct: null,
};

const SELECT_LIST_A = "id,created_at,status,name,category,price,stock,admin_note,description,image_url";
const SELECT_LIST_B = "id,created_at,status,item_name,item_category,unit_price,qty,note,description,image,provider_id";
const PROVIDER_KEYS = ["provider_id", "user_id", "owner_id"];

function showError(message) {
    if (!errBox) return;
    errBox.style.display = message ? "block" : "none";
    errBox.textContent = message || "";
}

function esc(v) {
    return String(v ?? "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
}

function normalizeStatus(raw) {
    const v = String(raw || "").toLowerCase().trim();
    return ["pending", "approved", "rejected"].includes(v) ? v : "pending";
}

function formatPrice(raw) {
    const n = Number(raw);
    return Number.isFinite(n) ? `$${n.toFixed(2)}` : "�";
}

function formatStock(raw) {
    const n = Number(raw);
    return Number.isFinite(n) ? String(Math.trunc(n)) : "�";
}

function prettyDate(v) {
    if (!v) return "�";
    try { return new Date(v).toLocaleString(); } catch (_) { return String(v); }
}

function normalizeRow(row) {
    return {
        raw: row,
        id: row?.id,
        name: row?.name ?? row?.item_name ?? row?.product_name ?? row?.title ?? "",
        category: row?.category ?? row?.item_category ?? row?.cat ?? "",
        price: row?.price ?? row?.unit_price ?? row?.cost ?? null,
        stock: row?.stock ?? row?.qty ?? row?.quantity ?? null,
        status: normalizeStatus(row?.status),
        createdAt: row?.created_at ?? row?.createdAt ?? row?.date ?? null,
        adminNote: row?.admin_note ?? row?.note ?? row?.reason ?? row?.adminNote ?? "",
        imageUrl: row?.image_url ?? row?.image ?? row?.img ?? "",
        description: row?.description ?? row?.desc ?? "",
        requestRowId: row?.id ?? null,
        productRowId: row?.product_id ?? null,
        productId: row?.product_id ?? null,
    };
}

function isColumnError(error) {
    const msg = String(error?.message || error?.details || "").toLowerCase();
    return msg.includes("column") || msg.includes("does not exist");
}

function isPermissionError(error) {
    const msg = String(error?.message || "").toLowerCase();
    return String(error?.code || "") === "42501" || msg.includes("permission denied");
}

async function runRequestsQuery({ selectList, providerKey, providerId, statusFilter, withOrder }) {
    let q = supabase.from("product_requests").select(selectList);
    if (providerKey) q = q.eq(providerKey, providerId);
    if (statusFilter) q = q.eq("status", statusFilter);
    if (withOrder) q = q.order("created_at", { ascending: false });
    return await q;
}

async function fetchProviderRequests(sessionUserId) {
    const statusFilter = (() => {
        const v = String(reqFilter?.value || "all").toLowerCase();
        return v === "all" ? null : normalizeStatus(v);
    })();

    let lastError = null;

    for (const selectList of [SELECT_LIST_A, SELECT_LIST_B]) {
        for (const providerKey of PROVIDER_KEYS) {
            let result = await runRequestsQuery({
                selectList,
                providerKey,
                providerId: sessionUserId,
                statusFilter,
                withOrder: true,
            });

            if (!result.error) return result;
            if (isPermissionError(result.error)) throw result.error;

            if (isColumnError(result.error) && String(result.error.message || "").toLowerCase().includes("created_at")) {
                result = await runRequestsQuery({
                    selectList,
                    providerKey,
                    providerId: sessionUserId,
                    statusFilter,
                    withOrder: false,
                });
                if (!result.error) return result;
                if (isPermissionError(result.error)) throw result.error;
            }

            if (isColumnError(result.error)) {
                lastError = result.error;
                continue;
            }

            lastError = result.error;
        }
    }

    // Fallback: no provider key worked (schema variant). Load with safe select only.
    for (const selectList of [SELECT_LIST_A, SELECT_LIST_B]) {
        let result = await runRequestsQuery({
            selectList,
            providerKey: null,
            providerId: null,
            statusFilter,
            withOrder: true,
        });

        if (!result.error) return result;
        if (isPermissionError(result.error)) throw result.error;

        if (isColumnError(result.error) && String(result.error.message || "").toLowerCase().includes("created_at")) {
            result = await runRequestsQuery({
                selectList,
                providerKey: null,
                providerId: null,
                statusFilter,
                withOrder: false,
            });
            if (!result.error) return result;
            if (isPermissionError(result.error)) throw result.error;
        }

        lastError = result.error;
    }

    throw lastError || new Error("Unknown query failure");
}

async function requireProvider() {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
        window.location.href = "provider-login.html";
        return null;
    }

    const { data: profile, error } = await supabase
        .from("profiles")
        .select("full_name, role")
        .eq("id", session.user.id)
        .maybeSingle();

    if (error || !profile || profile.role !== "provider") {
        await supabase.auth.signOut();
        window.location.href = "provider-login.html";
        return null;
    }

    return { session, user: session.user, profile };
}

async function pickProductsWhereClause(uid) {
    if (strategyCache.products) return strategyCache.products;
    const probe = await supabase.from("products").select("id").eq("provider_id", uid).limit(1);
    const strategy = probe.error ? "provider_email" : "provider_id";
    strategyCache.products = strategy;
    console.log("provider scope strategy:", strategy);
    return strategy;
}

function applyProductsScope(query, strategy, uid, email) {
    return strategy === "provider_email" ? query.eq("provider_email", email) : query.eq("provider_id", uid);
}

async function saveViaEdgeFunction(target, rowId) {
    const { data, error } = await supabase.functions.invoke("provider-edit-item", {
        body: {
            target,
            row_id: rowId,
            values: {
                name: fieldName.value.trim(),
                category: fieldCategory.value.trim() || null,
                price: Number(fieldPrice.value || 0),
                stock: Number(fieldStock.value || 0),
                description: fieldDescription.value.trim() || null,
                image: fieldImageUrl.value.trim() || null,
            },
        },
    });

    if (error) {
        throw new Error(error.message || "Edge function invocation failed");
    }
    if (!data?.ok) {
        throw new Error(data?.error || "Save failed");
    }
}

async function loadRequests() {
    showError("");

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
        window.location.href = "provider-login.html";
        return;
    }

    try {
        const { data, error } = await fetchProviderRequests(session.user.id);

        if (error) throw error;

        let rows = (data || []).map(normalizeRow);

        // if no provider key existed, keep only current provider by email when available
        const myEmail = String(session.user?.email || "").toLowerCase();
        if (myEmail) {
            rows = rows.filter((r) => {
                const rawEmail = String(r.raw?.provider_email || r.raw?.email || "").toLowerCase();
                return rawEmail ? rawEmail === myEmail : true;
            });
        }

        state.requests = rows;
        render();
    } catch (error) {
        if (isPermissionError(error)) {
            showError("Not authorized to read item requests. Ask admin to allow providers to read their own product_requests.");
        } else {
            showError(`Failed to load requests: ${error?.message || "Unknown error"}`);
        }
        console.error("provider-item-requests load failed", { error });
        reqBody.innerHTML = `<tr><td colspan="7">Failed to load requests.</td></tr>`;
    }
}

function render() {
    reqBody.innerHTML = state.requests.map((r) => {
        const actions = [
            `<button class="btn btn-secondary" data-act="view" data-id="${esc(r.id)}">View</button>`,
            ["pending", "rejected"].includes(r.status)
                ? `<button class="btn btn-primary" data-act="edit-request" data-id="${esc(r.id)}">Edit request</button>`
                : "",
            r.status === "approved"
                ? `<button class="btn btn-secondary" data-act="edit-product" data-id="${esc(r.id)}">Edit product</button>`
                : "",
        ].filter(Boolean).join(" ");

        return `
      <tr>
        <td>${esc(prettyDate(r.createdAt))}</td>
        <td>${esc(r.name || "�")}</td>
        <td>${esc(r.category || "�")}</td>
        <td>${esc(formatPrice(r.price))}</td>
        <td>${esc(formatStock(r.stock))}</td>
        <td>${esc(r.status)}</td>
        <td>${actions || "�"}</td>
      </tr>
    `;
    }).join("") || `<tr><td colspan="7">No requests found.</td></tr>`;
}

function openModal() {
    reqModalBd?.classList.add("show");
    reqModal?.classList.add("show");
}

function closeModal() {
    reqModalBd?.classList.remove("show");
    reqModal?.classList.remove("show");
    state.currentMode = "view";
    state.currentRequest = null;
    state.currentProduct = null;
}

function setFieldVisibility(wrap, visible) {
    if (wrap) wrap.style.display = visible ? "flex" : "none";
}

function setEditability(editable) {
    [fieldName, fieldCategory, fieldPrice, fieldStock, fieldImageUrl, fieldDescription].forEach((el) => {
        if (el) el.readOnly = !editable;
    });
}

function fillModalFromRequest(r) {
    fieldName.value = r.name || "";
    fieldCategory.value = r.category || "";
    fieldPrice.value = Number.isFinite(Number(r.price)) ? Number(r.price) : "";
    fieldStock.value = Number.isFinite(Number(r.stock)) ? Math.trunc(Number(r.stock)) : "";
    fieldImageUrl.value = r.imageUrl || "";
    fieldDescription.value = r.description || "";
    fieldAdminNote.value = r.adminNote || "";

    if (r.imageUrl) {
        fieldImagePreview.src = r.imageUrl;
        fieldImagePreview.style.display = "block";
    } else {
        fieldImagePreview.style.display = "none";
    }
}

function showViewModal(r) {
    state.currentRequest = r;
    state.currentMode = "view";

    modalTitle.textContent = "Item Request";
    modalMeta.textContent = `${r.status} � ${prettyDate(r.createdAt)}`;

    setEditability(false);
    setFieldVisibility(fieldImageWrap, true);
    setFieldVisibility(fieldNameWrap, true);
    setFieldVisibility(fieldCategoryWrap, true);
    setFieldVisibility(fieldPriceWrap, true);
    setFieldVisibility(fieldStockWrap, true);
    setFieldVisibility(fieldImageUrlWrap, true);
    setFieldVisibility(fieldDescriptionWrap, true);
    setFieldVisibility(fieldAdminNoteWrap, !!r.adminNote);

    fillModalFromRequest(r);

    btnSaveModal.style.display = "none";
    btnEditRequest.style.display = ["pending", "rejected"].includes(r.status) ? "inline-block" : "none";
    btnEditProduct.style.display = r.status === "approved" ? "inline-block" : "none";

    openModal();
}

function showEditRequestModal(r) {
    state.currentRequest = r;
    state.currentMode = "edit-request";

    modalTitle.textContent = "Edit request";
    modalMeta.textContent = `${r.status} � ${prettyDate(r.createdAt)}`;

    setEditability(true);
    setFieldVisibility(fieldImageWrap, true);
    setFieldVisibility(fieldNameWrap, true);
    setFieldVisibility(fieldCategoryWrap, true);
    setFieldVisibility(fieldPriceWrap, true);
    setFieldVisibility(fieldStockWrap, true);
    setFieldVisibility(fieldImageUrlWrap, true);
    setFieldVisibility(fieldDescriptionWrap, true);
    setFieldVisibility(fieldAdminNoteWrap, !!r.adminNote);

    fillModalFromRequest(r);

    btnEditRequest.style.display = "none";
    btnEditProduct.style.display = "none";
    btnSaveModal.style.display = "inline-block";

    openModal();
}

async function findProductForApprovedRequest(r) {
    const uid = state.user.id;
    const email = state.user.email || "";
    const strategy = await pickProductsWhereClause(uid);

    if (r.productId) {
        let q = supabase.from("products").select("*").eq("id", r.productId).limit(1);
        q = applyProductsScope(q, strategy, uid, email);
        const { data, error } = await q;
        if (!error && data?.[0]) return data[0];
    }

    let q2 = supabase
        .from("products")
        .select("*")
        .eq("name", r.name || "")
        .eq("category", r.category || "")
        .limit(1);
    q2 = applyProductsScope(q2, strategy, uid, email);
    const { data: byName, error: byNameErr } = await q2;
    if (byNameErr) {
        console.error(byNameErr);
        return null;
    }
    return byName?.[0] || null;
}

function showEditProductModal(r, productRow) {
    state.currentRequest = r;
    state.currentMode = "edit-product";
    state.currentProduct = productRow;

    modalTitle.textContent = "Edit product";
    modalMeta.textContent = `approved � ${prettyDate(r.createdAt)}`;

    setEditability(true);
    setFieldVisibility(fieldImageWrap, true);
    setFieldVisibility(fieldNameWrap, true);
    setFieldVisibility(fieldCategoryWrap, true);
    setFieldVisibility(fieldPriceWrap, true);
    setFieldVisibility(fieldStockWrap, true);
    setFieldVisibility(fieldImageUrlWrap, true);
    setFieldVisibility(fieldDescriptionWrap, true);
    setFieldVisibility(fieldAdminNoteWrap, false);

    const p = productRow || {};
    fieldName.value = p.name || r.name || "";
    fieldCategory.value = p.category || r.category || "";
    fieldPrice.value = Number.isFinite(Number(p.price)) ? Number(p.price) : (Number.isFinite(Number(r.price)) ? Number(r.price) : "");
    fieldStock.value = Number.isFinite(Number(p.stock)) ? Math.trunc(Number(p.stock)) : (Number.isFinite(Number(r.stock)) ? Math.trunc(Number(r.stock)) : "");
    fieldImageUrl.value = p.image_url || r.imageUrl || "";
    fieldDescription.value = p.description || r.description || "";

    if (fieldImageUrl.value) {
        fieldImagePreview.src = fieldImageUrl.value;
        fieldImagePreview.style.display = "block";
    } else {
        fieldImagePreview.style.display = "none";
    }

    btnEditRequest.style.display = "none";
    btnEditProduct.style.display = "none";
    btnSaveModal.style.display = "inline-block";

    openModal();
}

async function saveEditRequest() {
    const r = state.currentRequest;
    const rowId = r?.requestRowId || r?.id;
    if (!rowId) return;

    try {
        await saveViaEdgeFunction("request", rowId);
    } catch (error) {
        console.error({ error });
        alert(`Failed to save request: ${error?.message || "Unknown error"}`);
        return;
    }

    alert("Saved");
    closeModal();
    await loadRequests();
}

async function saveEditProduct() {
    const p = state.currentProduct;
    const rowId = state.currentRequest?.productRowId || p?.id;
    if (!rowId) return;

    try {
        await saveViaEdgeFunction("product", rowId);
    } catch (error) {
        console.error({ error });
        alert(`Failed to save product: ${error?.message || "Unknown error"}`);
        return;
    }

    alert("Saved");
    closeModal();
    await loadRequests();
}

function bind() {
    document.addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-act][data-id]");
        if (!btn) return;
        const id = btn.getAttribute("data-id");
        const act = btn.getAttribute("data-act");
        if (!id || !act) return;

        const r = state.requests.find((x) => String(x.id) === String(id));
        if (!r) return;

        if (act === "view") showViewModal(r);
        if (act === "edit-request" && ["pending", "rejected"].includes(r.status)) showEditRequestModal(r);
        if (act === "edit-product" && r.status === "approved") {
            findProductForApprovedRequest(r).then((product) => {
                if (!product) return alert("Approved product not found.");
                showEditProductModal(r, product);
            });
        }
    });

    reqFilter?.addEventListener("change", loadRequests);
    reqRefresh?.addEventListener("click", loadRequests);

    modalClose?.addEventListener("click", closeModal);
    reqModalBd?.addEventListener("click", closeModal);

    btnEditRequest?.addEventListener("click", () => {
        if (!state.currentRequest) return;
        showEditRequestModal(state.currentRequest);
    });

    btnEditProduct?.addEventListener("click", async () => {
        if (!state.currentRequest) return;
        const product = await findProductForApprovedRequest(state.currentRequest);
        if (!product) return alert("Approved product not found.");
        showEditProductModal(state.currentRequest, product);
    });

    btnSaveModal?.addEventListener("click", async () => {
        if (state.currentMode === "edit-request") await saveEditRequest();
        if (state.currentMode === "edit-product") await saveEditProduct();
    });
}

async function init() {
    const auth = await requireProvider();
    if (!auth) return;
    state = { ...state, ...auth };
    bind();
    await loadRequests();
}

init();
